# Arquivos modificados e criados — R2

## Base
A R2 parte do ZIP incremental R1 aplicado sobre o ZIP completo original enviado em 01/11/2026. Os dados e a estrutura preexistentes foram preservados.

## Alterações R2
- `lib/services/media_generation_service.dart` (novo): seleção de contas de imagem/vídeo por capacidade, prioridade e credencial segura; chamadas REST; suporte a OpenAI Images, Gemini image generation e contratos de vídeo síncronos/assíncronos com `status_url`, `polling_url` ou cabeçalho `Location`; mensagens de erro explícitas.
- `lib/services/api_provider_adapter.dart`: adaptador de texto OpenAI Chat Completions, endpoint configurável e aliases para provedores OpenAI-compatíveis.
- `lib/services/content_generation_service.dart`: encaminha o endpoint configurado para o adaptador de texto.
- `lib/services/automation_task_executor.dart`: geração real de imagens e vídeos depois do texto; exige quatro slides antes das imagens; bloqueia conclusão/aprovação quando mídia necessária falha; encaminha mídia e erros aos rascunhos.
- `lib/models/post_schedule.dart`: persiste URLs de quatro imagens e URL de vídeo, mantendo compatibilidade com registros antigos.
- `lib/screens/post_schedule_screen.dart`: prévia das imagens, player de vídeo e bloqueio de aprovação condicionado à existência dos arquivos necessários.
- `lib/screens/content_generator_screen.dart`: após geração, abre automaticamente a lista de configuração/revisão das postagens criadas.
- `lib/screens/post_history_screen.dart`: mostra quantidade de mídia gerada e erros de geração no cartão da postagem.
- `lib/screens/api_center_screen.dart`: endpoint configurável e teste de chamada real para endpoints de imagem/vídeo; teste de texto Google/OpenAI-compatível.
- `lib/services/api_model_catalog.dart`: modelos OpenAI iniciais.
- `pubspec.yaml`: dependência `video_player` para prévia de vídeo Android/Web.
- `test/post_schedule_media_test.dart` (novo): testes de serialização de mídia e compatibilidade retroativa.
- `test/api_provider_adapter_test.dart` (novo): testes do adaptador de texto OpenAI-compatible e erros HTTP.

## Arquivos incorporados da R1
A R1 também adicionou armazenamento seguro de credenciais, execução imediata do gerador, encaminhamento para configuração de postagens e documentação inicial. Consulte o histórico da R1 nos demais documentos.

---

## Alterações e Novos Módulos — Grande Atualização R3 (02/11/2026)
- `BACKUP_ORIGINAL_R2/automacao_conteudo_R2_pasta_completa_backup.zip` (novo): backup íntegro da versão R2 original preservado antes das modificações.
- `lib/core/theme_controller.dart` (novo): gerenciador de Tema Claro e Tema Escuro com identidade visual tecnológica premium e persistência local.
- `lib/main.dart`: integrado ao `ThemeController` permitindo alternar entre tema claro e escuro em tempo real.
- `lib/models/api_provider.dart`: expandido com suporte a múltiplas capacidades (`capabilities`), limite diário de cota gratuita (`dailyQuotaLimit`), uso diário (`usedQuotaToday`), contador de usos (`usageCount`), status de disponibilidade (`availabilityStatus`), permissão de uso comercial e último erro registrado, mantendo 100% de compatibilidade com os dados R2.
- `lib/models/post_schedule.dart`: expandido com a frase obrigatória no 4º slide (`PostSchedule.mandatoryFourthSlidePhrase`), listas dinâmicas de slides extras de publicidade (`extraAdSlideTexts`, `extraAdSlideImageUrls`), fontes e evidências (`evidenceSources`, `hasSufficientEvidence`), agendamento de reavaliação semestral (`reEvaluateAt`) e métricas reais fornecidas pelas plataformas (`metrics`).
- `lib/models/media_item.dart` (novo): modelo de mídia centralizada (imagem, vídeo, áudio) com tags, vínculo a tema, indicador de nuvem e controle de cache local.
- `lib/models/production_plan.dart` (novo): modelos `ProductionPlan` e `ProductionScene` do Diretor de Produção com IA.
- `lib/services/api_model_catalog.dart`: atualizado com a pesquisa de APIs 2026 (Google Gemini 2.5/3.1, Groq Llama 3.3/Qwen, OpenRouter DeepSeek Free, Cloudflare Workers AI FLUX.1 Schnell, Google Veo 2.0, Luma Ray 2, Instagram Graph API, Facebook Pages API e TikTok Content Posting API).
- `lib/services/api_provider_registry.dart`: busca por capacidade múltipla e gravação automática de consumo de cota e erros.
- `lib/services/content_generation_service.dart`: seleção de provedor preferencial, inclusão de fontes de pesquisa, aviso obrigatório de IA e registro automático de fallback em `ApiFallbackHistoryService`.
- `lib/services/media_generation_service.dart`: integração automática com a Biblioteca de Mídia e registro de cotas/erros por provedor.
- `lib/services/media_library_service.dart` (novo): gerenciamento centralizado de mídias e controle de orçamento de cache local (50 MB).
- `lib/services/production_director_service.dart` (novo): geração e edição de planos de produção divididos em 4 cenas com continuidade visual e prompts específicos por provedor.
- `lib/services/social_publishing_service.dart` (novo): armazenamento seguro segregado de tokens OAuth de redes sociais, verificação real de autenticação/permissões (Instagram, Facebook, TikTok), prevenção de publicações duplicadas e alerta de finalização manual.
- `lib/services/content_verification_service.dart` (novo): checagem de evidências e fontes antes da publicação e implementação do estado `"Reavaliar mais tarde"` (+6 meses).
- `lib/services/statistics_service.dart` (novo): consolidação de estatísticas por tema, rede social, conta, vídeo e melhores horários sem inventar métricas não fornecidas.
- `lib/services/automation_task_executor.dart`: aplicação automática da frase obrigatória no 4º slide, validação de evidências e execução de tarefas de revisão semestral.
- `lib/screens/home_screen.dart`: painel principal responsivo com indicadores gerais, alternador de tema claro/escuro e layout otimizado para celulares, notebooks e **Samsung Galaxy Tab S8 Ultra**.
- `lib/screens/api_center_screen.dart`: abas por categoria (Texto, Imagem, Vídeo, Redes Sociais, Áudio), seleção de múltiplas capacidades e controle de cota diária.
- `lib/screens/content_generator_screen.dart`: seleção de provedores de texto/imagem/vídeo, edição de prompt, presets reutilizáveis, fontes de pesquisa e slides extras de publicidade.
- `lib/screens/post_schedule_screen.dart`: prévia visual de carrossel com texto sobreposto e alto contraste, zoom interativo, slides extras de publicidade sem alterar código, player de vídeo com áudio (play/pause, barra de progresso, volume, duração e tela cheia) e estado `"Reavaliar mais tarde"`.
- `lib/screens/media_library_screen.dart` (novo): tela da Biblioteca de Mídia centralizada.
- `lib/screens/production_director_screen.dart` (novo): tela do Diretor de Produção com IA.
- `lib/screens/statistics_reports_screen.dart` (novo): tela de Estatísticas e Relatórios.
- `lib/screens/diagnostic_center_screen.dart` (novo): tela da Central de Diagnóstico do Sistema.
- `test/r3_features_test.dart` (novo): testes automatizados validando as regras da atualização R3.
- `DOCUMENTACAO/PESQUISA_APIS_2026.md` e `DOCUMENTACAO/RELATORIO_IMPLEMENTACAO_R3.md` (novos).
