# Pesquisa e Atualização de APIs — Edição R3 (Novembro de 2026)

Esta documentação consolida as pesquisas realizadas nas documentações oficiais dos provedores de Inteligência Artificial (Texto, Imagem e Vídeo) e das Redes Sociais (Instagram, Facebook e TikTok), incluindo limites gratuitos, planos de teste, permissões de uso comercial e custos potenciais.

---

## 1. APIs de Geração de Texto (`capability: text`)

| Provedor / Modelo | Plano Gratuito / Limites de Teste | Uso Comercial | Endpoint Oficial / Contrato | Custos Potenciais (Plano Pago) |
| :--- | :--- | :--- | :--- | :--- |
| **Google Gemini API** (`gemini-3.1-flash-lite`, `gemini-2.5-flash`, `gemini-2.5-pro`) | Camada gratuita no [Google AI Studio](https://ai.google.dev/gemini-api/docs/rate-limits) sem cartão de crédito obrigatório; limites por minuto (RPM) e por dia (RPD) variáveis conforme nível da conta. | Permitido nos termos da [Gemini API](https://ai.google.dev/gemini-api/terms) (no plano gratuito os dados podem ser usados para melhoria do serviço; no Tier Pago há privacidade corporativa). | `https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent` | A partir de US$ 0,075 a US$ 1,35 por 1M tokens de entrada conforme o modelo ([Pricing Oficial](https://ai.google.dev/gemini-api/docs/pricing)). |
| **GroqCloud API** (`llama-3.3-70b-versatile`, `qwen-qwq-32b`) | Plano gratuito ativo no [Groq Console](https://console.groq.com/docs/rate-limits) (~30 requisições/minuto e até 1.000 requisições/dia ou 200.000 tokens/dia conforme o modelo). | Permitido conforme a licença dos modelos abertos (Llama 3.3 / Qwen Apache 2.0) e termos da Groq. | `https://api.groq.com/openai/v1/chat/completions` (Compatível OpenAI) | Pay-as-you-go sob demanda apenas se o usuário ativar o Developer Tier no painel da Groq. |
| **OpenRouter** (`deepseek/deepseek-r1:free`) | Modelos com sufixo `:free` gratuitos com limite de requisições por minuto/dia por conta. | Permitido conforme licença MIT do DeepSeek R1. | `https://openrouter.ai/api/v1/chat/completions` (Compatível OpenAI) | Gratuito nos modelos `:free`; modelos pagos consomem créditos pré-pagos. |
| **OpenAI API** (`gpt-4.1-mini`, `gpt-4o-mini`) | Sem cota gratuita recorrente (exige créditos pré-pagos a partir de US$ 5). | 100% permitido com retenção zero para treinamento de modelos por padrão na API. | `https://api.openai.com/v1/chat/completions` | Cobrança por 1 milhão de tokens processados. |

---

## 2. APIs de Geração de Imagens (`capability: image`)

| Provedor / Modelo | Plano Gratuito / Limites de Teste | Uso Comercial | Endpoint Oficial / Contrato | Custos Potenciais (Plano Pago) |
| :--- | :--- | :--- | :--- | :--- |
| **Cloudflare Workers AI** (`@cf/black-forest-labs/flux-1-schnell`) | **10.000 Neurons por dia grátis** ([Cloudflare Workers AI Pricing](https://developers.cloudflare.com/workers-ai/platform/pricing/)), equivalente a aproximadamente **104 a 173 imagens 1024x1024 por dia sem custo**. | Permitido (FLUX.1 Schnell utiliza licença Apache 2.0 comercialmente livre). | Endpoint REST Cloudflare Workers AI / Worker Proxy | Acima de 10.000 Neurons/dia: US$ 0,011 por 1.000 Neurons (somente no plano Workers Paid). |
| **Google Gemini Image Generation / Imagen 3** (`gemini-2.0-flash-preview-image-generation`) | Disponível para testes via Google AI Studio com chave Gemini (`responseModalities: ["IMAGE", "TEXT"]`). | Permitido conforme termos da Gemini API (inclui marca invisível SynthID). | `https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent` | Cobrado por imagem gerada quando em faturamento Tier 1+. |
| **OpenAI Images** (`gpt-image-1` / `dall-e-3`) | Sem plano gratuito (requer saldo de créditos OpenAI). | 100% comercial. | `https://api.openai.com/v1/images/generations` | Aproximadamente US$ 0,02 a US$ 0,08 por imagem dependendo da resolução. |

---

## 3. APIs de Geração de Vídeos (`capability: video`)

| Provedor / Modelo | Plano Gratuito / Limites de Teste | Uso Comercial | Endpoint Oficial / Contrato | Custos Potenciais (Plano Pago) |
| :--- | :--- | :--- | :--- | :--- |
| **Google Veo 2.0** (`veo-2.0-generate-001`) | Operação assíncrona (`predictLongRunning`) via Gemini API / Vertex AI. Geralmente exige conta com faturamento (Tier 1+) ou créditos de avaliação Google Cloud. | Permitido com marca SynthID. | `https://generativelanguage.googleapis.com/v1beta/models/veo-2.0-generate-001:predictLongRunning` | Cobrado por segundo de vídeo gerado; deve ser usado com parcimônia e limites de cota configurados na Central de APIs. |
| **Luma Dream Machine / Ray 2** (`ray-2-flash`) | Exige créditos de API (planos pagos por uso). | Permitido nos planos de API comercial. | `https://api.lumalabs.ai/dream-machine/v1/generations` (assíncrono com polling) | Cobrado por geração concluída. |

---

## 4. Integrações Oficiais de Redes Sociais (`capability: social`)

1. **Instagram ([Instagram Graph API — Content Publishing](https://developers.facebook.com/documentation/instagram-platform/content-publishing)):**
   - **Requisitos:** Conta Profissional do Instagram (Business ou Creator) vinculada a uma Página do Facebook, App Meta configurado e token OAuth com escopos `instagram_basic` e `instagram_content_publish`.
   - **Limites Oficiais:** Até 50 publicações (containers publicados) por janela móvel de 24 horas por conta; carrosséis suportam até 10 itens.
   - **Fluxo:** Criação de container de mídia (`/media`) seguida da publicação (`/media_publish`).
2. **Facebook ([Pages Graph API](https://developers.facebook.com/docs/pages-api/)):**
   - **Requisitos:** Page Access Token e permissão `pages_manage_posts` e `pages_read_engagement`.
3. **TikTok ([TikTok Content Posting API v2](https://developers.tiktok.com/doc/content-posting-api-get-started)):**
   - **Requisitos:** Conta de desenvolvedor no TikTok for Developers, token OAuth do usuário (`open_id`) e escopos `video.upload` / `video.publish`.
   - **Finalização Manual vs. Direct Post:** Apps ainda não auditados para o escopo `video.publish` (Direct Post) utilizam o fluxo de envio para a caixa de entrada (*Inbox Upload*), onde o aplicativo envia o vídeo e o criador recebe uma notificação no aplicativo oficial do TikTok para concluir a postagem manualmente. O aplicativo Automação de Conteúdo R3 identifica e sinaliza claramente essa exigência na tela de contas e postagens.

> **Garantia de Limites de Autorização (Seção 20):** Nenhum serviço pago foi contratado, nenhuma cobrança foi gerada e nenhuma publicação externa real é disparada sem ação e autorização explícita do usuário.
