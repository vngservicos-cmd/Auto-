import 'package:flutter_test/flutter_test.dart';
import 'package:automacao_conteudo/models/api_provider.dart';
import 'package:automacao_conteudo/models/post_schedule.dart';
import 'package:automacao_conteudo/services/content_verification_service.dart';
import 'package:automacao_conteudo/services/production_director_service.dart';

void main() {
  group('R3 — Carrossel, Verificação Semestral, Multi-Capacidades e Diretor IA', () {
    test('garante frase obrigatória no 4º slide e preserva slides extras de publicidade', () {
      final slides = PostSchedule.ensureMandatoryFourthSlide([
        'Introdução do tema',
        'Desenvolvimento',
        'Conclusão',
        'Chamada final',
      ]);

      expect(slides, hasLength(4));
      expect(
        slides[3],
        contains('Gostou? Curta, compartilhe e comente para ajudar a trazer mais conteudos.'),
      );

      final schedule = PostSchedule(
        id: 'r3_carousel_test',
        network: 'Instagram',
        content: 'Conteúdo base',
        carouselSlides: slides,
        extraAdSlideTexts: const ['Slide Patrocinado 1'],
        scheduledAt: null,
        automatic: false,
        status: 'Rascunho',
        createdAt: DateTime.utc(2026, 11, 2),
      );

      final restored = PostSchedule.fromJson(schedule.toJson());
      expect(restored.totalCarouselSlidesCount, 5);
      expect(restored.extraAdSlideTexts.first, 'Slide Patrocinado 1');
    });

    test('agenda reavaliação exatamente 6 meses depois para Reavaliar mais tarde', () {
      final baseDate = DateTime(2026, 11, 2, 10, 30);
      final sixMonthsLater = ContentVerificationService.addSixMonths(baseDate);

      expect(sixMonthsLater.year, 2027);
      expect(sixMonthsLater.month, 5);
      expect(sixMonthsLater.day, 2);
    });

    test('evita duplicação de provedores que atendem múltiplas capacidades', () {
      final provider = ApiProvider(
        id: 'gemini_multi_1',
        name: 'Google Gemini Unificado',
        provider: 'Google',
        capability: 'text',
        capabilities: const ['text', 'image', 'video'],
        dailyQuotaLimit: 100,
        usedQuotaToday: 10,
      );

      expect(provider.supportsCapability('text'), isTrue);
      expect(provider.supportsCapability('image'), isTrue);
      expect(provider.supportsCapability('video'), isTrue);
      expect(provider.hasQuotaAvailable, isTrue);
    });

    test('Diretor de Produção divide roteiro em 4 cenas com continuidade visual', () {
      final director = ProductionDirectorService();
      final plan = director.buildPlanFromTopic(
        topicName: 'Automação Inteligente',
        scriptOrIdea: 'Como organizar publicações com segurança',
      );

      expect(plan.scenes, hasLength(4));
      expect(
        plan.scenes[3].subtitleText,
        contains('Gostou? Curta, compartilhe e comente'),
      );
    });
  });
}
