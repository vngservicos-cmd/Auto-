import '../models/api_fallback_event.dart';
import '../models/api_provider.dart';
import 'api_fallback_history_service.dart';
import 'api_provider_adapter.dart';
import 'api_provider_credentials_storage.dart';
import 'api_provider_registry.dart';

/// Resultado detalhado de uma geração de conteúdo.
class ContentGenerationResult {
  final String text;
  final String accountName;
  final String providerName;
  final String modelId;
  final bool usedFallback;
  final List<String> sourcesIncluded;

  const ContentGenerationResult({
    required this.text,
    required this.accountName,
    required this.providerName,
    required this.modelId,
    this.usedFallback = false,
    this.sourcesIncluded = const [],
  });
}

class ContentGenerationService {
  ContentGenerationService({
    ApiProviderRegistry? providerRegistry,
    ApiProviderCredentialsStorage? credentialsStorage,
    ApiProviderAdapterRegistry? adapterRegistry,
    ApiFallbackHistoryService? fallbackHistoryService,
  })  : _providerRegistry = providerRegistry ?? ApiProviderRegistry(),
        _credentialsStorage =
            credentialsStorage ?? ApiProviderCredentialsStorage(),
        _adapterRegistry = adapterRegistry ?? ApiProviderAdapterRegistry(),
        _fallbackHistory =
            fallbackHistoryService ?? ApiFallbackHistoryService(),
        _ownsAdapterRegistry = adapterRegistry == null;

  final ApiProviderRegistry _providerRegistry;
  final ApiProviderCredentialsStorage _credentialsStorage;
  final ApiProviderAdapterRegistry _adapterRegistry;
  final ApiFallbackHistoryService _fallbackHistory;
  final bool _ownsAdapterRegistry;

  bool _disposed = false;

  static const String _avisoPadrao = '''

Aviso importante:

Este conteúdo foi produzido com auxílio de inteligência artificial e tem finalidade informativa e reflexiva. Não deve ser considerado, por si só, uma fonte definitiva de informação, material didático validado ou referência para estudos acadêmicos. As informações apresentadas podem conter imprecisões e devem ser verificadas em fontes confiáveis quando utilizadas para estudos, pesquisas ou tomadas de decisão.

''';

  String _adicionarAviso(String texto, List<String> fontes) {
    var conteudo = texto.trim();

    if (fontes.isNotEmpty &&
        !conteudo.toLowerCase().contains('fontes consultadas:')) {
      final listaFontes = fontes.map((f) => '- $f').join('\n');
      conteudo = '$conteudo\n\nFontes consultadas:\n$listaFontes';
    }

    if (conteudo.toLowerCase().contains(
          'este conteúdo foi produzido com auxílio de inteligência artificial',
        )) {
      return conteudo;
    }

    return '$conteudo\n\n${_avisoPadrao.trim()}';
  }

  void _checkNotDisposed() {
    if (_disposed) {
      throw Exception(
        'O serviço de geração já foi encerrado. Reabra a tela e tente novamente.',
      );
    }
  }

  /// Método original preservado para manter compatibilidade.
  Future<String> generate(String prompt) async {
    final result = await generateDetailed(prompt);
    return result.text;
  }

  /// Gera conteúdo e informa qual conta, provedor e modelo
  /// foram efetivamente utilizados, permitindo selecionar um provedor preferencial
  /// e aplicando fallback automático quando a opção principal falha.
  Future<ContentGenerationResult> generateDetailed(
    String prompt, {
    String? preferredAccountId,
    List<String> researchSources = const [],
  }) async {
    _checkNotDisposed();

    final normalizedPrompt = prompt.trim();

    if (normalizedPrompt.isEmpty) {
      throw Exception('Digite uma instrução para gerar o conteúdo.');
    }

    if (normalizedPrompt.length > 12000) {
      throw Exception(
        'O texto da solicitação ultrapassa 12.000 caracteres.',
      );
    }

    List<ApiProvider> accounts;

    try {
      accounts = await _providerRegistry.getAll();
    } catch (_) {
      throw Exception(
        'Não foi possível carregar as contas da Central de APIs. '
        'Verifique o armazenamento e tente novamente.',
      );
    }

    _checkNotDisposed();

    final compatibleAccounts = accounts
        .where(
          (account) =>
              account.active &&
              account.supportsCapability('text') &&
              account.hasQuotaAvailable,
        )
        .toList()
      ..sort((a, b) {
        if (preferredAccountId != null && preferredAccountId.isNotEmpty) {
          if (a.id == preferredAccountId && b.id != preferredAccountId) {
            return -1;
          }
          if (b.id == preferredAccountId && a.id != preferredAccountId) {
            return 1;
          }
        }

        final priorityComparison = a.priority.compareTo(b.priority);

        if (priorityComparison != 0) {
          return priorityComparison;
        }

        final dateComparison = a.createdAt.compareTo(b.createdAt);

        if (dateComparison != 0) {
          return dateComparison;
        }

        return a.id.compareTo(b.id);
      });

    if (compatibleAccounts.isEmpty) {
      throw Exception(
        'Nenhuma conta ativa, com cota disponível e compatível com geração de texto '
        'foi encontrada na Central de APIs.',
      );
    }

    final failures = <String>[];
    ApiProvider? firstFailedAccount;

    for (var i = 0; i < compatibleAccounts.length; i++) {
      final account = compatibleAccounts[i];
      _checkNotDisposed();

      final adapter = _adapterRegistry.find(
        account.provider.trim().toLowerCase(),
      );

      if (adapter == null) {
        failures.add(
          '${account.name}: fornecedor ainda não possui integração disponível.',
        );
        firstFailedAccount ??= account;
        continue;
      }

      final modelId = account.modelId?.trim() ?? '';

      if (modelId.isEmpty) {
        failures.add(
          '${account.name}: nenhum modelo foi configurado.',
        );
        firstFailedAccount ??= account;
        continue;
      }

      String? apiKey;

      try {
        apiKey = await _credentialsStorage.readCredential(account.id);
      } catch (_) {
        failures.add(
          '${account.name}: não foi possível acessar a credencial armazenada.',
        );
        firstFailedAccount ??= account;
        continue;
      }

      _checkNotDisposed();

      if (apiKey == null || apiKey.trim().isEmpty) {
        failures.add(
          '${account.name}: credencial não encontrada.',
        );
        firstFailedAccount ??= account;
        continue;
      }

      try {
        final result = await adapter.generateContent(
          apiKey: apiKey,
          modelId: modelId,
          prompt: normalizedPrompt,
          endpointUrl: account.websiteUrl,
        );

        _checkNotDisposed();

        if (result.trim().isEmpty) {
          failures.add(
            '${account.name}: o fornecedor retornou um conteúdo vazio.',
          );
          firstFailedAccount ??= account;
          continue;
        }

        await _providerRegistry.recordExecutionOutcome(
          account.id,
          success: true,
        );

        final usedFallback = firstFailedAccount != null;
        if (usedFallback) {
          await _fallbackHistory.add(
            ApiFallbackEvent(
              capability: 'text',
              failedProviderId: firstFailedAccount.id,
              failedProviderName: firstFailedAccount.name,
              selectedProviderId: account.id,
              selectedProviderName: account.name,
              action: 'useFreeAlternative',
              message:
                  'Fallback automático executado de ${firstFailedAccount.name} para ${account.name}.',
              occurredAt: DateTime.now(),
            ),
          );
        }

        return ContentGenerationResult(
          text: _adicionarAviso(result, researchSources),
          accountName: account.name,
          providerName: account.provider,
          modelId: modelId,
          usedFallback: usedFallback,
          sourcesIncluded: researchSources,
        );
      } on ApiProviderException catch (error) {
        failures.add('${account.name}: ${error.message}');
        firstFailedAccount ??= account;
        await _providerRegistry.recordExecutionOutcome(
          account.id,
          success: false,
          errorMessage: error.message,
          quotaExceeded: error.statusCode == 429,
        );

        if (!error.shouldTryNextAccount) {
          throw Exception(
            'A geração foi interrompida.\n${error.message}',
          );
        }
      } catch (err) {
        failures.add(
          '${account.name}: ocorreu uma falha inesperada durante a geração.',
        );
        firstFailedAccount ??= account;
        await _providerRegistry.recordExecutionOutcome(
          account.id,
          success: false,
          errorMessage: err.toString(),
        );
      }
    }

    _checkNotDisposed();

    throw Exception(
      'Não foi possível gerar o conteúdo com as contas disponíveis.\n\n'
      '${failures.join('\n')}',
    );
  }

  void dispose() {
    if (_disposed) return;

    _disposed = true;

    if (_ownsAdapterRegistry) {
      _adapterRegistry.dispose();
    }
  }
}
