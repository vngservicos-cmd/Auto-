import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/media_item.dart';

class MediaLibraryService {
  static const String _storageKey = 'media_library_items_v1';
  static const int maxLocalCacheBytes = 50 * 1024 * 1024; // 50 MB limite padrão

  Future<List<MediaItem>> getAll() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_storageKey);
    if (raw == null || raw.isEmpty) {
      return [];
    }
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return [];
      final items = decoded
          .whereType<Map>()
          .map((e) => MediaItem.fromJson(Map<String, dynamic>.from(e)))
          .toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return items;
    } catch (_) {
      return [];
    }
  }

  Future<bool> saveAll(List<MediaItem> items) async {
    final prefs = await SharedPreferences.getInstance();
    final encoded = jsonEncode(items.map((e) => e.toJson()).toList());
    return prefs.setString(_storageKey, encoded);
  }

  Future<bool> add(MediaItem item) async {
    final items = await getAll();
    items.removeWhere((existing) => existing.id == item.id);
    items.insert(0, item);
    await _enforceCacheBudget(items);
    return saveAll(items);
  }

  Future<bool> remove(String id) async {
    final items = await getAll();
    final before = items.length;
    items.removeWhere((item) => item.id == id);
    if (items.length == before) return false;
    return saveAll(items);
  }

  /// Mantém o cache local controlado sem excluir os metadados/URLs na nuvem.
  Future<int> pruneLocalCache() async {
    final items = await getAll();
    var freedCount = 0;
    for (var i = 0; i < items.length; i++) {
      if (items[i].cachedLocally && !items[i].url.startsWith('data:')) {
        items[i] = items[i].copyWith(
          cachedLocally: false,
          cloudSynced: true,
        );
        freedCount++;
      }
    }
    await saveAll(items);
    return freedCount;
  }

  Future<int> totalCachedBytes() async {
    final items = await getAll();
    return items
        .where((item) => item.cachedLocally)
        .fold<int>(0, (sum, item) => sum + item.estimatedSizeBytes);
  }

  Future<void> _enforceCacheBudget(List<MediaItem> items) async {
    var runningBytes = 0;
    for (var i = 0; i < items.length; i++) {
      if (items[i].cachedLocally) {
        runningBytes += items[i].estimatedSizeBytes;
        if (runningBytes > maxLocalCacheBytes &&
            !items[i].url.startsWith('data:')) {
          items[i] = items[i].copyWith(
            cachedLocally: false,
            cloudSynced: true,
          );
        }
      }
    }
  }
}
