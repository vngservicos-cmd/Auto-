import 'dart:async';

import '../models/automation_task.dart';
import '../models/post_schedule.dart';
import 'automation_task_service.dart';
import 'content_generation_service.dart';
import 'content_verification_service.dart';
import 'media_generation_service.dart';
import 'post_schedule_service.dart';

class AutomationTaskExecutor {
  static const String _captionNotice =
      'Aviso importante: Este conteúdo foi produzido com auxílio de inteligência artificial e tem finalidade informativa e reflexiva. Não deve ser considerado, por si só, uma fonte definitiva de informação, material didático validado ou referência para estudos acadêmicos. As informações apresentadas podem conter imprecisões e devem ser verificadas em fontes confiáveis quando utilizadas para estudos, pesquisas ou tomadas de decisão.';

  static const String mandatorySlideFourText =
      PostSchedule.mandatoryFourthSlidePhrase;

  AutomationTaskExecutor({
    AutomationTaskService? taskService,
    ContentGenerationService? contentGenerationService,
    PostScheduleService? postScheduleService,
    MediaGenerationService? mediaGenerationService,
    ContentVerificationService? verificationService,
  })  : _taskService = taskService ?? AutomationTaskService(),
        _postScheduleService = postScheduleService ?? PostScheduleService(),
        _verificationService =
            verificationService ?? ContentVerificationService(),
        _ownsContentGenerationService = contentGenerationService == null,
        _contentGenerationService =
            contentGenerationService ?? ContentGenerationService(),
        _mediaGenerationService =
            mediaGenerationService ?? MediaGenerationService(),
        _ownsMediaGenerationService = mediaGenerationService == null;

  final AutomationTaskService _taskService;
  final PostScheduleService _postScheduleService;
  final ContentVerificationService _verificationService;
  final ContentGenerationService _contentGenerationService;
  final MediaGenerationService _mediaGenerationService;
  final bool _ownsContentGenerationService;
  final bool _ownsMediaGenerationService;

  bool _isRunning = false;
  bool _isDisposed = false;

  bool get isRunning => _isRunning;

  bool get isDisposed => _isDisposed;

  /// Executa diretamente uma tarefa específica criada pelo Gerador ou Central.
  Future<bool> executeTask(String taskId) async {
    _checkNotDisposed();
    if (_isRunning || taskId.trim().isEmpty) return false;
    _isRunning = true;
    try {
      final task = await _taskService.getById(taskId);
      if (task == null || !task.isReady) {
        return false;
      }
      if (task.type == AutomationTaskType.review) {
        return _executeReviewTask(task);
      }
      if (task.type != AutomationTaskType.contentGeneration) {
        return false;
      }
      return _executeContentGeneration(task);
    } finally {
      _isRunning = false;
    }
  }

  /// Executa uma tarefa pronta por vez.
  Future<bool> runNext() async {
    _checkNotDisposed();

    if (_isRunning) {
      return false;
    }

    _isRunning = true;

    try {
      final tasks = await _taskService.getReadyTasks(limit: 50);

      for (final task in tasks) {
        _checkNotDisposed();

        if (task.type == AutomationTaskType.review) {
          final reviewed = await _executeReviewTask(task);
          if (reviewed) return true;
          continue;
        }

        if (task.type != AutomationTaskType.contentGeneration) {
          continue;
        }

        final executed = await _executeContentGeneration(task);

        if (executed) {
          return true;
        }
      }

      return false;
    } finally {
      _isRunning = false;
    }
  }

  /// Executa várias tarefas sequencialmente.
  Future<int> runBatch({
    int limit = 5,
  }) async {
    _checkNotDisposed();

    if (limit <= 0 || _isRunning) {
      return 0;
    }

    var executedCount = 0;

    for (var i = 0; i < limit; i++) {
      _checkNotDisposed();

      final executed = await runNext();

      if (!executed) {
        break;
      }

      executedCount++;
    }

    return executedCount;
  }

  Future<bool> _executeReviewTask(AutomationTask task) async {
    final marked = await _taskService.markRunning(task.id);
    if (!marked) return false;
    final now = DateTime.now();
    final postId = task.publicationId ?? task.payload['postId']?.toString();
    if (postId != null && postId.isNotEmpty) {
      final schedule = await _postScheduleService.getById(postId);
      if (schedule != null) {
        await _postScheduleService.upsert(
          schedule.copyWith(
            approvalStatus: 'Pendente',
            scheduleStatus: 'Reavaliação semestral pronta para revisão',
            status: 'Pendente de revisão após 6 meses',
            updatedAt: now,
          ),
        );
      }
    }
    await _taskService.markCompleted(task.id);
    return true;
  }

  Future<bool> _executeContentGeneration(
    AutomationTask task,
  ) async {
    _checkNotDisposed();

    final markedRunning = await _taskService.markRunning(task.id);

    if (!markedRunning) {
      return false;
    }

    final runningTask = await _taskService.getById(task.id);

    if (runningTask == null ||
        runningTask.status != AutomationTaskStatus.running) {
      return false;
    }

    final startedAt = runningTask.startedAt ?? DateTime.now();
    final attemptNumber = runningTask.attemptCount + 1;

    try {
      _checkNotDisposed();

      final runningExecution = AutomationTaskExecution(
        attemptNumber: attemptNumber,
        startedAt: startedAt,
        status: AutomationTaskExecutionStatus.running,
      );

      final history = List<AutomationTaskExecution>.from(
        runningTask.executionHistory,
      )..add(runningExecution);

      final taskWithHistory = runningTask.copyWith(
        executionHistory: history,
        updatedAt: startedAt,
      );

      final historySaved = await _taskService.update(taskWithHistory);

      if (!historySaved) {
        await _registerFailure(
          task.id,
          'Não foi possível salvar o histórico inicial da execução.',
          attemptNumber: attemptNumber,
          startedAt: startedAt,
        );

        return true;
      }

      final prompt =
          taskWithHistory.payload['prompt']?.toString().trim() ?? '';

      if (prompt.isEmpty) {
        await _registerFailure(
          task.id,
          'A tarefa não possui um prompt válido.',
          attemptNumber: attemptNumber,
          startedAt: startedAt,
        );

        return true;
      }

      final preferredTextAccountId =
          taskWithHistory.payload['preferredTextAccountId']?.toString();
      final preferredImageAccountId =
          taskWithHistory.payload['preferredImageAccountId']?.toString();
      final preferredVideoAccountId =
          taskWithHistory.payload['preferredVideoAccountId']?.toString();

      final rawSources = taskWithHistory.payload['evidenceSources'];
      final evidenceSources = rawSources is List
          ? rawSources.map((e) => e.toString()).toList()
          : <String>[];

      final result = await _contentGenerationService.generateDetailed(
        prompt,
        preferredAccountId: preferredTextAccountId,
        researchSources: evidenceSources,
      );

      _checkNotDisposed();

      final currentTask = await _taskService.getById(task.id);

      if (currentTask == null ||
          currentTask.status != AutomationTaskStatus.running) {
        return false;
      }

      final completedAt = DateTime.now();

      final updatedHistory = List<AutomationTaskExecution>.from(
        currentTask.executionHistory,
      );

      final executionIndex = updatedHistory.lastIndexWhere(
        (execution) =>
            execution.attemptNumber == attemptNumber &&
            execution.status == AutomationTaskExecutionStatus.running,
      );

      if (executionIndex == -1) {
        await _registerFailure(
          task.id,
          'O histórico da execução não foi encontrado para conclusão.',
          attemptNumber: attemptNumber,
          startedAt: startedAt,
          providerName: result.providerName,
        );

        return true;
      }

      updatedHistory[executionIndex] = AutomationTaskExecution(
        attemptNumber: attemptNumber,
        startedAt: startedAt,
        completedAt: completedAt,
        status: AutomationTaskExecutionStatus.completed,
        providerName: result.providerName,
      );

      final updatedPayload = Map<String, dynamic>.from(
        currentTask.payload,
      );

      updatedPayload['result'] = result.text;
      updatedPayload['resultGeneratedAt'] = completedAt.toIso8601String();
      updatedPayload['providerName'] = result.providerName;
      updatedPayload['providerAccountName'] = result.accountName;
      updatedPayload['modelId'] = result.modelId;
      updatedPayload['usedFallback'] = result.usedFallback;

      final format = (updatedPayload['format'] ?? 'Legenda').toString();
      final needsImages =
          format == 'Carrossel' || format == 'Publicação completa';
      final needsVideo =
          format == 'Roteiro para vídeo' || format == 'Publicação completa';
      final missingAssets = <String>[];
      final quantity = updatedPayload['quantity'] is num
          ? (updatedPayload['quantity'] as num).toInt()
          : 1;
      final publicationBlocks = _extractPublications(result.text, quantity);
      final publicationMedia = <Map<String, dynamic>>[];

      for (var publicationIndex = 0;
          publicationIndex < publicationBlocks.length;
          publicationIndex++) {
        final publicationText = publicationBlocks[publicationIndex];
        final media = <String, dynamic>{};
        if (needsImages) {
          try {
            final slides = _extractCarouselSlides(publicationText);
            if (slides.length != 4) {
              throw FormatException(
                'A publicação ${publicationIndex + 1} precisa conter exatamente quatro blocos SLIDE 1 a SLIDE 4.',
              );
            }
            final imagePrompts = slides.asMap().entries.map((entry) =>
                'Crie uma imagem vertical para carrossel de rede social. Tema: ${updatedPayload['topicName'] ?? ''}. Publicação ${publicationIndex + 1}. Slide ${entry.key + 1}/4. Conceito visual: ${entry.value}. Não inclua texto, letras, marcas ou marcas-dagua. Mantenha identidade visual consistente entre os quatro slides desta publicação.').toList();
            media['carouselImageUrls'] =
                await _mediaGenerationService.generateImages(
              prompts: imagePrompts,
              aspectRatio: '4:5',
              preferredAccountId: preferredImageAccountId,
              topicId: currentTask.topicId,
              topicName: updatedPayload['topicName']?.toString(),
            );
          } catch (error) {
            media['imageGenerationError'] = _safeErrorMessage(error);
            if (!missingAssets.contains('imagem')) missingAssets.add('imagem');
          }
        }
        if (needsVideo) {
          try {
            final script =
                _extractSection(publicationText, 'ROTEIRO') ?? publicationText;
            final videoAsset = await _mediaGenerationService.generateVideoAsset(
              prompt:
                  'Produza um vídeo vertical 9:16, com áudio, cenas e transições adequadas para Reels/TikTok. Tema: ${updatedPayload['topicName'] ?? ''}. Publicação ${publicationIndex + 1}. Roteiro: $script',
              preferredAccountId: preferredVideoAccountId,
              topicId: currentTask.topicId,
              topicName: updatedPayload['topicName']?.toString(),
            );
            media['videoUrl'] = videoAsset.url;
            media['videoApiAccountId'] = videoAsset.accountId;
            media['videoApiProvider'] = videoAsset.provider;
          } catch (error) {
            media['videoGenerationError'] = _safeErrorMessage(error);
            if (!missingAssets.contains('vídeo')) missingAssets.add('vídeo');
          }
        }
        publicationMedia.add(media);
      }
      updatedPayload['publicationMedia'] = publicationMedia;
      if (publicationMedia.isNotEmpty) {
        updatedPayload['carouselImageUrls'] =
            publicationMedia.first['carouselImageUrls'] ?? const <String>[];
        updatedPayload['videoUrl'] = publicationMedia.first['videoUrl'];
        updatedPayload['videoApiAccountId'] =
            publicationMedia.first['videoApiAccountId'];
        updatedPayload['videoApiProvider'] =
            publicationMedia.first['videoApiProvider'];
      }
      if (missingAssets.isNotEmpty) {
        updatedPayload['generatedText'] = result.text;
        updatedPayload['missingAssets'] = missingAssets;
        updatedPayload['generationStage'] = 'awaiting_assets';
        await _taskService.update(
          currentTask.copyWith(payload: updatedPayload),
        );
        updatedPayload['draftCount'] = await _createApprovalDrafts(
          currentTask,
          updatedPayload,
          result.text,
          evidenceSources: evidenceSources,
        );
        await _taskService.update(
          currentTask.copyWith(payload: updatedPayload),
        );
        final draftCount = updatedPayload['draftCount'] as int;
        final routingMessage = draftCount > 0
            ? ' Foram criados $draftCount rascunho(s) em Configuração de Postagens, todos pendentes e bloqueados para aprovação.'
            : ' Nenhum rascunho foi criado porque não há conta compatível selecionada.';
        final mediaErrors = publicationMedia
            .expand((media) => [
                  media['imageGenerationError'],
                  media['videoGenerationError']
                ])
            .whereType<String>()
            .where((value) => value.trim().isNotEmpty)
            .join(' | ');
        await _registerFailure(
          task.id,
          'O texto foi gerado, mas a geração de ${missingAssets.join(' e ')} não foi concluída. $mediaErrors.$routingMessage O conteúdo permanece incompleto e não pode ser aprovado nem publicado.',
          attemptNumber: attemptNumber,
          startedAt: startedAt,
          providerName: result.providerName,
        );
        return true;
      }

      updatedPayload['generatedText'] = result.text;
      updatedPayload['generationStage'] = 'text_completed';
      await _taskService.update(
        currentTask.copyWith(payload: updatedPayload),
      );
      updatedPayload['draftCount'] = await _createApprovalDrafts(
        currentTask,
        updatedPayload,
        result.text,
        evidenceSources: evidenceSources,
      );

      final completedTask = currentTask.copyWith(
        status: AutomationTaskStatus.completed,
        payload: updatedPayload,
        attemptCount: attemptNumber,
        executionHistory: updatedHistory,
        completedAt: completedAt,
        updatedAt: completedAt,
        lastError: null,
        nextAttemptAt: null,
      );

      final saved = await _taskService.update(completedTask);

      if (saved) {
        return true;
      }

      await _registerFailure(
        task.id,
        'Não foi possível salvar o resultado da geração.',
        attemptNumber: attemptNumber,
        startedAt: startedAt,
        providerName: result.providerName,
      );

      return true;
    } catch (error) {
      if (_isDisposed) {
        return false;
      }

      await _registerFailure(
        task.id,
        _safeErrorMessage(error),
        attemptNumber: attemptNumber,
        startedAt: startedAt,
      );

      return true;
    }
  }

  Future<int> _createApprovalDrafts(
    AutomationTask task,
    Map<String, dynamic> payload,
    String generatedText, {
    List<String> evidenceSources = const [],
  }) async {
    final rawAccounts = payload['targetAccounts'];
    final format = (payload['format'] ?? 'Legenda').toString();
    final quantity = payload['quantity'] is num
        ? (payload['quantity'] as num).toInt()
        : 1;
    final publications = _extractPublications(generatedText, quantity);
    if (rawAccounts is! List) return 0;

    final rawExtraTexts = payload['extraAdSlideTexts'];
    final extraAdTexts = rawExtraTexts is List
        ? rawExtraTexts.map((e) => e.toString()).toList()
        : <String>[];
    final rawExtraImgs = payload['extraAdSlideImageUrls'];
    final extraAdImgs = rawExtraImgs is List
        ? rawExtraImgs.map((e) => e.toString()).toList()
        : <String>[];

    var createdCount = 0;
    final now = DateTime.now();
    final topicName = (payload['topicName'] ?? '').toString();

    for (final item in rawAccounts) {
      if (item is! Map) continue;
      final account = Map<String, dynamic>.from(item);
      if (account['active'] != true) continue;

      final accountId = (account['id'] ?? '').toString().trim();
      final network = (account['platform'] ?? account['networkId'] ?? '')
          .toString()
          .trim();
      if (accountId.isEmpty || network.isEmpty) continue;

      final formats = account['formats'];
      final acceptedFormats = formats is List
          ? formats.map((value) => value.toString()).toSet()
          : <String>{};
      final accountFormat =
          format == 'Roteiro para vídeo' ? 'Vídeo' : format;
      if (acceptedFormats.isNotEmpty &&
          !acceptedFormats.contains(accountFormat)) {
        continue;
      }

      for (var index = 0; index < publications.length; index++) {
        final publicationText = publications[index];
        final extractedCaption = _extractCaption(publicationText);
        final captionSource = format == 'Legenda' && extractedCaption.isEmpty
            ? publicationText
            : extractedCaption;
        final caption = _ensureCaptionNotice(captionSource);
        final rawSlides = _extractCarouselSlides(publicationText);
        final slides = rawSlides.isNotEmpty
            ? PostSchedule.ensureMandatoryFourthSlide(rawSlides)
            : <String>[];
        final rawPublicationMedia = payload['publicationMedia'];
        final publicationMedia = rawPublicationMedia is List &&
                index < rawPublicationMedia.length &&
                rawPublicationMedia[index] is Map
            ? Map<String, dynamic>.from(rawPublicationMedia[index] as Map)
            : <String, dynamic>{};
        final rawImages = publicationMedia['carouselImageUrls'] ??
            payload['carouselImageUrls'];
        final imageUrls = rawImages is List
            ? rawImages.map((item) => item.toString()).toList()
            : <String>[];
        final script = format == 'Roteiro para vídeo' ||
                format == 'Publicação completa'
            ? _extractSection(publicationText, 'ROTEIRO') ??
                (format == 'Roteiro para vídeo' ? publicationText : null)
            : null;

        final verificationReport = _verificationService.verifyContent(
          content: '$caption\n$publicationText',
          explicitSources: evidenceSources,
        );

        final schedule = PostSchedule(
          id: '${task.id}_${accountId}_${index + 1}',
          network: network,
          content: publicationText,
          caption: caption,
          contentFormat: format,
          topicId: task.topicId,
          topicName: topicName,
          accountId: accountId,
          publicationGroupId: task.id,
          carouselSlides: slides,
          carouselImageUrls: imageUrls,
          extraAdSlideTexts: extraAdTexts,
          extraAdSlideImageUrls: extraAdImgs,
          videoUrl: (publicationMedia['videoUrl'] ?? payload['videoUrl'])
              ?.toString(),
          videoApiAccountId: (publicationMedia['videoApiAccountId'] ??
                  payload['videoApiAccountId'])
              ?.toString(),
          videoApiProvider: (publicationMedia['videoApiProvider'] ??
                  payload['videoApiProvider'])
              ?.toString(),
          videoScript: script,
          evidenceSources: verificationReport.detectedSources,
          hasSufficientEvidence: verificationReport.hasSufficientEvidence,
          requiresManualFinalization:
              network.toLowerCase().contains('tiktok') &&
                  account['tiktokDirectPostApproved'] != true,
          lastError: [
            publicationMedia['imageGenerationError'],
            publicationMedia['videoGenerationError']
          ]
              .whereType<String>()
              .where((value) => value.trim().isNotEmpty)
              .join(' | '),
          scheduledAt: null,
          scheduleStatus: 'Aguardando aprovação',
          approvalStatus: 'Pendente',
          automatic: false,
          status: 'Pendente de aprovação',
          createdAt: now,
          updatedAt: now,
        );
        final saved = await _postScheduleService.upsert(schedule);
        if (!saved) {
          throw Exception(
            'Não foi possível encaminhar o conteúdo para Configuração de Postagens.',
          );
        }
        createdCount++;
      }
    }
    return createdCount;
  }

  List<String> _extractPublications(String text, int expectedQuantity) {
    final expression = RegExp(
      r'PUBLICAÇÃO\s*\d+\s*[:\-]\s*([\s\S]*?)(?=\n\s*PUBLICAÇÃO\s*\d+\s*[:\-]|$)',
      caseSensitive: false,
    );
    final parsed = expression
        .allMatches(text)
        .map((match) => match.group(1)?.trim() ?? '')
        .where((value) => value.isNotEmpty)
        .toList();
    if (parsed.isEmpty && expectedQuantity == 1 && text.trim().isNotEmpty) {
      return [text.trim()];
    }
    if (parsed.length != expectedQuantity) {
      throw FormatException(
        'A IA retornou ${parsed.length} bloco(s) de publicação, mas foram '
        'solicitados $expectedQuantity. O conteúdo foi preservado para revisão.',
      );
    }
    return parsed;
  }

  String _ensureCaptionNotice(String caption) {
    final value = caption.trim();
    if (value.isEmpty ||
        value.toLowerCase().contains(
              'este conteúdo foi produzido com auxílio de inteligência artificial',
            )) {
      return value;
    }
    return '$value\n\n$_captionNotice';
  }

  String _extractCaption(String text) {
    final match = RegExp(
      r'(?:LEGENDA|CAPTION)\s*[:\-]\s*([\s\S]*?)(?=\n\s*(?:SLIDE\s*1|ROTEIRO|CENAS)\b|$)',
      caseSensitive: false,
    ).firstMatch(text);
    return match?.group(1)?.trim() ?? '';
  }

  List<String> _extractCarouselSlides(String text) {
    final expression = RegExp(
      r'SLIDE\s*([1-4])\s*[:\-]\s*([\s\S]*?)(?=\n\s*SLIDE\s*[1-4]\s*[:\-]|$)',
      caseSensitive: false,
    );
    final matches = expression.allMatches(text).toList();
    final slides = <String>[];
    for (var number = 1; number <= 4; number++) {
      RegExpMatch? selectedMatch;
      for (final match in matches) {
        if (match.group(1) == '$number') {
          selectedMatch = match;
          break;
        }
      }
      if (selectedMatch != null) {
        var slideText = selectedMatch.group(2)?.trim() ?? '';
        final noticeIndex = slideText.toLowerCase().indexOf(
              'aviso importante:',
            );
        if (noticeIndex >= 0) {
          slideText = slideText.substring(0, noticeIndex).trim();
        }
        slides.add(slideText);
      }
    }
    if (slides.length == 4) {
      return PostSchedule.ensureMandatoryFourthSlide(slides);
    }
    return slides;
  }

  String? _extractSection(String text, String heading) {
    final match = RegExp(
      '${RegExp.escape(heading)}\\s*[:\\-]?\\s*([\\s\\S]*?)(?=\\n\\s*(?:LEGENDA|CARROSSEL|SLIDE|CENAS)\\b|$)',
      caseSensitive: false,
    ).firstMatch(text);
    final value = match?.group(1)?.trim();
    return value == null || value.isEmpty ? null : value;
  }

  Future<void> _registerFailure(
    String taskId,
    String message, {
    required int attemptNumber,
    required DateTime startedAt,
    String? providerName,
    bool disableRetry = false,
  }) async {
    _checkNotDisposed();

    var currentTask = await _taskService.getById(taskId);

    if (currentTask == null ||
        currentTask.status != AutomationTaskStatus.running) {
      return;
    }

    final failedAt = DateTime.now();

    if (disableRetry) {
      currentTask = currentTask.copyWith(
        maxAttempts: attemptNumber,
        updatedAt: failedAt,
      );
      await _taskService.update(currentTask);
    }

    final markedFailed = await _taskService.markFailed(
      taskId,
      error: message,
    );

    if (!markedFailed) {
      return;
    }

    final updatedTask = await _taskService.getById(taskId);

    if (updatedTask == null ||
        updatedTask.status != AutomationTaskStatus.failed) {
      return;
    }

    final history = List<AutomationTaskExecution>.from(
      updatedTask.executionHistory,
    );

    final runningIndex = history.lastIndexWhere(
      (execution) =>
          execution.attemptNumber == attemptNumber &&
          execution.status == AutomationTaskExecutionStatus.running,
    );

    final failedExecution = AutomationTaskExecution(
      attemptNumber: attemptNumber,
      startedAt: startedAt,
      completedAt: failedAt,
      status: AutomationTaskExecutionStatus.failed,
      providerName: providerName,
      error: message,
    );

    if (runningIndex == -1) {
      history.add(failedExecution);
    } else {
      history[runningIndex] = failedExecution;
    }

    await _taskService.update(
      updatedTask.copyWith(
        executionHistory: history,
        updatedAt: failedAt,
      ),
    );
  }

  String _safeErrorMessage(Object error) {
    final message = error.toString().trim();

    if (message.isEmpty) {
      return 'Não foi possível executar a tarefa.';
    }

    return message.length > 2000 ? message.substring(0, 2000) : message;
  }

  void _checkNotDisposed() {
    if (_isDisposed) {
      throw StateError(
        'O executor de tarefas já foi encerrado.',
      );
    }
  }

  /// Encerra o executor sem apagar tarefas ou dados armazenados.
  void dispose() {
    if (_isDisposed) {
      return;
    }

    _isDisposed = true;

    if (_ownsContentGenerationService) {
      _contentGenerationService.dispose();
    }
    if (_ownsMediaGenerationService) {
      _mediaGenerationService.dispose();
    }
  }
}
