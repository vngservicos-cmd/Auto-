import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/production_plan.dart';

class ProductionDirectorService {
  static const String _storageKey = 'production_director_plans_v1';

  Future<List<ProductionPlan>> getAll() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_storageKey);
    if (raw == null || raw.isEmpty) return [];
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return [];
      final plans = decoded
          .whereType<Map>()
          .map((item) => ProductionPlan.fromJson(Map<String, dynamic>.from(item)))
          .toList()
        ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
      return plans;
    } catch (_) {
      return [];
    }
  }

  Future<bool> saveAll(List<ProductionPlan> plans) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.setString(
      _storageKey,
      jsonEncode(plans.map((p) => p.toJson()).toList()),
    );
  }

  Future<bool> upsert(ProductionPlan plan) async {
    final plans = await getAll();
    final idx = plans.indexWhere((p) => p.id == plan.id);
    if (idx == -1) {
      plans.insert(0, plan);
    } else {
      plans[idx] = plan;
    }
    return saveAll(plans);
  }

  Future<bool> remove(String id) async {
    final plans = await getAll();
    plans.removeWhere((p) => p.id == id);
    return saveAll(plans);
  }

  /// Transforma um tema e roteiro/ideia em um Plano de Produção estruturado em 4 cenas
  /// com continuidade visual, prompts específicos por provedor, narração e legendas.
  ProductionPlan buildPlanFromTopic({
    required String topicName,
    String? topicId,
    required String scriptOrIdea,
    String visualStyle = 'Cinematográfico Moderno de Alto Contraste',
    String targetImageProvider = 'Google Gemini / Cloudflare FLUX.1',
    String targetVideoProvider = 'Google Veo 2.0 / Luma Ray 2',
  }) {
    final now = DateTime.now();
    final cleanIdea = scriptOrIdea.trim().isEmpty
        ? 'Apresentação prática e confiável sobre $topicName.'
        : scriptOrIdea.trim();

    final continuityGuide =
        'Estilo Visual Unificado: $visualStyle. Paleta consistente em todas as 4 cenas, '
        'iluminação suave direcional, enquadramento vertical 9:16 / 4:5 sem marcas-d\'água ou textos sobrepostos na imagem base.';

    final scenes = <ProductionScene>[
      ProductionScene(
        sceneNumber: 1,
        title: 'Cena 1 — Gancho Visual e Contextualização',
        visualDescription:
            'Plano fechado dinâmico apresentando o tema central de "$topicName" com estética $visualStyle.',
        imagePrompt:
            'Fotografia editorial vertical 4:5, tema $topicName, $visualStyle, iluminação dramática limpa, sem texto, alta nitidez.',
        videoPrompt:
            'Vídeo vertical 9:16, movimento suave de câmera (push-in) revelando o cenário principal de $topicName, estética $visualStyle.',
        narrationText:
            'Você sabia como $topicName pode transformar seus resultados quando aplicado com método? Veja este guia direto.',
        subtitleText: 'Como dominar $topicName na prática',
        durationSeconds: 7,
        targetImageProvider: targetImageProvider,
        targetVideoProvider: targetVideoProvider,
      ),
      ProductionScene(
        sceneNumber: 2,
        title: 'Cena 2 — Desenvolvimento e Evidências Práticas',
        visualDescription:
            'Demonstração visual dos conceitos-chave: $cleanIdea mantendo a mesma paleta e iluminação da Cena 1.',
        imagePrompt:
            'Composição vertical 4:5 demonstrando o processo de $topicName ($cleanIdea), estilo $visualStyle, continuidade cromática com a Cena 1, sem textos.',
        videoPrompt:
            'Vídeo 9:16 em plano médio mostrando a execução prática de $topicName com transição fluida e iluminação consistente ($visualStyle).',
        narrationText:
            'O ponto essencial está em estruturar cada etapa com base em dados verificados: $cleanIdea',
        subtitleText: 'Etapa principal e aplicação com evidências',
        durationSeconds: 9,
        targetImageProvider: targetImageProvider,
        targetVideoProvider: targetVideoProvider,
      ),
      ProductionScene(
        sceneNumber: 3,
        title: 'Cena 3 — Síntese e Benefício Real',
        visualDescription:
            'Comparativo visual claro do resultado alcançado com $topicName, mantendo o ambiente das cenas anteriores.',
        imagePrompt:
            'Imagem vertical 4:5 destacando o resultado organizado de $topicName, $visualStyle, profundidade de campo cinematográfica, sem letras.',
        videoPrompt:
            'Vídeo 9:16 com câmera estabilizada exibindo o resultado consolidado sobre $topicName, mantendo paleta e luz.',
        narrationText:
            'Com essa organização, você reduz falhas operacionais e mantém consistência em todas as publicações.',
        subtitleText: 'Resultado consistente e seguro',
        durationSeconds: 8,
        targetImageProvider: targetImageProvider,
        targetVideoProvider: targetVideoProvider,
      ),
      ProductionScene(
        sceneNumber: 4,
        title: 'Cena 4 — Encerramento e Chamada para Ação (CTA)',
        visualDescription:
            ' Quadro final limpo com espaço de respiro para o convite de engajamento obrigatório.',
        imagePrompt:
            'Fundo visual elegante vertical 4:5 para slide de encerramento sobre $topicName, estilo $visualStyle, alto contraste para leitura de texto, sem letras.',
        videoPrompt:
            'Vídeo 9:16 de encerramento suave convidando o público a interagir, estética $visualStyle.',
        narrationText:
            'Gostou? Curta, compartilhe e comente para ajudar a trazer mais conteudos.',
        subtitleText:
            'Gostou? Curta, compartilhe e comente para ajudar a trazer mais conteudos.',
        durationSeconds: 6,
        targetImageProvider: targetImageProvider,
        targetVideoProvider: targetVideoProvider,
      ),
    ];

    return ProductionPlan(
      id: 'plan_${now.microsecondsSinceEpoch}',
      topicId: topicId,
      topicName: topicName,
      title: 'Plano de Produção — $topicName',
      baseScript: cleanIdea,
      visualContinuityGuide: continuityGuide,
      scenes: scenes,
      createdAt: now,
      updatedAt: now,
    );
  }
}
