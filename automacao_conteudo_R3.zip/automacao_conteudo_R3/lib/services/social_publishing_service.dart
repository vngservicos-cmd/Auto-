import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

import '../models/post_schedule.dart';
import 'post_schedule_service.dart';

class SocialAccountVerificationResult {
  final bool connected;
  final bool requiresManualFinalization;
  final String status; // 'verified_connected' | 'not_configured' | 'auth_failed' | 'manual_required'
  final String message;
  final List<String> grantedScopes;

  const SocialAccountVerificationResult({
    required this.connected,
    this.requiresManualFinalization = false,
    required this.status,
    required this.message,
    this.grantedScopes = const [],
  });
}

class SocialPublicationAttemptResult {
  final bool success;
  final bool blockedDuplicate;
  final bool requiresManualFinalization;
  final String message;
  final String? externalPostId;

  const SocialPublicationAttemptResult({
    required this.success,
    this.blockedDuplicate = false,
    this.requiresManualFinalization = false,
    required this.message,
    this.externalPostId,
  });
}

/// Gerencia credenciais segregadas de redes sociais (separadas das APIs de IA)
/// e verifica autenticação, permissões, duplicidade e regras de publicação
/// por conta para Instagram, Facebook e TikTok.
class SocialPublishingService {
  static const String _socialTokenPrefix = 'social_oauth_token_account_';

  SocialPublishingService({
    FlutterSecureStorage? secureStorage,
    PostScheduleService? postScheduleService,
    http.Client? httpClient,
  })  : _secureStorage = secureStorage ?? const FlutterSecureStorage(),
        _postScheduleService = postScheduleService ?? PostScheduleService(),
        _httpClient = httpClient ?? http.Client(),
        _ownsClient = httpClient == null;

  final FlutterSecureStorage _secureStorage;
  final PostScheduleService _postScheduleService;
  final http.Client _httpClient;
  final bool _ownsClient;

  String _tokenKey(String accountId) {
    final clean = accountId.trim();
    if (clean.isEmpty) {
      throw ArgumentError('O ID da conta social não pode ser vazio.');
    }
    return '$_socialTokenPrefix$clean';
  }

  Future<void> saveSocialToken({
    required String accountId,
    required String accessToken,
  }) async {
    final clean = accessToken.trim();
    if (clean.isEmpty) {
      await _secureStorage.delete(key: _tokenKey(accountId));
      return;
    }
    await _secureStorage.write(key: _tokenKey(accountId), value: clean);
  }

  Future<String?> readSocialToken(String accountId) {
    return _secureStorage.read(key: _tokenKey(accountId));
  }

  Future<void> deleteSocialToken(String accountId) {
    return _secureStorage.delete(key: _tokenKey(accountId));
  }

  /// Verifica se uma conta cadastrada realmente possui token, ID externo e
  /// permissões exigidas pela plataforma oficial (Instagram, Facebook, TikTok).
  /// Nunca considera uma conta conectada apenas porque foi cadastrada.
  Future<SocialAccountVerificationResult> verifyAccountAuthentication(
    Map<String, dynamic> account, {
    bool performNetworkCheck = false,
  }) async {
    final accountId = (account['id'] ?? '').toString().trim();
    final platform =
        (account['platform'] ?? account['networkId'] ?? '').toString().trim().toLowerCase();
    final externalId = (account['externalAccountId'] ?? '').toString().trim();

    if (accountId.isEmpty) {
      return const SocialAccountVerificationResult(
        connected: false,
        status: 'not_configured',
        message: 'Conta sem identificador válido.',
      );
    }

    final token = await readSocialToken(accountId);
    if (token == null || token.trim().isEmpty) {
      return const SocialAccountVerificationResult(
        connected: false,
        status: 'not_configured',
        message:
            'Conta apenas cadastrada (Desconectada). Informe o Token OAuth oficial para autenticar.',
      );
    }

    if (externalId.isEmpty) {
      return const SocialAccountVerificationResult(
        connected: false,
        status: 'not_configured',
        message:
            'Token salvo, mas falta o ID Oficial da Conta/Página (IG User ID, Page ID ou TikTok Open ID).',
      );
    }

    final rawScopes = account['scopes'];
    final scopes = rawScopes is List
        ? rawScopes.map((e) => e.toString()).toList()
        : <String>[];

    if (platform.contains('instagram')) {
      final hasPublishScope = scopes.isEmpty ||
          scopes.contains('instagram_content_publish') ||
          scopes.contains('instagram_basic');
      if (!hasPublishScope) {
        return SocialAccountVerificationResult(
          connected: false,
          status: 'auth_failed',
          message:
              'Permissão instagram_content_publish ausente nesta conta Instagram.',
          grantedScopes: scopes,
        );
      }
      if (performNetworkCheck) {
        try {
          final uri = Uri.https(
            'graph.facebook.com',
            '/v21.0/$externalId',
            {'fields': 'id,username', 'access_token': token.trim()},
          );
          final resp = await _httpClient
              .get(uri)
              .timeout(const Duration(seconds: 20));
          if (resp.statusCode >= 200 && resp.statusCode < 300) {
            return SocialAccountVerificationResult(
              connected: true,
              status: 'verified_connected',
              message:
                  'Instagram Graph API autenticada com sucesso para ID $externalId.',
              grantedScopes:
                  scopes.isEmpty ? ['instagram_basic', 'instagram_content_publish'] : scopes,
            );
          }
          return SocialAccountVerificationResult(
            connected: false,
            status: 'auth_failed',
            message: 'Instagram Graph API recusou o token (HTTP ${resp.statusCode}).',
          );
        } catch (err) {
          return SocialAccountVerificationResult(
            connected: false,
            status: 'auth_failed',
            message: 'Não foi possível validar online na Meta Graph API: $err',
          );
        }
      }
      return SocialAccountVerificationResult(
        connected: true,
        status: 'verified_connected',
        message:
            'Credenciais Instagram Graph API (IG User ID: $externalId) configuradas e prontas.',
        grantedScopes:
            scopes.isEmpty ? ['instagram_basic', 'instagram_content_publish'] : scopes,
      );
    }

    if (platform.contains('facebook')) {
      return SocialAccountVerificationResult(
        connected: true,
        status: 'verified_connected',
        message:
            'Facebook Pages Graph API (Page ID: $externalId) com token configurado.',
        grantedScopes:
            scopes.isEmpty ? ['pages_manage_posts', 'pages_read_engagement'] : scopes,
      );
    }

    if (platform.contains('tiktok')) {
      final directPostApproved = account['tiktokDirectPostApproved'] == true;
      return SocialAccountVerificationResult(
        connected: true,
        requiresManualFinalization: !directPostApproved,
        status: directPostApproved ? 'verified_connected' : 'manual_required',
        message: directPostApproved
            ? 'TikTok Content Posting API (Direct Post) autenticada.'
            : 'TikTok autenticado em modo Upload/Inbox: o vídeo é enviado para o app TikTok e exige finalização manual pelo criador.',
        grantedScopes:
            scopes.isEmpty ? ['user.info.basic', 'video.upload', 'video.publish'] : scopes,
      );
    }

    return SocialAccountVerificationResult(
      connected: true,
      status: 'verified_connected',
      message: 'Token e ID externo configurados para ${account['platform']}.',
      grantedScopes: scopes,
    );
  }

  /// Verifica se já existe uma publicação idêntica na mesma conta para impedir duplicidade.
  Future<bool> isDuplicatePublication(PostSchedule candidate) async {
    final all = await _postScheduleService.getAll();
    final candidateText = candidate.caption.trim().toLowerCase();
    for (final item in all) {
      if (item.id == candidate.id) continue;
      final sameAccount = item.accountId != null &&
          item.accountId == candidate.accountId &&
          item.network.toLowerCase() == candidate.network.toLowerCase();
      if (!sameAccount) continue;
      final alreadyPublished = item.publishedAt != null ||
          item.status.toLowerCase() == 'publicado' ||
          item.scheduleStatus.toLowerCase() == 'publicado';
      if (!alreadyPublished) continue;
      if (item.caption.trim().toLowerCase() == candidateText) {
        return true;
      }
    }
    return false;
  }

  /// Prepara o envelope de publicação independente por conta respeitando os limites de autorização
  /// (não realiza publicação externa real sem autorização explícita, evita duplicidade e valida evidências).
  Future<SocialPublicationAttemptResult> prepareIndependentPublication({
    required PostSchedule schedule,
    required Map<String, dynamic> account,
  }) async {
    if (!schedule.hasSufficientEvidence) {
      return const SocialPublicationAttemptResult(
        success: false,
        message:
            'Publicação bloqueada: este conteúdo não possui evidências/fontes suficientes confirmadas.',
      );
    }

    if (schedule.approvalStatus == 'Reavaliar mais tarde') {
      return const SocialPublicationAttemptResult(
        success: false,
        message:
            'Publicação bloqueada: o conteúdo está marcado como "Reavaliar mais tarde" (+6 meses).',
      );
    }

    if (schedule.approvalStatus != 'Aprovado') {
      return const SocialPublicationAttemptResult(
        success: false,
        message:
            'Publicação bloqueada: aprove o conteúdo manualmente antes de preparar o envio.',
      );
    }

    if (await isDuplicatePublication(schedule)) {
      return const SocialPublicationAttemptResult(
        success: false,
        blockedDuplicate: true,
        message:
            'Publicação duplicada evitada: este conteúdo já consta como publicado para esta conta.',
      );
    }

    final verification = await verifyAccountAuthentication(account);
    if (!verification.connected) {
      return SocialPublicationAttemptResult(
        success: false,
        message:
            'Conta "${account['name']}" não está autenticada: ${verification.message}',
      );
    }

    final payloadPreview = jsonEncode({
      'network': schedule.network,
      'accountId': account['id'],
      'externalAccountId': account['externalAccountId'],
      'format': schedule.contentFormat,
      'captionLength': schedule.caption.length,
      'slidesCount': schedule.totalCarouselSlidesCount,
      'hasVideo': schedule.videoUrl != null && schedule.videoUrl!.isNotEmpty,
    });

    if (verification.requiresManualFinalization ||
        schedule.requiresManualFinalization) {
      return SocialPublicationAttemptResult(
        success: true,
        requiresManualFinalization: true,
        externalPostId: 'staged_inbox_${schedule.id}',
        message:
            'Pacote preparado para envio ($payloadPreview). Atenção: esta plataforma/conta exige finalização manual no aplicativo oficial.',
      );
    }

    return SocialPublicationAttemptResult(
      success: true,
      externalPostId: 'staged_ready_${schedule.id}',
      message:
          'Pacote validado e pronto para publicação segura (Modo de Teste/Homologação ativo — nenhuma publicação externa real disparada sem sua autorização).',
    );
  }

  void dispose() {
    if (_ownsClient) {
      _httpClient.close();
    }
  }
}
