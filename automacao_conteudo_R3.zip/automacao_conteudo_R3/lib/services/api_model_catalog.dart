class ApiModel {
  final String id;
  final String name;
  final String provider;
  final String capability;
  final bool active;
  final bool recommended;
  final bool freeTierAvailable;
  final bool commercialUseAllowed;
  final String? quotaSummary;
  final String? defaultEndpoint;

  const ApiModel({
    required this.id,
    required this.name,
    required this.provider,
    required this.capability,
    this.active = true,
    this.recommended = false,
    this.freeTierAvailable = true,
    this.commercialUseAllowed = true,
    this.quotaSummary,
    this.defaultEndpoint,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'provider': provider,
      'capability': capability,
      'active': active,
      'recommended': recommended,
      'freeTierAvailable': freeTierAvailable,
      'commercialUseAllowed': commercialUseAllowed,
      'quotaSummary': quotaSummary,
      'defaultEndpoint': defaultEndpoint,
    };
  }

  factory ApiModel.fromJson(Map<String, dynamic> json) {
    return ApiModel(
      id: json['id'] as String,
      name: json['name'] as String,
      provider: json['provider'] as String,
      capability: json['capability'] as String,
      active: json['active'] as bool? ?? true,
      recommended: json['recommended'] as bool? ?? false,
      freeTierAvailable: json['freeTierAvailable'] as bool? ?? true,
      commercialUseAllowed: json['commercialUseAllowed'] as bool? ?? true,
      quotaSummary: json['quotaSummary'] as String?,
      defaultEndpoint: json['defaultEndpoint'] as String?,
    );
  }
}

class ApiModelCatalog {
  static const List<ApiModel> models = [
    // =========================================================================
    // TEXTO — GOOGLE GEMINI / GROQ / OPENROUTER / OPENAI
    // =========================================================================
    ApiModel(
      id: 'gemini-3.1-flash-lite',
      name: 'Gemini 3.1 Flash Lite',
      provider: 'Google',
      capability: 'text',
      recommended: true,
      freeTierAvailable: true,
      commercialUseAllowed: true,
      quotaSummary: 'Camada gratuita AI Studio (RPM/RPD sujeitos à conta)',
      defaultEndpoint:
          'https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent',
    ),
    ApiModel(
      id: 'gemini-2.5-flash',
      name: 'Gemini 2.5 Flash',
      provider: 'Google',
      capability: 'text',
      recommended: true,
      freeTierAvailable: true,
      commercialUseAllowed: true,
      quotaSummary: 'Gratuito no AI Studio com limites diários de requisições',
      defaultEndpoint:
          'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent',
    ),
    ApiModel(
      id: 'gemini-2.5-pro',
      name: 'Gemini 2.5 Pro',
      provider: 'Google',
      capability: 'text',
      freeTierAvailable: true,
      commercialUseAllowed: true,
      quotaSummary: 'Raciocínio avançado e roteiros longos (AI Studio)',
    ),
    ApiModel(
      id: 'llama-3.3-70b-versatile',
      name: 'Llama 3.3 70B Versatile (Groq)',
      provider: 'Groq',
      capability: 'text',
      recommended: true,
      freeTierAvailable: true,
      commercialUseAllowed: true,
      quotaSummary: 'Plano gratuito GroqCloud (~30 RPM / cota diária de tokens)',
      defaultEndpoint: 'https://api.groq.com/openai/v1/chat/completions',
    ),
    ApiModel(
      id: 'qwen-qwq-32b',
      name: 'Qwen QwQ 32B (Groq)',
      provider: 'Groq',
      capability: 'text',
      freeTierAvailable: true,
      commercialUseAllowed: true,
      quotaSummary: 'Gratuito no GroqCloud (30 RPM)',
      defaultEndpoint: 'https://api.groq.com/openai/v1/chat/completions',
    ),
    ApiModel(
      id: 'deepseek/deepseek-r1:free',
      name: 'DeepSeek R1 Free (OpenRouter)',
      provider: 'OpenRouter',
      capability: 'text',
      recommended: true,
      freeTierAvailable: true,
      commercialUseAllowed: true,
      quotaSummary: 'Gratuito via OpenRouter (compatível OpenAI)',
      defaultEndpoint: 'https://openrouter.ai/api/v1/chat/completions',
    ),
    ApiModel(
      id: 'gpt-4.1-mini',
      name: 'GPT-4.1 mini',
      provider: 'OpenAI',
      capability: 'text',
      recommended: true,
      freeTierAvailable: false,
      commercialUseAllowed: true,
      quotaSummary: 'Pago por token (Tier 1+)',
      defaultEndpoint: 'https://api.openai.com/v1/chat/completions',
    ),
    ApiModel(
      id: 'gpt-4o-mini',
      name: 'GPT-4o mini',
      provider: 'OpenAI',
      capability: 'text',
      freeTierAvailable: false,
      commercialUseAllowed: true,
      quotaSummary: 'Pago por token (baixo custo)',
      defaultEndpoint: 'https://api.openai.com/v1/chat/completions',
    ),

    // =========================================================================
    // IMAGEM — GOOGLE GEMINI / CLOUDFLARE WORKERS AI / OPENAI
    // =========================================================================
    ApiModel(
      id: 'gemini-2.0-flash-preview-image-generation',
      name: 'Gemini 2.0 Flash Image Generation',
      provider: 'Google',
      capability: 'image',
      recommended: true,
      freeTierAvailable: true,
      commercialUseAllowed: true,
      quotaSummary: 'Geração multimodal nativa de imagens via AI Studio',
    ),
    ApiModel(
      id: '@cf/black-forest-labs/flux-1-schnell',
      name: 'FLUX.1 Schnell (Cloudflare Workers AI)',
      provider: 'Cloudflare',
      capability: 'image',
      recommended: true,
      freeTierAvailable: true,
      commercialUseAllowed: true,
      quotaSummary: '10.000 Neurons/dia grátis (~173 imagens 1024x1024/dia)',
    ),
    ApiModel(
      id: 'gpt-image-1',
      name: 'GPT Image 1 / DALL-E 3',
      provider: 'OpenAI',
      capability: 'image',
      recommended: true,
      freeTierAvailable: false,
      commercialUseAllowed: true,
      quotaSummary: 'Pago por imagem gerada (/v1/images/generations)',
      defaultEndpoint: 'https://api.openai.com/v1/images/generations',
    ),

    // =========================================================================
    // VÍDEO — GOOGLE VEO / LUMA / REPLICATE / RUNWAY REST
    // =========================================================================
    ApiModel(
      id: 'veo-2.0-generate-001',
      name: 'Google Veo 2.0 (Vídeo Assíncrono)',
      provider: 'Google',
      capability: 'video',
      recommended: true,
      freeTierAvailable: false,
      commercialUseAllowed: true,
      quotaSummary: 'Geração assíncrona predictLongRunning (9:16 / 16:9)',
    ),
    ApiModel(
      id: 'ray-2-flash',
      name: 'Luma Ray 2 Flash (REST Polling)',
      provider: 'Luma',
      capability: 'video',
      recommended: true,
      freeTierAvailable: false,
      commercialUseAllowed: true,
      quotaSummary: 'API assíncrona com status_url e saída MP4 com áudio',
      defaultEndpoint: 'https://api.lumalabs.ai/dream-machine/v1/generations',
    ),

    // =========================================================================
    // REDES SOCIAIS — APIS OFICIAIS (META GRAPH API & TIKTOK CONTENT POSTING)
    // =========================================================================
    ApiModel(
      id: 'instagram-graph-v21',
      name: 'Instagram Graph API (Content Publishing)',
      provider: 'Meta',
      capability: 'social',
      recommended: true,
      freeTierAvailable: true,
      commercialUseAllowed: true,
      quotaSummary: 'Gratuito para Contas Profissionais (limite 50 posts/24h)',
      defaultEndpoint: 'https://graph.facebook.com/v21.0',
    ),
    ApiModel(
      id: 'facebook-pages-graph-v21',
      name: 'Facebook Pages Graph API',
      provider: 'Meta',
      capability: 'social',
      recommended: true,
      freeTierAvailable: true,
      commercialUseAllowed: true,
      quotaSummary: 'Gratuito mediante token de Página e escopo pages_manage_posts',
      defaultEndpoint: 'https://graph.facebook.com/v21.0',
    ),
    ApiModel(
      id: 'tiktok-content-posting-v2',
      name: 'TikTok Content Posting API v2',
      provider: 'TikTok',
      capability: 'social',
      recommended: true,
      freeTierAvailable: true,
      commercialUseAllowed: true,
      quotaSummary: 'Exige aprovação do escopo video.publish ou envio para Inbox',
      defaultEndpoint: 'https://open.tiktokapis.com/v2/post/publish/video/init/',
    ),
  ];

  static List<ApiModel> getActiveModels(
    String provider, {
    String? capability,
  }) {
    final normalizedProvider = provider.trim().toLowerCase();
    return models.where((model) {
      if (!model.active) return false;
      final p = model.provider.toLowerCase();
      final matchesProvider = normalizedProvider.isEmpty ||
          p == normalizedProvider ||
          normalizedProvider.contains(p) ||
          p.contains(normalizedProvider);
      if (!matchesProvider) return false;
      if (capability != null && capability.trim().isNotEmpty) {
        return model.capability.toLowerCase() ==
            capability.trim().toLowerCase();
      }
      return true;
    }).toList();
  }

  static ApiModel? findById(String id) {
    final normalized = id.trim().toLowerCase();
    for (final model in models) {
      if (model.id.toLowerCase() == normalized) {
        return model;
      }
    }
    return null;
  }
}