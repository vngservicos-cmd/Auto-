import '../models/post_schedule.dart';
import 'post_schedule_service.dart';

class GroupPerformanceSummary {
  final String key;
  final String label;
  final int totalPosts;
  final int approvedPosts;
  final int publishedPosts;
  final int reEvaluateLaterPosts;
  final int videoPostsCount;
  final bool hasPlatformMetrics;
  final int totalReach;
  final int totalImpressions;
  final int totalEngagement;
  final int totalVideoViews;

  const GroupPerformanceSummary({
    required this.key,
    required this.label,
    required this.totalPosts,
    required this.approvedPosts,
    required this.publishedPosts,
    required this.reEvaluateLaterPosts,
    required this.videoPostsCount,
    required this.hasPlatformMetrics,
    required this.totalReach,
    required this.totalImpressions,
    required this.totalEngagement,
    required this.totalVideoViews,
  });
}

class BestHourRecommendation {
  final int hour;
  final int postsCount;
  final int totalEngagement;
  final bool basedOnPlatformMetrics;

  const BestHourRecommendation({
    required this.hour,
    required this.postsCount,
    required this.totalEngagement,
    required this.basedOnPlatformMetrics,
  });
}

class DashboardAnalyticsBundle {
  final int totalPosts;
  final int publishedCount;
  final int pendingCount;
  final int reEvaluateCount;
  final int totalVideos;
  final bool anyPlatformMetricsProvided;
  final List<GroupPerformanceSummary> byTopic;
  final List<GroupPerformanceSummary> byNetwork;
  final List<GroupPerformanceSummary> byAccount;
  final List<BestHourRecommendation> bestHours;

  const DashboardAnalyticsBundle({
    required this.totalPosts,
    required this.publishedCount,
    required this.pendingCount,
    required this.reEvaluateCount,
    required this.totalVideos,
    required this.anyPlatformMetricsProvided,
    required this.byTopic,
    required this.byNetwork,
    required this.byAccount,
    required this.bestHours,
  });
}

/// Calcula estatísticas reais por Tema, por Rede Social, por Conta,
/// desempenho de vídeos e melhores horários.
/// Regra estrita (Seção 13): NUNCA inventa métricas não fornecidas pelas plataformas.
class StatisticsService {
  StatisticsService({PostScheduleService? postScheduleService})
      : _postScheduleService = postScheduleService ?? PostScheduleService();

  final PostScheduleService _postScheduleService;

  Future<DashboardAnalyticsBundle> buildAnalytics() async {
    final schedules = await _postScheduleService.getAll();

    var publishedCount = 0;
    var pendingCount = 0;
    var reEvaluateCount = 0;
    var totalVideos = 0;
    var anyPlatformMetrics = false;

    for (final s in schedules) {
      if (s.publishedAt != null ||
          s.status.toLowerCase() == 'publicado' ||
          s.scheduleStatus.toLowerCase() == 'publicado') {
        publishedCount++;
      } else if (s.approvalStatus == 'Reavaliar mais tarde') {
        reEvaluateCount++;
      } else if (s.approvalStatus == 'Pendente') {
        pendingCount++;
      }
      if ((s.videoUrl != null && s.videoUrl!.trim().isNotEmpty) ||
          s.contentFormat == 'Roteiro para vídeo' ||
          s.contentFormat == 'Publicação completa') {
        totalVideos++;
      }
      if (_hasProvidedMetrics(s.metrics)) {
        anyPlatformMetrics = true;
      }
    }

    final byTopic = _groupBy(
      schedules,
      keySelector: (s) => (s.topicId ?? s.topicName ?? 'sem_tema').trim(),
      labelSelector: (s) =>
          (s.topicName != null && s.topicName!.trim().isNotEmpty)
              ? s.topicName!.trim()
              : 'Sem tema associado',
    );

    final byNetwork = _groupBy(
      schedules,
      keySelector: (s) => s.network.trim().toLowerCase(),
      labelSelector: (s) =>
          s.network.trim().isEmpty ? 'Rede não informada' : s.network.trim(),
    );

    final byAccount = _groupBy(
      schedules,
      keySelector: (s) => (s.accountId ?? 'conta_padrao').trim(),
      labelSelector: (s) => (s.accountId != null && s.accountId!.isNotEmpty)
          ? '${s.network} (${s.accountId})'
          : '${s.network} (Conta geral)',
    );

    final bestHours = _computeBestHours(schedules);

    return DashboardAnalyticsBundle(
      totalPosts: schedules.length,
      publishedCount: publishedCount,
      pendingCount: pendingCount,
      reEvaluateCount: reEvaluateCount,
      totalVideos: totalVideos,
      anyPlatformMetricsProvided: anyPlatformMetrics,
      byTopic: byTopic,
      byNetwork: byNetwork,
      byAccount: byAccount,
      bestHours: bestHours,
    );
  }

  bool _hasProvidedMetrics(Map<String, dynamic> metrics) {
    if (metrics.isEmpty) return false;
    for (final key in const [
      'reach',
      'impressions',
      'likes',
      'comments',
      'shares',
      'engagement',
      'videoViews'
    ]) {
      final val = metrics[key];
      if (val is num && val > 0) return true;
    }
    return false;
  }

  int _metricInt(Map<String, dynamic> m, String key) {
    final val = m[key];
    if (val is num) return val.toInt();
    if (val is String) return int.tryParse(val) ?? 0;
    return 0;
  }

  List<GroupPerformanceSummary> _groupBy(
    List<PostSchedule> schedules, {
    required String Function(PostSchedule) keySelector,
    required String Function(PostSchedule) labelSelector,
  }) {
    final buckets = <String, List<PostSchedule>>{};
    final labels = <String, String>{};

    for (final s in schedules) {
      final key = keySelector(s);
      buckets.putIfAbsent(key, () => []).add(s);
      labels.putIfAbsent(key, () => labelSelector(s));
    }

    final summaries = <GroupPerformanceSummary>[];
    for (final entry in buckets.entries) {
      final list = entry.value;
      var approved = 0;
      var published = 0;
      var reEval = 0;
      var videos = 0;
      var hasMetrics = false;
      var reach = 0;
      var impressions = 0;
      var engagement = 0;
      var videoViews = 0;

      for (final s in list) {
        if (s.approvalStatus == 'Aprovado') approved++;
        if (s.approvalStatus == 'Reavaliar mais tarde') reEval++;
        if (s.publishedAt != null ||
            s.status.toLowerCase() == 'publicado') {
          published++;
        }
        if (s.videoUrl != null && s.videoUrl!.trim().isNotEmpty) {
          videos++;
        }
        if (_hasProvidedMetrics(s.metrics)) {
          hasMetrics = true;
          reach += _metricInt(s.metrics, 'reach');
          impressions += _metricInt(s.metrics, 'impressions');
          final likes = _metricInt(s.metrics, 'likes');
          final comments = _metricInt(s.metrics, 'comments');
          final shares = _metricInt(s.metrics, 'shares');
          final directEng = _metricInt(s.metrics, 'engagement');
          engagement += directEng > 0 ? directEng : (likes + comments + shares);
          videoViews += _metricInt(s.metrics, 'videoViews');
        }
      }

      summaries.add(
        GroupPerformanceSummary(
          key: entry.key,
          label: labels[entry.key] ?? entry.key,
          totalPosts: list.length,
          approvedPosts: approved,
          publishedPosts: published,
          reEvaluateLaterPosts: reEval,
          videoPostsCount: videos,
          hasPlatformMetrics: hasMetrics,
          totalReach: reach,
          totalImpressions: impressions,
          totalEngagement: engagement,
          totalVideoViews: videoViews,
        ),
      );
    }

    summaries.sort((a, b) => b.totalPosts.compareTo(a.totalPosts));
    return summaries;
  }

  List<BestHourRecommendation> _computeBestHours(List<PostSchedule> schedules) {
    final hourCounts = <int, int>{};
    final hourEngagement = <int, int>{};
    final hourHasMetrics = <int, bool>{};

    for (final s in schedules) {
      final refDate = s.publishedAt ?? s.scheduledAt ?? s.createdAt;
      final h = refDate.hour;
      hourCounts[h] = (hourCounts[h] ?? 0) + 1;
      if (_hasProvidedMetrics(s.metrics)) {
        hourHasMetrics[h] = true;
        final likes = _metricInt(s.metrics, 'likes');
        final comments = _metricInt(s.metrics, 'comments');
        final shares = _metricInt(s.metrics, 'shares');
        final directEng = _metricInt(s.metrics, 'engagement');
        final eng = directEng > 0 ? directEng : (likes + comments + shares);
        hourEngagement[h] = (hourEngagement[h] ?? 0) + eng;
      }
    }

    final list = hourCounts.entries.map((entry) {
      final h = entry.key;
      return BestHourRecommendation(
        hour: h,
        postsCount: entry.value,
        totalEngagement: hourEngagement[h] ?? 0,
        basedOnPlatformMetrics: hourHasMetrics[h] ?? false,
      );
    }).toList();

    list.sort((a, b) {
      if (a.basedOnPlatformMetrics != b.basedOnPlatformMetrics) {
        return a.basedOnPlatformMetrics ? -1 : 1;
      }
      final engComp = b.totalEngagement.compareTo(a.totalEngagement);
      if (engComp != 0) return engComp;
      return b.postsCount.compareTo(a.postsCount);
    });

    return list.take(5).toList();
  }
}
