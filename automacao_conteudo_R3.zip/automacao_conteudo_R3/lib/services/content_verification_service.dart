import '../models/automation_task.dart';
import '../models/post_schedule.dart';
import 'automation_task_service.dart';
import 'post_schedule_service.dart';

class ContentVerificationReport {
  final bool hasSufficientEvidence;
  final List<String> detectedSources;
  final List<String> warnings;
  final String recommendation;

  const ContentVerificationReport({
    required this.hasSufficientEvidence,
    required this.detectedSources,
    required this.warnings,
    required this.recommendation,
  });
}

/// Serviço responsável pela Verificação de Conteúdo (Seção 12):
/// - Pesquisa e extração de fontes confiáveis;
/// - Verificação de evidências antes da publicação;
/// - Criação do estado "Reavaliar mais tarde" com nova verificação programada após 6 meses;
/// - Bloqueio de publicação automática de conteúdos sem evidências suficientes.
class ContentVerificationService {
  ContentVerificationService({
    PostScheduleService? postScheduleService,
    AutomationTaskService? taskService,
  })  : _postScheduleService = postScheduleService ?? PostScheduleService(),
        _taskService = taskService ?? AutomationTaskService();

  final PostScheduleService _postScheduleService;
  final AutomationTaskService _taskService;

  /// Calcula exatamente 6 meses à frente a partir da data base.
  static DateTime addSixMonths(DateTime from) {
    final targetMonth = from.month + 6;
    final yearOffset = (targetMonth - 1) ~/ 12;
    final month = ((targetMonth - 1) % 12) + 1;
    final year = from.year + yearOffset;
    final maxDayInTargetMonth = DateTime(year, month + 1, 0).day;
    final day =
        from.day > maxDayInTargetMonth ? maxDayInTargetMonth : from.day;
    return DateTime(year, month, day, from.hour, from.minute);
  }

  /// Analisa o texto e as fontes cadastradas para verificar se há evidências suficientes
  /// e se não há afirmações sem comprovação apresentadas como fatos absolutos.
  ContentVerificationReport verifyContent({
    required String content,
    required List<String> explicitSources,
  }) {
    final cleanContent = content.trim();
    final urlRegex = RegExp(r'https?://[^\s)\]]+', caseSensitive: false);
    final extractedUrls = urlRegex
        .allMatches(cleanContent)
        .map((m) => m.group(0)!)
        .toSet()
        .toList();

    final allSources = <String>{
      ...explicitSources.map((s) => s.trim()).where((s) => s.isNotEmpty),
      ...extractedUrls,
    }.toList();

    final warnings = <String>[];
    final lower = cleanContent.toLowerCase();

    if (!lower.contains(
      'este conteúdo foi produzido com auxílio de inteligência artificial',
    )) {
      warnings.add(
        'O aviso obrigatório de conteúdo produzido com auxílio de IA ainda não consta no texto.',
      );
    }

    final unverifiedPatterns = [
      '100% garantido',
      'comprovado sem fontes',
      'cura definitiva',
      'ganho garantido sem risco',
      'fato absoluto inquestionável',
    ];
    for (final pattern in unverifiedPatterns) {
      if (lower.contains(pattern)) {
        warnings.add(
          'Expressão de afirmação absoluta detectada ("$pattern") sem evidência vinculada.',
        );
      }
    }

    final requiresEvidence = lower.contains('estudo mostra') ||
        lower.contains('segundo pesquisa') ||
        lower.contains('dados oficiais') ||
        lower.contains('estatística');

    if (requiresEvidence && allSources.isEmpty) {
      warnings.add(
        'O texto menciona estudos, pesquisas ou dados oficiais, mas nenhuma fonte confiável foi anexada.',
      );
    }

    final sufficient = warnings.isEmpty;

    return ContentVerificationReport(
      hasSufficientEvidence: sufficient,
      detectedSources: allSources,
      warnings: warnings,
      recommendation: sufficient
          ? 'Evidências e aviso de IA verificados. Elegível para aprovação humana.'
          : 'Conteúdo retido para revisão humana ou marcação como "Reavaliar mais tarde" (+6 meses). Publicação automática bloqueada.',
    );
  }

  /// Coloca a postagem no estado "Reavaliar mais tarde" e agenda automaticamente
  /// uma tarefa de nova verificação para daqui a 6 meses.
  Future<PostSchedule> markReEvaluateLater(PostSchedule schedule) async {
    final now = DateTime.now();
    final reEvalDate = addSixMonths(now);

    final updated = schedule.copyWith(
      approvalStatus: 'Reavaliar mais tarde',
      scheduleStatus: 'Reavaliar em 6 meses',
      status: 'Reavaliar mais tarde',
      automatic: false,
      reEvaluateAt: reEvalDate,
      updatedAt: now,
    );

    await _postScheduleService.upsert(updated);

    final reviewTask = AutomationTask(
      id: 'recheck_${schedule.id}_${reEvalDate.millisecondsSinceEpoch}',
      type: AutomationTaskType.review,
      status: AutomationTaskStatus.pending,
      priority: 1,
      topicId: schedule.topicId,
      accountId: schedule.accountId,
      publicationId: schedule.id,
      payload: {
        'action': 'six_month_evidence_recheck',
        'postId': schedule.id,
        'topicName': schedule.topicName ?? '',
        'network': schedule.network,
        'scheduledReEvaluationDate': reEvalDate.toIso8601String(),
        'prompt':
            'Reavaliar evidências e fontes da publicação ${schedule.id} após 6 meses.',
      },
      createdAt: now,
      updatedAt: now,
      scheduledAt: reEvalDate,
    );

    await _taskService.add(reviewTask);
    return updated;
  }
}
