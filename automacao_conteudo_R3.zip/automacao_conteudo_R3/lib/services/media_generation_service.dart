import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/api_provider.dart';
import '../models/media_item.dart';
import 'api_provider_credentials_storage.dart';
import 'api_provider_registry.dart';
import 'media_library_service.dart';

class GeneratedVideoAsset {
  const GeneratedVideoAsset({
    required this.url,
    required this.accountId,
    required this.provider,
  });
  final String url;
  final String accountId;
  final String provider;
}

class MediaGenerationService {
  MediaGenerationService({
    ApiProviderRegistry? registry,
    ApiProviderCredentialsStorage? credentials,
    MediaLibraryService? mediaLibrary,
    http.Client? client,
  })  : _registry = registry ?? ApiProviderRegistry(),
        _credentials = credentials ?? ApiProviderCredentialsStorage(),
        _mediaLibrary = mediaLibrary ?? MediaLibraryService(),
        _client = client ?? http.Client(),
        _ownsClient = client == null;

  final ApiProviderRegistry _registry;
  final ApiProviderCredentialsStorage _credentials;
  final MediaLibraryService _mediaLibrary;
  final http.Client _client;
  final bool _ownsClient;

  Future<List<String>> generateImages({
    required List<String> prompts,
    String? aspectRatio,
    String? preferredAccountId,
    String? topicId,
    String? topicName,
    bool saveToLibrary = true,
  }) async {
    if (prompts.isEmpty) return const [];
    final accounts = await _accounts('image', preferredId: preferredAccountId);
    final failures = <String>[];
    for (final account in accounts) {
      try {
        final key = await _credentials.readCredential(account.id);
        if (key == null || key.trim().isEmpty) {
          failures.add('${account.name}: credencial não cadastrada.');
          continue;
        }
        if (account.modelId == null || account.modelId!.trim().isEmpty) {
          failures.add('${account.name}: selecione um modelo para esta API.');
          continue;
        }
        final generated = <String>[];
        if (_isGemini(account)) {
          for (final prompt in prompts) {
            final response = await _client
                .post(
                  _endpoint(account, 'image'),
                  headers: _headers(key, account),
                  body: jsonEncode({
                    'contents': [
                      {
                        'parts': [
                          {'text': prompt}
                        ]
                      }
                    ],
                    'generationConfig': {
                      'responseModalities': ['IMAGE', 'TEXT']
                    },
                  }),
                )
                .timeout(const Duration(minutes: 3));
            if (response.statusCode < 200 || response.statusCode >= 300) {
              throw MediaGenerationException(
                '${account.name}: HTTP ${response.statusCode} - ${_bodyMessage(response.body)}',
                statusCode: response.statusCode,
              );
            }
            final urls =
                _extractMediaUrls(_decode(response.body, account.name));
            if (urls.isEmpty) {
              throw MediaGenerationException(
                '${account.name}: não retornou imagem. Verifique se o modelo suporta geração de imagens.',
              );
            }
            generated.add(urls.first);
          }
        } else {
          final endpoint = _endpoint(account, 'image');
          for (final prompt in prompts) {
            final response = await _client
                .post(
                  endpoint,
                  headers: _headers(key, account),
                  body: jsonEncode({
                    'model': account.modelId,
                    'prompt': prompt,
                    'n': 1,
                    'size': _sizeFor(aspectRatio),
                  }),
                )
                .timeout(const Duration(minutes: 3));
            if (response.statusCode < 200 || response.statusCode >= 300) {
              throw MediaGenerationException(
                '${account.name}: HTTP ${response.statusCode} - ${_bodyMessage(response.body)}',
                statusCode: response.statusCode,
              );
            }
            final urls =
                _extractMediaUrls(_decode(response.body, account.name));
            if (urls.isEmpty) {
              throw MediaGenerationException(
                '${account.name}: resposta sem URL ou arquivo de imagem reconhecível.',
              );
            }
            generated.add(urls.first);
          }
        }

        await _registry.recordExecutionOutcome(account.id, success: true);

        if (saveToLibrary) {
          for (var i = 0; i < generated.length; i++) {
            await _mediaLibrary.add(
              MediaItem(
                id: 'img_${DateTime.now().microsecondsSinceEpoch}_$i',
                title:
                    '${topicName ?? "Imagem"} • Slide ${i + 1}/${generated.length}',
                mediaType: 'image',
                url: generated[i],
                topicId: topicId,
                topicName: topicName,
                providerName: '${account.name} (${account.provider})',
                promptUsed: i < prompts.length ? prompts[i] : '',
                createdAt: DateTime.now(),
              ),
            );
          }
        }

        return generated;
      } on MediaGenerationException catch (error) {
        failures.add('${account.name}: ${error.message}');
        await _registry.recordExecutionOutcome(
          account.id,
          success: false,
          errorMessage: error.message,
          quotaExceeded: error.statusCode == 429,
        );
      } catch (error) {
        failures.add('${account.name}: $error');
        await _registry.recordExecutionOutcome(
          account.id,
          success: false,
          errorMessage: error.toString(),
        );
      }
    }
    throw MediaGenerationException(
      'Nenhuma API de imagem conseguiu gerar os arquivos.\n${failures.join('\n')}',
    );
  }

  Future<String> generateVideo({required String prompt}) async =>
      (await generateVideoAsset(prompt: prompt)).url;

  Future<GeneratedVideoAsset> generateVideoAsset({
    required String prompt,
    String? preferredAccountId,
    String? topicId,
    String? topicName,
    bool saveToLibrary = true,
  }) async {
    final accounts = await _accounts('video', preferredId: preferredAccountId);
    final failures = <String>[];
    for (final account in accounts) {
      try {
        final key = await _credentials.readCredential(account.id);
        if (key == null || key.trim().isEmpty) {
          failures.add('${account.name}: credencial não cadastrada.');
          continue;
        }
        if (account.modelId == null || account.modelId!.trim().isEmpty) {
          failures.add('${account.name}: selecione um modelo para esta API.');
          continue;
        }
        final videoBody = _isGemini(account)
            ? {
                'instances': [
                  {'prompt': prompt}
                ],
                'parameters': {'aspectRatio': '9:16', 'sampleCount': 1},
              }
            : {'model': account.modelId, 'prompt': prompt};
        final response = await _client
            .post(
              _endpoint(account, 'video'),
              headers: _headers(key, account),
              body: jsonEncode(videoBody),
            )
            .timeout(const Duration(minutes: 5));
        if (response.statusCode < 200 || response.statusCode >= 300) {
          final msg =
              '${account.name}: HTTP ${response.statusCode} - ${_bodyMessage(response.body)}';
          failures.add(msg);
          await _registry.recordExecutionOutcome(
            account.id,
            success: false,
            errorMessage: msg,
            quotaExceeded: response.statusCode == 429,
          );
          continue;
        }
        final decoded = _decode(response.body, account.name);
        final urls = _extractMediaUrls(decoded);
        String? resolvedVideoUrl;
        if (urls.isNotEmpty) {
          resolvedVideoUrl = urls.first;
        } else {
          final map = decoded is Map
              ? Map<String, dynamic>.from(decoded)
              : <String, dynamic>{};
          final jobId = map['id'] ?? map['job_id'] ?? map['task_id'];
          final pollValue = map['status_url'] ??
              map['polling_url'] ??
              map['statusUrl'] ??
              response.headers['location'] ??
              (_isGemini(account) && map['name'] != null
                  ? 'https://generativelanguage.googleapis.com/v1beta/${map['name']}'
                  : null);
          if (jobId != null && pollValue != null) {
            resolvedVideoUrl = await _pollVideoJob(
              account: account,
              apiKey: key,
              pollUrl: pollValue.toString(),
            );
            if (resolvedVideoUrl == null) {
              throw MediaGenerationException(
                'A tarefa $jobId de ${account.name} terminou sem URL de vídeo.',
              );
            }
          } else if (jobId != null) {
            throw MediaGenerationException(
              'A API ${account.name} aceitou a solicitação (tarefa $jobId), mas não informou status_url/polling_url nem cabeçalho Location.',
            );
          }
        }

        if (resolvedVideoUrl != null && resolvedVideoUrl.isNotEmpty) {
          await _registry.recordExecutionOutcome(account.id, success: true);
          if (saveToLibrary) {
            await _mediaLibrary.add(
              MediaItem(
                id: 'vid_${DateTime.now().microsecondsSinceEpoch}',
                title: '${topicName ?? "Vídeo"} • Geração IA',
                mediaType: 'video',
                url: resolvedVideoUrl,
                topicId: topicId,
                topicName: topicName,
                providerName: '${account.name} (${account.provider})',
                promptUsed: prompt,
                estimatedSizeBytes: 4200000,
                createdAt: DateTime.now(),
              ),
            );
          }
          return GeneratedVideoAsset(
            url: resolvedVideoUrl,
            accountId: account.id,
            provider: account.provider,
          );
        }

        failures.add('${account.name}: resposta sem URL de vídeo.');
      } on MediaGenerationException catch (error) {
        failures.add('${account.name}: ${error.message}');
        await _registry.recordExecutionOutcome(
          account.id,
          success: false,
          errorMessage: error.message,
          quotaExceeded: error.statusCode == 429,
        );
      } catch (error) {
        failures.add('${account.name}: $error');
        await _registry.recordExecutionOutcome(
          account.id,
          success: false,
          errorMessage: error.toString(),
        );
      }
    }
    throw MediaGenerationException(
      'Nenhuma API de vídeo conseguiu entregar um arquivo reproduzível.\n${failures.join('\n')}',
    );
  }

  Future<String?> _pollVideoJob({
    required ApiProvider account,
    required String apiKey,
    required String pollUrl,
  }) async {
    final parsed = Uri.tryParse(pollUrl);
    if (parsed == null ||
        !parsed.hasScheme ||
        (parsed.scheme != 'https' && parsed.scheme != 'http')) {
      throw MediaGenerationException(
        '${account.name}: URL de consulta do trabalho inválida.',
      );
    }
    final deadline = DateTime.now().add(const Duration(minutes: 8));
    while (DateTime.now().isBefore(deadline)) {
      await Future<void>.delayed(const Duration(seconds: 5));
      final response = await _client
          .get(parsed, headers: _headers(apiKey, account))
          .timeout(const Duration(seconds: 45));
      if (response.statusCode < 200 || response.statusCode >= 300) {
        if (_retryable(response.statusCode)) continue;
        throw MediaGenerationException(
          '${account.name}: falha ao consultar o trabalho. HTTP ${response.statusCode}: ${_bodyMessage(response.body)}',
          statusCode: response.statusCode,
        );
      }
      final decoded = _decode(response.body, account.name);
      final urls = _extractMediaUrls(decoded);
      if (urls.isNotEmpty) return urls.first;
      if (decoded is Map) {
        final status =
            (decoded['status'] ?? decoded['state'] ?? '').toString().toLowerCase();
        if (decoded['done'] == true) {
          final operationResult = decoded['response'] ?? decoded['result'];
          final operationUrls = _extractMediaUrls(operationResult);
          if (operationUrls.isNotEmpty) return operationUrls.first;
          final operationError = decoded['error'];
          if (operationError != null) {
            throw MediaGenerationException(
              '${account.name}: ${operationError.toString()}',
            );
          }
        }
        if (status == 'failed' || status == 'error' || status == 'cancelled') {
          throw MediaGenerationException(
            '${account.name}: geração de vídeo falhou: ${decoded['error'] ?? decoded['message'] ?? status}',
          );
        }
        if (status == 'completed' ||
            status == 'succeeded' ||
            status == 'success') {
          final result = decoded['result'] ?? decoded['output'];
          final resultUrls = _extractMediaUrls(result);
          if (resultUrls.isNotEmpty) return resultUrls.first;
          throw MediaGenerationException(
            '${account.name}: trabalho concluído, mas sem URL de vídeo no resultado.',
          );
        }
      }
    }
    throw MediaGenerationException(
      '${account.name}: tempo limite de 8 minutos aguardando a geração do vídeo.',
    );
  }

  Future<List<ApiProvider>> _accounts(
    String capability, {
    String? preferredId,
  }) async {
    final all = await _registry.getAll();
    final accounts = all
        .where((item) =>
            item.active &&
            item.supportsCapability(capability) &&
            item.hasQuotaAvailable)
        .toList()
      ..sort((a, b) {
        if (preferredId != null && preferredId.isNotEmpty) {
          if (a.id == preferredId && b.id != preferredId) return -1;
          if (b.id == preferredId && a.id != preferredId) return 1;
        }
        return a.priority.compareTo(b.priority);
      });
    if (accounts.isEmpty) {
      throw MediaGenerationException(
        'Nenhuma API ativa e com cota de ${capability == 'image' ? 'imagem' : 'vídeo'} cadastrada. Cadastre uma conta desse tipo na Central de APIs.',
      );
    }
    return accounts;
  }

  bool _isGemini(ApiProvider account) {
    final provider = account.provider.toLowerCase();
    return provider.contains('google') || provider.contains('gemini');
  }

  Uri _endpoint(ApiProvider account, String capability) {
    final raw = account.websiteUrl?.trim() ?? '';
    if (raw.isEmpty && _isGemini(account) && capability == 'image') {
      return Uri.https(
        'generativelanguage.googleapis.com',
        '/v1beta/models/${Uri.encodeComponent(account.modelId ?? '')}:generateContent',
      );
    }
    if (raw.isEmpty && _isGemini(account) && capability == 'video') {
      return Uri.https(
        'generativelanguage.googleapis.com',
        '/v1beta/models/${Uri.encodeComponent(account.modelId ?? '')}:predictLongRunning',
      );
    }
    if (raw.isNotEmpty) {
      final uri = Uri.tryParse(raw);
      if (uri == null ||
          !uri.hasScheme ||
          (uri.scheme != 'https' && uri.scheme != 'http')) {
        throw MediaGenerationException(
          '${account.name}: informe uma URL HTTP/HTTPS válida no campo Endpoint da API.',
        );
      }
      return uri;
    }
    final provider = account.provider.toLowerCase();
    if (capability == 'image' &&
        (provider.contains('openai') || provider.contains('dall'))) {
      return Uri.parse('https://api.openai.com/v1/images/generations');
    }
    throw MediaGenerationException(
      '${account.name}: informe o endpoint HTTP da API.',
    );
  }

  Map<String, String> _headers(String key, ApiProvider account) {
    if (_isGemini(account)) {
      return {
        'x-goog-api-key': key.trim(),
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      };
    }
    return {
      'Authorization': 'Bearer ${key.trim()}',
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
  }

  String _sizeFor(String? ratio) {
    switch (ratio) {
      case '9:16':
        return '1024x1536';
      case '4:5':
        return '1024x1536';
      case '16:9':
        return '1536x1024';
      default:
        return '1024x1024';
    }
  }

  dynamic _decode(String body, String account) {
    try {
      return jsonDecode(body);
    } catch (_) {
      throw MediaGenerationException('$account retornou JSON inválido.');
    }
  }

  List<String> _extractMediaUrls(dynamic decoded) {
    final result = <String>[];
    void visit(dynamic value) {
      if (value is List) {
        for (final item in value) {
          visit(item);
        }
        return;
      }
      if (value is! Map) return;
      final url = value['url'] ??
          value['uri'] ??
          value['video_url'] ??
          value['videoUrl'] ??
          value['image_url'] ??
          value['imageUrl'];
      if (url is String && url.trim().isNotEmpty) result.add(url.trim());
      final b64 = value['b64_json'] ?? value['base64'] ?? value['image'];
      if (b64 is String && b64.isNotEmpty && !b64.startsWith('http')) {
        final mime = value['mimeType'] ?? value['mime_type'] ?? 'image/png';
        result.add('data:$mime;base64,$b64');
      }
      final inline = value['inlineData'] ?? value['inline_data'];
      if (inline is Map && inline['data'] is String) {
        final mime = inline['mimeType'] ?? inline['mime_type'] ?? 'image/png';
        result.add('data:$mime;base64,${inline['data']}');
      }
      for (final key in const [
        'data',
        'output',
        'images',
        'videos',
        'results',
        'candidates',
        'content',
        'parts',
        'video',
        'generatedSamples',
        'generated_samples',
        'response',
        'result',
        'sample',
        'generateVideoResponse',
        'generate_video_response',
      ]) {
        if (value.containsKey(key)) visit(value[key]);
      }
    }

    visit(decoded);
    return result.toSet().toList();
  }

  String _bodyMessage(String body) {
    try {
      final decoded = jsonDecode(body);
      if (decoded is Map) {
        final error = decoded['error'];
        if (error is Map && error['message'] != null) {
          return error['message'].toString();
        }
        if (error is String) return error;
        if (decoded['message'] != null) return decoded['message'].toString();
      }
    } catch (_) {}
    return body.length > 240 ? '${body.substring(0, 240)}…' : body;
  }

  bool _retryable(int code) =>
      code == 401 ||
      code == 403 ||
      code == 404 ||
      code == 408 ||
      code == 429 ||
      code >= 500;

  void dispose() {
    if (_ownsClient) _client.close();
  }
}

class MediaGenerationException implements Exception {
  const MediaGenerationException(this.message, {this.statusCode});
  final String message;
  final int? statusCode;
  @override
  String toString() => message;
}
