import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/api_provider.dart';
import 'api_provider_sync_queue.dart';

class ApiProviderRegistry {
  static const String _storageKey = 'api_provider_registry_v1';
  static const String _migrationKey = 'api_provider_initial_sync_migration_v1';

  final ApiProviderSyncQueue _syncQueue = ApiProviderSyncQueue();

  Future<List<ApiProvider>> getAll() async {
    final prefs = await SharedPreferences.getInstance();
    final storedData = prefs.getString(_storageKey);

    if (storedData == null || storedData.isEmpty) {
      await _prepareInitialSyncMigration([]);
      return [];
    }

    try {
      final decoded = jsonDecode(storedData);

      if (decoded is! List) {
        return [];
      }

      var needsMigration = false;
      final providers = <ApiProvider>[];

      for (var index = 0; index < decoded.length; index++) {
        final item = decoded[index];

        if (item is! Map) {
          continue;
        }

        final json = Map<String, dynamic>.from(item);
        final createdAtValue = json['createdAt'];

        if (createdAtValue == null || createdAtValue.toString().isEmpty) {
          json['createdAt'] = DateTime.fromMillisecondsSinceEpoch(
            index,
            isUtc: true,
          ).toIso8601String();

          needsMigration = true;
        }

        providers.add(ApiProvider.fromJson(json));
      }

      providers.sort((a, b) {
        final dateComparison = a.createdAt.compareTo(b.createdAt);

        if (dateComparison != 0) {
          return dateComparison;
        }

        return a.id.compareTo(b.id);
      });

      if (needsMigration) {
        await saveAll(providers);
      }

      await _prepareInitialSyncMigration(providers);

      return providers;
    } catch (_) {
      return [];
    }
  }

  /// Retorna provedores ativos compatíveis com a capacidade solicitada,
  /// ordenados por prioridade (1 = mais alta).
  Future<List<ApiProvider>> getActiveByCapability(String capability) async {
    final all = await getAll();
    final compatible = all
        .where((p) =>
            p.active && p.supportsCapability(capability) && p.hasQuotaAvailable)
        .toList()
      ..sort((a, b) {
        final pComp = a.priority.compareTo(b.priority);
        if (pComp != 0) return pComp;
        final dComp = a.createdAt.compareTo(b.createdAt);
        if (dComp != 0) return dComp;
        return a.id.compareTo(b.id);
      });
    return compatible;
  }

  /// Registra consumo, sucesso ou falha de cota no provedor.
  Future<void> recordExecutionOutcome(
    String providerId, {
    required bool success,
    String? errorMessage,
    bool quotaExceeded = false,
  }) async {
    final providers = await getAll();
    final index = providers.indexWhere((p) => p.id == providerId);
    if (index == -1) return;
    final current = providers[index];
    final nextStatus = quotaExceeded
        ? 'quota_exceeded'
        : (success ? 'available' : 'error');

    providers[index] = current.copyWith(
      usedQuotaToday: success ? current.usedQuotaToday + 1 : current.usedQuotaToday,
      usageCount: success ? current.usageCount + 1 : current.usageCount,
      availabilityStatus: nextStatus,
      lastError: success ? null : errorMessage,
      lastTestedAt: DateTime.now(),
    );
    await saveAll(providers);
  }

  Future<void> _prepareInitialSyncMigration(
    List<ApiProvider> providers,
  ) async {
    final prefs = await SharedPreferences.getInstance();

    if (prefs.getBool(_migrationKey) == true) {
      return;
    }

    for (final provider in providers) {
      final success = await _syncQueue.recordCreate(provider.id);

      if (!success) {
        throw Exception(
          'Não foi possível preparar a sincronização inicial.',
        );
      }
    }

    await prefs.setBool(_migrationKey, true);
  }

  Future<bool> saveAll(List<ApiProvider> providers) async {
    final prefs = await SharedPreferences.getInstance();

    final encoded = jsonEncode(
      providers.map((provider) => provider.toJson()).toList(),
    );

    return prefs.setString(_storageKey, encoded);
  }

  Future<bool> add(ApiProvider provider) async {
    final providers = await getAll();

    final alreadyExists = providers.any(
      (item) => item.id == provider.id,
    );

    if (alreadyExists) {
      return false;
    }

    final queueSaved = await _syncQueue.recordCreate(provider.id);

    if (!queueSaved) {
      return false;
    }

    providers.add(provider);

    providers.sort((a, b) {
      final dateComparison = a.createdAt.compareTo(b.createdAt);

      if (dateComparison != 0) {
        return dateComparison;
      }

      return a.id.compareTo(b.id);
    });

    final saved = await saveAll(providers);

    if (!saved) {
      await _syncQueue.remove(provider.id);
    }

    return saved;
  }

  Future<bool> update(ApiProvider updatedProvider) async {
    final providers = await getAll();

    final index = providers.indexWhere(
      (item) => item.id == updatedProvider.id,
    );

    if (index == -1) {
      return false;
    }

    final currentProvider = providers[index];

    final providerToSave = ApiProvider(
      id: updatedProvider.id,
      name: updatedProvider.name,
      provider: updatedProvider.provider,
      capability: updatedProvider.capability,
      capabilities: updatedProvider.capabilities,
      connectionType: updatedProvider.connectionType,
      modelId: updatedProvider.modelId,
      active: updatedProvider.active,
      isFree: updatedProvider.isFree,
      hasFreeTrial: updatedProvider.hasFreeTrial,
      commercialUseAllowed: updatedProvider.commercialUseAllowed,
      priority: updatedProvider.priority,
      trialDays: updatedProvider.trialDays,
      trialEndsAt: updatedProvider.trialEndsAt,
      quotaRenewsAt: updatedProvider.quotaRenewsAt,
      dailyQuotaLimit: updatedProvider.dailyQuotaLimit,
      usedQuotaToday: updatedProvider.usedQuotaToday,
      usageCount: updatedProvider.usageCount,
      availabilityStatus: updatedProvider.availabilityStatus,
      lastError: updatedProvider.lastError,
      lastTestedAt: updatedProvider.lastTestedAt,
      websiteUrl: updatedProvider.websiteUrl,
      notes: updatedProvider.notes,
      createdAt: currentProvider.createdAt,
    );

    final queueSaved = await _syncQueue.recordUpdate(
      providerToSave.id,
    );

    if (!queueSaved) {
      return false;
    }

    providers[index] = providerToSave;

    providers.sort((a, b) {
      final dateComparison = a.createdAt.compareTo(b.createdAt);

      if (dateComparison != 0) {
        return dateComparison;
      }

      return a.id.compareTo(b.id);
    });

    return saveAll(providers);
  }

  Future<bool> remove(String id) async {
    final providers = await getAll();
    final originalLength = providers.length;

    providers.removeWhere((provider) => provider.id == id);

    if (providers.length == originalLength) {
      return false;
    }

    final saved = await saveAll(providers);

    if (!saved) {
      return false;
    }

    return _syncQueue.recordDelete(id);
  }
}
