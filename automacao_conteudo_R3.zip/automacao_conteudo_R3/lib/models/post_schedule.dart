class PostSchedule {
  static const String mandatoryFourthSlidePhrase =
      'Gostou? Curta, compartilhe e comente para ajudar a trazer mais conteudos.';

  final String id;

  final String network;
  final String content;

  // Conteúdo e origem
  final String caption;
  final String contentFormat;
  final String? topicId;
  final String? topicName;

  // Vínculos permanentes
  final String? accountId;
  final String? campaignId;
  final String? publicationGroupId;

  // Identificação externa da publicação
  final String? externalPostId;
  final DateTime? publishedAt;

  // Materiais complementares (4 slides principais + slides extras de publicidade)
  final List<String> carouselSlides;
  final List<String> carouselImageUrls;
  final List<String> extraAdSlideTexts;
  final List<String> extraAdSlideImageUrls;

  final String? videoUrl;
  final String? videoApiAccountId;
  final String? videoApiProvider;
  final String? videoScript;
  final String? videoPrompt;

  // Verificação de evidências e fontes (Seções 4 e 12)
  final List<String> evidenceSources;
  final bool hasSufficientEvidence;
  final DateTime? reEvaluateAt;
  final bool requiresManualFinalization;

  // Estatísticas reais fornecidas pela plataforma (Seção 13)
  final Map<String, dynamic> metrics;

  // Agendamento
  final DateTime? scheduledAt;
  final String scheduleStatus;

  // Aprovação: 'Pendente' | 'Aprovado' | 'Reprovado' | 'Reavaliar mais tarde'
  final String approvalStatus;

  // Compatibilidade com versões anteriores
  final bool automatic;
  final String status;

  // Controle de tentativas e falhas
  final DateTime? lastAttemptAt;
  final int attemptCount;
  final String? lastError;

  // Controle e histórico
  final DateTime createdAt;
  final DateTime? updatedAt;
  final int version;

  const PostSchedule({
    required this.id,
    required this.network,
    required this.content,
    required this.scheduledAt,
    required this.automatic,
    required this.status,
    required this.createdAt,
    String? caption,
    this.contentFormat = 'Legenda para rede social',
    this.topicId,
    this.topicName,
    this.accountId,
    this.campaignId,
    this.publicationGroupId,
    this.externalPostId,
    this.publishedAt,
    this.carouselSlides = const [],
    this.carouselImageUrls = const [],
    this.extraAdSlideTexts = const [],
    this.extraAdSlideImageUrls = const [],
    this.videoUrl,
    this.videoApiAccountId,
    this.videoApiProvider,
    this.videoScript,
    this.videoPrompt,
    this.evidenceSources = const [],
    this.hasSufficientEvidence = true,
    this.reEvaluateAt,
    this.requiresManualFinalization = false,
    this.metrics = const {},
    String? scheduleStatus,
    this.approvalStatus = 'Pendente',
    this.lastAttemptAt,
    this.attemptCount = 0,
    this.lastError,
    this.updatedAt,
    this.version = 1,
  })  : caption = caption ?? content,
        scheduleStatus = scheduleStatus ??
            (scheduledAt == null ? 'Não agendado' : 'Agendado');

  static const Object _notProvided = Object();

  /// Total de slides do carrossel (4 principais + extras de publicidade).
  int get totalCarouselSlidesCount =>
      carouselSlides.length + extraAdSlideTexts.length;

  /// Verifica se a postagem pode ser publicada automaticamente.
  bool get canAutoPublish {
    if (approvalStatus != 'Aprovado') return false;
    if (!hasSufficientEvidence) return false;
    if (requiresManualFinalization) return false;
    return true;
  }

  /// Garante que o 4º slide contenha a frase obrigatória do projeto.
  static List<String> ensureMandatoryFourthSlide(List<String> slides) {
    final normalized = List<String>.from(slides);
    while (normalized.length < 4) {
      normalized.add('');
    }
    final fourth = normalized[3].trim();
    if (!fourth.toLowerCase().contains(
          'gostou? curta, compartilhe e comente',
        )) {
      normalized[3] = fourth.isEmpty
          ? mandatoryFourthSlidePhrase
          : '$fourth\n\n$mandatoryFourthSlidePhrase';
    }
    return normalized;
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'network': network,
      'content': content,
      'caption': caption,
      'contentFormat': contentFormat,
      'topicId': topicId,
      'topicName': topicName,
      'accountId': accountId,
      'campaignId': campaignId,
      'publicationGroupId': publicationGroupId,
      'externalPostId': externalPostId,
      'publishedAt': publishedAt?.toIso8601String(),
      'carouselSlides': carouselSlides,
      'carouselImageUrls': carouselImageUrls,
      'extraAdSlideTexts': extraAdSlideTexts,
      'extraAdSlideImageUrls': extraAdSlideImageUrls,
      'videoUrl': videoUrl,
      'videoApiAccountId': videoApiAccountId,
      'videoApiProvider': videoApiProvider,
      'videoScript': videoScript,
      'videoPrompt': videoPrompt,
      'evidenceSources': evidenceSources,
      'hasSufficientEvidence': hasSufficientEvidence,
      'reEvaluateAt': reEvaluateAt?.toIso8601String(),
      'requiresManualFinalization': requiresManualFinalization,
      'metrics': metrics,
      'scheduledAt': scheduledAt?.toIso8601String(),
      'scheduleStatus': scheduleStatus,
      'approvalStatus': approvalStatus,
      'automatic': automatic,
      'status': status,
      'lastAttemptAt': lastAttemptAt?.toIso8601String(),
      'attemptCount': attemptCount,
      'lastError': lastError,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt?.toIso8601String(),
      'version': version,
    };
  }

  factory PostSchedule.fromJson(Map<String, dynamic> json) {
    DateTime? parseDate(dynamic value) {
      if (value == null || value.toString().isEmpty) {
        return null;
      }
      return DateTime.tryParse(value.toString());
    }

    List<String> parseStringList(dynamic raw) {
      if (raw is List) {
        return raw.map((item) => item.toString()).toList();
      }
      return <String>[];
    }

    final content = json['content']?.toString() ?? '';
    final scheduledAt = parseDate(json['scheduledAt']);

    final rawMetrics = json['metrics'];
    final parsedMetrics = rawMetrics is Map
        ? Map<String, dynamic>.from(rawMetrics)
        : <String, dynamic>{};

    return PostSchedule(
      id: json['id']?.toString() ?? '',
      network: json['network']?.toString() ?? '',
      content: content,
      caption: json['caption']?.toString() ?? content,
      contentFormat:
          json['contentFormat']?.toString() ?? 'Legenda para rede social',
      topicId: json['topicId']?.toString(),
      topicName: json['topicName']?.toString(),
      accountId: json['accountId']?.toString(),
      campaignId: json['campaignId']?.toString(),
      publicationGroupId: json['publicationGroupId']?.toString(),
      externalPostId: json['externalPostId']?.toString(),
      publishedAt: parseDate(json['publishedAt']),
      carouselSlides: parseStringList(json['carouselSlides']),
      carouselImageUrls: parseStringList(json['carouselImageUrls']),
      extraAdSlideTexts: parseStringList(json['extraAdSlideTexts']),
      extraAdSlideImageUrls: parseStringList(json['extraAdSlideImageUrls']),
      videoUrl: json['videoUrl']?.toString(),
      videoApiAccountId: json['videoApiAccountId']?.toString(),
      videoApiProvider: json['videoApiProvider']?.toString(),
      videoScript: json['videoScript']?.toString(),
      videoPrompt: json['videoPrompt']?.toString(),
      evidenceSources: parseStringList(json['evidenceSources']),
      hasSufficientEvidence: json['hasSufficientEvidence'] as bool? ?? true,
      reEvaluateAt: parseDate(json['reEvaluateAt']),
      requiresManualFinalization:
          json['requiresManualFinalization'] as bool? ?? false,
      metrics: parsedMetrics,
      scheduledAt: scheduledAt,
      scheduleStatus: json['scheduleStatus']?.toString() ??
          (scheduledAt == null ? 'Não agendado' : 'Agendado'),
      approvalStatus: json['approvalStatus']?.toString() ?? 'Pendente',
      automatic: json['automatic'] == true,
      status: json['status']?.toString() ?? 'Rascunho',
      lastAttemptAt: parseDate(json['lastAttemptAt']),
      attemptCount: json['attemptCount'] is num
          ? (json['attemptCount'] as num).toInt()
          : 0,
      lastError: json['lastError']?.toString(),
      createdAt: parseDate(json['createdAt']) ?? DateTime.now(),
      updatedAt: parseDate(json['updatedAt']),
      version: json['version'] is num ? (json['version'] as num).toInt() : 1,
    );
  }

  PostSchedule copyWith({
    String? network,
    String? content,
    String? caption,
    String? contentFormat,
    Object? topicId = _notProvided,
    Object? topicName = _notProvided,
    Object? accountId = _notProvided,
    Object? campaignId = _notProvided,
    Object? publicationGroupId = _notProvided,
    Object? externalPostId = _notProvided,
    Object? publishedAt = _notProvided,
    List<String>? carouselSlides,
    List<String>? carouselImageUrls,
    List<String>? extraAdSlideTexts,
    List<String>? extraAdSlideImageUrls,
    Object? videoUrl = _notProvided,
    Object? videoApiAccountId = _notProvided,
    Object? videoApiProvider = _notProvided,
    Object? videoScript = _notProvided,
    Object? videoPrompt = _notProvided,
    List<String>? evidenceSources,
    bool? hasSufficientEvidence,
    Object? reEvaluateAt = _notProvided,
    bool? requiresManualFinalization,
    Map<String, dynamic>? metrics,
    Object? scheduledAt = _notProvided,
    String? scheduleStatus,
    String? approvalStatus,
    bool? automatic,
    String? status,
    Object? lastAttemptAt = _notProvided,
    int? attemptCount,
    Object? lastError = _notProvided,
    DateTime? updatedAt,
    int? version,
  }) {
    final newScheduledAt = identical(scheduledAt, _notProvided)
        ? this.scheduledAt
        : scheduledAt as DateTime?;

    return PostSchedule(
      id: id,
      network: network ?? this.network,
      content: content ?? this.content,
      caption: caption ?? this.caption,
      contentFormat: contentFormat ?? this.contentFormat,
      topicId: identical(topicId, _notProvided)
          ? this.topicId
          : topicId as String?,
      topicName: identical(topicName, _notProvided)
          ? this.topicName
          : topicName as String?,
      accountId: identical(accountId, _notProvided)
          ? this.accountId
          : accountId as String?,
      campaignId: identical(campaignId, _notProvided)
          ? this.campaignId
          : campaignId as String?,
      publicationGroupId: identical(publicationGroupId, _notProvided)
          ? this.publicationGroupId
          : publicationGroupId as String?,
      externalPostId: identical(externalPostId, _notProvided)
          ? this.externalPostId
          : externalPostId as String?,
      publishedAt: identical(publishedAt, _notProvided)
          ? this.publishedAt
          : publishedAt as DateTime?,
      carouselSlides: carouselSlides ?? this.carouselSlides,
      carouselImageUrls: carouselImageUrls ?? this.carouselImageUrls,
      extraAdSlideTexts: extraAdSlideTexts ?? this.extraAdSlideTexts,
      extraAdSlideImageUrls:
          extraAdSlideImageUrls ?? this.extraAdSlideImageUrls,
      videoUrl: identical(videoUrl, _notProvided)
          ? this.videoUrl
          : videoUrl as String?,
      videoApiAccountId: identical(videoApiAccountId, _notProvided)
          ? this.videoApiAccountId
          : videoApiAccountId as String?,
      videoApiProvider: identical(videoApiProvider, _notProvided)
          ? this.videoApiProvider
          : videoApiProvider as String?,
      videoScript: identical(videoScript, _notProvided)
          ? this.videoScript
          : videoScript as String?,
      videoPrompt: identical(videoPrompt, _notProvided)
          ? this.videoPrompt
          : videoPrompt as String?,
      evidenceSources: evidenceSources ?? this.evidenceSources,
      hasSufficientEvidence:
          hasSufficientEvidence ?? this.hasSufficientEvidence,
      reEvaluateAt: identical(reEvaluateAt, _notProvided)
          ? this.reEvaluateAt
          : reEvaluateAt as DateTime?,
      requiresManualFinalization:
          requiresManualFinalization ?? this.requiresManualFinalization,
      metrics: metrics ?? this.metrics,
      scheduledAt: newScheduledAt,
      scheduleStatus: scheduleStatus ??
          (identical(scheduledAt, _notProvided)
              ? this.scheduleStatus
              : newScheduledAt == null
                  ? 'Não agendado'
                  : 'Agendado'),
      approvalStatus: approvalStatus ?? this.approvalStatus,
      automatic: automatic ?? this.automatic,
      status: status ?? this.status,
      lastAttemptAt: identical(lastAttemptAt, _notProvided)
          ? this.lastAttemptAt
          : lastAttemptAt as DateTime?,
      attemptCount: attemptCount ?? this.attemptCount,
      lastError: identical(lastError, _notProvided)
          ? this.lastError
          : lastError as String?,
      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
      version: version ?? this.version + 1,
    );
  }
}
