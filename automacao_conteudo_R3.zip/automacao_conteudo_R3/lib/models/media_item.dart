class MediaItem {
  final String id;
  final String title;
  final String mediaType; // 'image' | 'video' | 'audio'
  final String url;
  final String? topicId;
  final String? topicName;
  final String? providerName;
  final String? promptUsed;
  final bool cloudSynced;
  final bool cachedLocally;
  final int estimatedSizeBytes;
  final List<String> tags;
  final DateTime createdAt;

  const MediaItem({
    required this.id,
    required this.title,
    required this.mediaType,
    required this.url,
    this.topicId,
    this.topicName,
    this.providerName,
    this.promptUsed,
    this.cloudSynced = false,
    this.cachedLocally = true,
    this.estimatedSizeBytes = 256000,
    this.tags = const [],
    required this.createdAt,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'mediaType': mediaType,
      'url': url,
      'topicId': topicId,
      'topicName': topicName,
      'providerName': providerName,
      'promptUsed': promptUsed,
      'cloudSynced': cloudSynced,
      'cachedLocally': cachedLocally,
      'estimatedSizeBytes': estimatedSizeBytes,
      'tags': tags,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory MediaItem.fromJson(Map<String, dynamic> json) {
    final rawTags = json['tags'];
    return MediaItem(
      id: json['id']?.toString() ?? '',
      title: json['title']?.toString() ?? 'Mídia sem título',
      mediaType: json['mediaType']?.toString() ?? 'image',
      url: json['url']?.toString() ?? '',
      topicId: json['topicId']?.toString(),
      topicName: json['topicName']?.toString(),
      providerName: json['providerName']?.toString(),
      promptUsed: json['promptUsed']?.toString(),
      cloudSynced: json['cloudSynced'] == true,
      cachedLocally: json['cachedLocally'] as bool? ?? true,
      estimatedSizeBytes: json['estimatedSizeBytes'] is num
          ? (json['estimatedSizeBytes'] as num).toInt()
          : 256000,
      tags: rawTags is List
          ? rawTags.map((e) => e.toString()).toList()
          : const <String>[],
      createdAt: DateTime.tryParse(json['createdAt']?.toString() ?? '') ??
          DateTime.now(),
    );
  }

  MediaItem copyWith({
    String? title,
    String? mediaType,
    String? url,
    String? topicId,
    String? topicName,
    String? providerName,
    String? promptUsed,
    bool? cloudSynced,
    bool? cachedLocally,
    int? estimatedSizeBytes,
    List<String>? tags,
  }) {
    return MediaItem(
      id: id,
      title: title ?? this.title,
      mediaType: mediaType ?? this.mediaType,
      url: url ?? this.url,
      topicId: topicId ?? this.topicId,
      topicName: topicName ?? this.topicName,
      providerName: providerName ?? this.providerName,
      promptUsed: promptUsed ?? this.promptUsed,
      cloudSynced: cloudSynced ?? this.cloudSynced,
      cachedLocally: cachedLocally ?? this.cachedLocally,
      estimatedSizeBytes: estimatedSizeBytes ?? this.estimatedSizeBytes,
      tags: tags ?? this.tags,
      createdAt: createdAt,
    );
  }
}
