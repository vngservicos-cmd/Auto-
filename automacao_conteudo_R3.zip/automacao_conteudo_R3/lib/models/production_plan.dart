class ProductionScene {
  final int sceneNumber;
  final String title;
  final String visualDescription;
  final String imagePrompt;
  final String videoPrompt;
  final String narrationText;
  final String subtitleText;
  final int durationSeconds;
  final String targetImageProvider;
  final String targetVideoProvider;

  const ProductionScene({
    required this.sceneNumber,
    required this.title,
    required this.visualDescription,
    required this.imagePrompt,
    required this.videoPrompt,
    required this.narrationText,
    required this.subtitleText,
    this.durationSeconds = 8,
    this.targetImageProvider = 'Google Gemini / Cloudflare Flux',
    this.targetVideoProvider = 'Google Veo / Luma / OpenAI',
  });

  Map<String, dynamic> toJson() {
    return {
      'sceneNumber': sceneNumber,
      'title': title,
      'visualDescription': visualDescription,
      'imagePrompt': imagePrompt,
      'videoPrompt': videoPrompt,
      'narrationText': narrationText,
      'subtitleText': subtitleText,
      'durationSeconds': durationSeconds,
      'targetImageProvider': targetImageProvider,
      'targetVideoProvider': targetVideoProvider,
    };
  }

  factory ProductionScene.fromJson(Map<String, dynamic> json) {
    return ProductionScene(
      sceneNumber: json['sceneNumber'] is num
          ? (json['sceneNumber'] as num).toInt()
          : 1,
      title: json['title']?.toString() ?? 'Cena',
      visualDescription: json['visualDescription']?.toString() ?? '',
      imagePrompt: json['imagePrompt']?.toString() ?? '',
      videoPrompt: json['videoPrompt']?.toString() ?? '',
      narrationText: json['narrationText']?.toString() ?? '',
      subtitleText: json['subtitleText']?.toString() ?? '',
      durationSeconds: json['durationSeconds'] is num
          ? (json['durationSeconds'] as num).toInt()
          : 8,
      targetImageProvider: json['targetImageProvider']?.toString() ??
          'Google Gemini / Cloudflare Flux',
      targetVideoProvider:
          json['targetVideoProvider']?.toString() ?? 'Google Veo / REST Video',
    );
  }

  ProductionScene copyWith({
    int? sceneNumber,
    String? title,
    String? visualDescription,
    String? imagePrompt,
    String? videoPrompt,
    String? narrationText,
    String? subtitleText,
    int? durationSeconds,
    String? targetImageProvider,
    String? targetVideoProvider,
  }) {
    return ProductionScene(
      sceneNumber: sceneNumber ?? this.sceneNumber,
      title: title ?? this.title,
      visualDescription: visualDescription ?? this.visualDescription,
      imagePrompt: imagePrompt ?? this.imagePrompt,
      videoPrompt: videoPrompt ?? this.videoPrompt,
      narrationText: narrationText ?? this.narrationText,
      subtitleText: subtitleText ?? this.subtitleText,
      durationSeconds: durationSeconds ?? this.durationSeconds,
      targetImageProvider: targetImageProvider ?? this.targetImageProvider,
      targetVideoProvider: targetVideoProvider ?? this.targetVideoProvider,
    );
  }
}

class ProductionPlan {
  final String id;
  final String? topicId;
  final String topicName;
  final String title;
  final String baseScript;
  final String visualContinuityGuide;
  final List<ProductionScene> scenes;
  final DateTime createdAt;
  final DateTime updatedAt;

  const ProductionPlan({
    required this.id,
    this.topicId,
    required this.topicName,
    required this.title,
    required this.baseScript,
    required this.visualContinuityGuide,
    required this.scenes,
    required this.createdAt,
    required this.updatedAt,
  });

  int get totalDurationSeconds =>
      scenes.fold(0, (acc, scene) => acc + scene.durationSeconds);

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'topicId': topicId,
      'topicName': topicName,
      'title': title,
      'baseScript': baseScript,
      'visualContinuityGuide': visualContinuityGuide,
      'scenes': scenes.map((s) => s.toJson()).toList(),
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory ProductionPlan.fromJson(Map<String, dynamic> json) {
    final rawScenes = json['scenes'];
    final parsedScenes = rawScenes is List
        ? rawScenes
            .whereType<Map>()
            .map((item) =>
                ProductionScene.fromJson(Map<String, dynamic>.from(item)))
            .toList()
        : <ProductionScene>[];

    return ProductionPlan(
      id: json['id']?.toString() ?? '',
      topicId: json['topicId']?.toString(),
      topicName: json['topicName']?.toString() ?? '',
      title: json['title']?.toString() ?? 'Plano de Produção',
      baseScript: json['baseScript']?.toString() ?? '',
      visualContinuityGuide: json['visualContinuityGuide']?.toString() ?? '',
      scenes: parsedScenes,
      createdAt: DateTime.tryParse(json['createdAt']?.toString() ?? '') ??
          DateTime.now(),
      updatedAt: DateTime.tryParse(json['updatedAt']?.toString() ?? '') ??
          DateTime.now(),
    );
  }

  ProductionPlan copyWith({
    String? topicId,
    String? topicName,
    String? title,
    String? baseScript,
    String? visualContinuityGuide,
    List<ProductionScene>? scenes,
    DateTime? updatedAt,
  }) {
    return ProductionPlan(
      id: id,
      topicId: topicId ?? this.topicId,
      topicName: topicName ?? this.topicName,
      title: title ?? this.title,
      baseScript: baseScript ?? this.baseScript,
      visualContinuityGuide:
          visualContinuityGuide ?? this.visualContinuityGuide,
      scenes: scenes ?? this.scenes,
      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
    );
  }
}
