class ApiProvider {
  final String id;
  final String name;
  final String provider;
  final String capability;
  final List<String> capabilities;
  final String connectionType;
  final String? modelId;

  final bool active;
  final bool isFree;
  final bool hasFreeTrial;
  final bool commercialUseAllowed;

  final int priority;
  final int? trialDays;
  final DateTime? trialEndsAt;
  final DateTime? quotaRenewsAt;

  final int? dailyQuotaLimit;
  final int usedQuotaToday;
  final int usageCount;
  final String availabilityStatus;
  final String? lastError;
  final DateTime? lastTestedAt;

  final String? websiteUrl;
  final String? notes;

  final DateTime createdAt;

  ApiProvider({
    required this.id,
    required this.name,
    required this.provider,
    required this.capability,
    List<String>? capabilities,
    this.connectionType = 'manual',
    this.modelId,
    this.active = true,
    this.isFree = true,
    this.hasFreeTrial = false,
    this.commercialUseAllowed = true,
    this.priority = 1,
    this.trialDays,
    this.trialEndsAt,
    this.quotaRenewsAt,
    this.dailyQuotaLimit,
    this.usedQuotaToday = 0,
    this.usageCount = 0,
    this.availabilityStatus = 'available',
    this.lastError,
    this.lastTestedAt,
    this.websiteUrl,
    this.notes,
    DateTime? createdAt,
  })  : capabilities = capabilities != null && capabilities.isNotEmpty
            ? capabilities
            : <String>[capability],
        createdAt = createdAt ?? DateTime.fromMillisecondsSinceEpoch(0);

  bool get hasQuotaAvailable {
    if (availabilityStatus == 'quota_exceeded') return false;
    if (dailyQuotaLimit != null &&
        dailyQuotaLimit! > 0 &&
        usedQuotaToday >= dailyQuotaLimit!) {
      return false;
    }
    if (hasFreeTrial &&
        trialEndsAt != null &&
        trialEndsAt!.isBefore(DateTime.now())) {
      return false;
    }
    return true;
  }

  bool supportsCapability(String targetCapability) {
    final normalized = targetCapability.trim().toLowerCase();
    if (capability.trim().toLowerCase() == normalized) return true;
    return capabilities.any((c) => c.trim().toLowerCase() == normalized);
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'provider': provider,
      'capability': capability,
      'capabilities': capabilities,
      'connectionType': connectionType,
      'modelId': modelId,
      'active': active,
      'isFree': isFree,
      'hasFreeTrial': hasFreeTrial,
      'commercialUseAllowed': commercialUseAllowed,
      'priority': priority,
      'trialDays': trialDays,
      'trialEndsAt': trialEndsAt?.toIso8601String(),
      'quotaRenewsAt': quotaRenewsAt?.toIso8601String(),
      'dailyQuotaLimit': dailyQuotaLimit,
      'usedQuotaToday': usedQuotaToday,
      'usageCount': usageCount,
      'availabilityStatus': availabilityStatus,
      'lastError': lastError,
      'lastTestedAt': lastTestedAt?.toIso8601String(),
      'websiteUrl': websiteUrl,
      'notes': notes,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory ApiProvider.fromJson(Map<String, dynamic> json) {
    final primaryCap = json['capability'] as String? ?? 'text';
    final rawCaps = json['capabilities'];
    final parsedCaps = rawCaps is List
        ? rawCaps.map((e) => e.toString()).where((e) => e.isNotEmpty).toList()
        : <String>[primaryCap];

    return ApiProvider(
      id: json['id'] as String? ?? '',
      name: json['name'] as String? ?? '',
      provider: json['provider'] as String? ?? '',
      capability: primaryCap,
      capabilities: parsedCaps,
      connectionType: json['connectionType'] as String? ?? 'manual',
      modelId: json['modelId'] as String?,
      active: json['active'] as bool? ?? true,
      isFree: json['isFree'] as bool? ?? true,
      hasFreeTrial: json['hasFreeTrial'] as bool? ?? false,
      commercialUseAllowed: json['commercialUseAllowed'] as bool? ?? true,
      priority: json['priority'] is num ? (json['priority'] as num).toInt() : 1,
      trialDays:
          json['trialDays'] is num ? (json['trialDays'] as num).toInt() : null,
      trialEndsAt: _parseDate(json['trialEndsAt']),
      quotaRenewsAt: _parseDate(json['quotaRenewsAt']),
      dailyQuotaLimit: json['dailyQuotaLimit'] is num
          ? (json['dailyQuotaLimit'] as num).toInt()
          : null,
      usedQuotaToday: json['usedQuotaToday'] is num
          ? (json['usedQuotaToday'] as num).toInt()
          : 0,
      usageCount:
          json['usageCount'] is num ? (json['usageCount'] as num).toInt() : 0,
      availabilityStatus:
          json['availabilityStatus'] as String? ?? 'available',
      lastError: json['lastError'] as String?,
      lastTestedAt: _parseDate(json['lastTestedAt']),
      websiteUrl: json['websiteUrl'] as String?,
      notes: json['notes'] as String?,
      createdAt: _parseDate(json['createdAt']) ??
          DateTime.fromMillisecondsSinceEpoch(0),
    );
  }

  static DateTime? _parseDate(dynamic value) {
    if (value is! String || value.isEmpty) {
      return null;
    }
    return DateTime.tryParse(value);
  }

  ApiProvider copyWith({
    String? name,
    String? provider,
    String? capability,
    List<String>? capabilities,
    String? connectionType,
    String? modelId,
    bool? active,
    bool? isFree,
    bool? hasFreeTrial,
    bool? commercialUseAllowed,
    int? priority,
    int? trialDays,
    DateTime? trialEndsAt,
    DateTime? quotaRenewsAt,
    int? dailyQuotaLimit,
    int? usedQuotaToday,
    int? usageCount,
    String? availabilityStatus,
    String? lastError,
    DateTime? lastTestedAt,
    String? websiteUrl,
    String? notes,
  }) {
    return ApiProvider(
      id: id,
      name: name ?? this.name,
      provider: provider ?? this.provider,
      capability: capability ?? this.capability,
      capabilities: capabilities ?? this.capabilities,
      connectionType: connectionType ?? this.connectionType,
      modelId: modelId ?? this.modelId,
      active: active ?? this.active,
      isFree: isFree ?? this.isFree,
      hasFreeTrial: hasFreeTrial ?? this.hasFreeTrial,
      commercialUseAllowed: commercialUseAllowed ?? this.commercialUseAllowed,
      priority: priority ?? this.priority,
      trialDays: trialDays ?? this.trialDays,
      trialEndsAt: trialEndsAt ?? this.trialEndsAt,
      quotaRenewsAt: quotaRenewsAt ?? this.quotaRenewsAt,
      dailyQuotaLimit: dailyQuotaLimit ?? this.dailyQuotaLimit,
      usedQuotaToday: usedQuotaToday ?? this.usedQuotaToday,
      usageCount: usageCount ?? this.usageCount,
      availabilityStatus: availabilityStatus ?? this.availabilityStatus,
      lastError: lastError ?? this.lastError,
      lastTestedAt: lastTestedAt ?? this.lastTestedAt,
      websiteUrl: websiteUrl ?? this.websiteUrl,
      notes: notes ?? this.notes,
      createdAt: createdAt,
    );
  }
}
