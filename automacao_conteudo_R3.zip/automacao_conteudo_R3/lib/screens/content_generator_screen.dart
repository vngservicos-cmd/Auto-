import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/api_provider.dart';
import '../models/automation_task.dart';
import '../models/post_schedule.dart';
import '../services/api_provider_registry.dart';
import '../services/automation_task_executor.dart';
import '../services/automation_task_service.dart';
import 'post_history_screen.dart';

class ContentGeneratorScreen extends StatefulWidget {
  const ContentGeneratorScreen({super.key});

  @override
  State<ContentGeneratorScreen> createState() =>
      _ContentGeneratorScreenState();
}

class _ContentGeneratorScreenState extends State<ContentGeneratorScreen> {
  static const String _topicsStorageKey = 'content_topics_v2';
  static const String _savedPresetsKey = 'content_generator_presets_v1';

  final TextEditingController _audienceController = TextEditingController();
  final TextEditingController _objectiveController = TextEditingController();
  final TextEditingController _customPromptController =
      TextEditingController();
  final TextEditingController _sourcesController = TextEditingController();
  final TextEditingController _extraAdSlideController =
      TextEditingController();
  final TextEditingController _resultController = TextEditingController();

  final AutomationTaskService _taskService = AutomationTaskService();
  final ApiProviderRegistry _providerRegistry = ApiProviderRegistry();

  List<Map<String, dynamic>> _topics = [];
  List<ApiProvider> _textProviders = [];
  List<ApiProvider> _imageProviders = [];
  List<ApiProvider> _videoProviders = [];
  List<Map<String, dynamic>> _savedPresets = [];

  String? _selectedTopicId;
  String? _preferredTextAccountId;
  String? _preferredImageAccountId;
  String? _preferredVideoAccountId;

  String _format = 'Legenda';
  String _tone = 'Natural e envolvente';
  String _videoStyle = 'Dinâmico';

  int _quantity = 1;
  String _period = 'Dia';
  String _repetition = 'Uma única vez';
  List<Map<String, dynamic>> _accounts = [];
  final Set<String> _selectedAccountIds = {};

  bool _loading = true;
  bool _addingToQueue = false;

  final List<String> _formats = const [
    'Legenda',
    'Carrossel',
    'Roteiro para vídeo',
    'Publicação completa',
  ];

  final List<String> _tones = const [
    'Natural e envolvente',
    'Profissional',
    'Divertido',
    'Educativo',
    'Inspirador',
    'Persuasivo',
  ];

  final List<String> _videoStyles = const [
    'Dinâmico',
    'Cinematográfico',
    'Documental',
    'Minimalista',
    'Narrativo',
    'Educativo',
  ];

  Map<String, dynamic>? get _selectedTopic {
    for (final topic in _topics) {
      if (topic['id'] == _selectedTopicId) {
        return topic;
      }
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    _loadInitial();
  }

  Future<void> _loadInitial() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final storedData = prefs.getString(_topicsStorageKey);

      if (storedData != null && storedData.isNotEmpty) {
        final decoded = jsonDecode(storedData);

        if (decoded is List) {
          _topics = decoded
              .whereType<Map>()
              .map((item) => Map<String, dynamic>.from(item))
              .where((topic) {
                final id = topic['id'];
                final name = topic['name'];

                return topic['active'] == true &&
                    id is String &&
                    id.trim().isNotEmpty &&
                    name is String &&
                    name.trim().isNotEmpty;
              })
              .toList();
        }
      }

      final presetsRaw = prefs.getString(_savedPresetsKey);
      if (presetsRaw != null && presetsRaw.isNotEmpty) {
        final decodedPresets = jsonDecode(presetsRaw);
        if (decodedPresets is List) {
          _savedPresets = decodedPresets
              .whereType<Map>()
              .map((item) => Map<String, dynamic>.from(item))
              .toList();
        }
      }

      final allProviders = await _providerRegistry.getAll();
      _textProviders = allProviders
          .where((p) => p.active && p.supportsCapability('text'))
          .toList();
      _imageProviders = allProviders
          .where((p) => p.active && p.supportsCapability('image'))
          .toList();
      _videoProviders = allProviders
          .where((p) => p.active && p.supportsCapability('video'))
          .toList();
    } catch (_) {
      _topics = [];
    }

    if (!mounted) return;

    setState(() {
      _selectedTopicId =
          _topics.isNotEmpty ? _topics.first['id'] as String : null;
    });
    if (_selectedTopicId != null) {
      await _loadAccountsForTopic(_selectedTopicId!);
    }
    if (!mounted) return;
    setState(() => _loading = false);
  }

  Future<void> _loadAccountsForTopic(String topicId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('social_accounts_topic_id_$topicId');
      final decoded = raw == null ? null : jsonDecode(raw);
      final accounts = decoded is List
          ? decoded
              .whereType<Map>()
              .map((item) => Map<String, dynamic>.from(item))
              .where((item) =>
                  item['active'] == true &&
                  (item['id']?.toString().trim().isNotEmpty ?? false))
              .toList()
          : <Map<String, dynamic>>[];
      if (!mounted) return;
      setState(() {
        _accounts = accounts;
        _selectedAccountIds
          ..clear()
          ..addAll(accounts.map((item) => item['id'].toString()));
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _accounts = [];
        _selectedAccountIds.clear();
      });
    }
  }

  Future<void> _saveCurrentPreset() async {
    final prefs = await SharedPreferences.getInstance();
    final preset = <String, dynamic>{
      'name':
          '${_selectedTopic?['name'] ?? "Configuração"} • $_format ($_tone)',
      'format': _format,
      'tone': _tone,
      'videoStyle': _videoStyle,
      'quantity': _quantity,
      'period': _period,
      'repetition': _repetition,
      'audience': _audienceController.text.trim(),
      'objective': _objectiveController.text.trim(),
      'customPrompt': _customPromptController.text.trim(),
      'sources': _sourcesController.text.trim(),
    };
    _savedPresets.insert(0, preset);
    if (_savedPresets.length > 20) {
      _savedPresets = _savedPresets.take(20).toList();
    }
    await prefs.setString(_savedPresetsKey, jsonEncode(_savedPresets));
    if (!mounted) return;
    setState(() {});
    _showMessage('Configuração salva para reutilização rápida.');
  }

  void _applyPreset(Map<String, dynamic> preset) {
    setState(() {
      _format = (preset['format'] ?? _format).toString();
      _tone = (preset['tone'] ?? _tone).toString();
      _videoStyle = (preset['videoStyle'] ?? _videoStyle).toString();
      _quantity = preset['quantity'] is num
          ? (preset['quantity'] as num).toInt()
          : _quantity;
      _period = (preset['period'] ?? _period).toString();
      _repetition = (preset['repetition'] ?? _repetition).toString();
      _audienceController.text = (preset['audience'] ?? '').toString();
      _objectiveController.text = (preset['objective'] ?? '').toString();
      _customPromptController.text =
          (preset['customPrompt'] ?? '').toString();
      _sourcesController.text = (preset['sources'] ?? '').toString();
    });
    _showMessage('Configuração reutilizada.');
  }

  void _prepareDraft() {
    final topic = _selectedTopic;

    if (topic == null) {
      _showMessage(
        'Cadastre e ative um tema antes de continuar.',
      );
      return;
    }

    final prompt = _buildPrompt(topic);
    setState(() {
      _customPromptController.text = prompt;
      _resultController.text = prompt;
    });
    _showMessage(
      'Prompt preparado! Você pode editá-lo livremente antes de gerar.',
    );
  }

  String _friendlyErrorMessage(Object error) {
    final message = error.toString().replaceFirst(
          'Exception: ',
          '',
        );

    if (message.trim().isEmpty) {
      return 'Ocorreu uma falha inesperada ao cadastrar a tarefa.';
    }

    return message;
  }

  String _buildPrompt(Map<String, dynamic> topic) {
    final name = topic['name'] as String;
    final description = (topic['description'] as String? ?? '').trim();

    final audience = _audienceController.text.trim();
    final objective = _objectiveController.text.trim();
    final sources = _sourcesController.text.trim();

    final buffer = StringBuffer()
      ..writeln('Crie conteúdo de qualidade, natural e variado em português brasileiro.')
      ..writeln()
      ..writeln('Tema: $name')
      ..writeln('ID do tema: $_selectedTopicId')
      ..writeln(
        'Descrição: ${description.isEmpty ? "Não informada" : description}',
      )
      ..writeln('Formato: $_format')
      ..writeln('Quantidade por período: $_quantity')
      ..writeln('Período: $_period')
      ..writeln('Repetição: $_repetition')
      ..writeln('Tom: $_tone')
      ..writeln(
        'Público-alvo: ${audience.isEmpty ? "Não especificado" : audience}',
      )
      ..writeln(
        'Objetivo: ${objective.isEmpty ? "Não especificado" : objective}',
      );

    if (sources.isNotEmpty) {
      buffer.writeln('Fontes de pesquisa obrigatórias a citar: $sources');
    }

    if (_format == 'Roteiro para vídeo' || _format == 'Publicação completa') {
      buffer.writeln('Estilo de edição: $_videoStyle');
    }

    buffer
      ..writeln()
      ..writeln('INSTRUÇÕES GERAIS E DE VERIFICAÇÃO:')
      ..writeln('- Entregue conteúdo final, variado, natural e pronto para revisão.')
      ..writeln('- Respeite o formato e o tom selecionados.')
      ..writeln(
        '- Nunca apresente informações sem evidências suficientes como fatos confirmados.',
      )
      ..writeln('- Quando houver pesquisa, inclua as fontes consultadas.')
      ..writeln('- Toda legenda deve terminar obrigatoriamente com o aviso de conteúdo produzido com auxílio de inteligência artificial.')
      ..writeln('- Gere exatamente $_quantity publicações independentes.')
      ..writeln(
        '- Inicie cada bloco com PUBLICAÇÃO 1:, PUBLICAÇÃO 2: e assim sucessivamente.',
      );

    switch (_format) {
      case 'Legenda':
        buffer
          ..writeln()
          ..writeln('FORMATO LEGENDA:')
          ..writeln(
              '- Gere $_quantity legenda(s), uma em cada bloco PUBLICAÇÃO N:.')
          ..writeln(
              '- Cada legenda deve ser independente e começar com LEGENDA:.')
          ..writeln('- Inclua o aviso obrigatório de IA ao final de cada uma.');
        break;

      case 'Carrossel':
        buffer
          ..writeln()
          ..writeln('FORMATO CARROSSEL (4 SLIDES):')
          ..writeln(
              '- Gere $_quantity conjunto(s), um em cada bloco PUBLICAÇÃO N:.')
          ..writeln(
              '- Comece com o bloco LEGENDA: contendo a legenda completa.')
          ..writeln(
              '- Depois apresente exatamente quatro blocos: SLIDE 1:, SLIDE 2:, SLIDE 3: e SLIDE 4:.')
          ..writeln('- Slide 1: introdução e apresentação do assunto.')
          ..writeln('- Slide 2: desenvolvimento.')
          ..writeln('- Slide 3: conclusão.')
          ..writeln(
              '- Slide 4: chamada para ação contendo obrigatoriamente a frase exata: "${PostSchedule.mandatoryFourthSlidePhrase}"')
          ..writeln('- Inclua o aviso obrigatório de IA na legenda.');
        break;

      case 'Roteiro para vídeo':
        buffer
          ..writeln()
          ..writeln('FORMATO VÍDEO:')
          ..writeln(
              '- Gere $_quantity roteiro(s), um em cada bloco PUBLICAÇÃO N:.')
          ..writeln('- Cada bloco deve conter LEGENDA: e ROTEIRO:.')
          ..writeln(
              '- Divida o roteiro em cenas com imagem, ação, narração e áudio.')
          ..writeln('- Inclua o aviso obrigatório de IA na legenda.');
        break;

      case 'Publicação completa':
        buffer
          ..writeln()
          ..writeln('FORMATO PUBLICAÇÃO COMPLETA:')
          ..writeln(
              '- Gere $_quantity conjunto(s) completo(s), um em cada bloco PUBLICAÇÃO N:.')
          ..writeln('- Cada conjunto deve conter uma seção LEGENDA:.')
          ..writeln(
              '- Cada conjunto deve conter os blocos SLIDE 1: a SLIDE 4:, usando obrigatoriamente no SLIDE 4 a frase: "${PostSchedule.mandatoryFourthSlidePhrase}".')
          ..writeln(
              '- Cada conjunto deve conter uma seção ROTEIRO: dividida em cenas com narração e áudio.')
          ..writeln('- Inclua o aviso obrigatório de IA em cada legenda.');
        break;
    }

    return buffer.toString();
  }

  Future<void> _generateContent() async {
    if (_addingToQueue) return;

    final topic = _selectedTopic;
    if (topic == null) {
      _showMessage('Cadastre e ative um tema antes de continuar.');
      return;
    }

    setState(() => _addingToQueue = true);

    try {
      final prompt = _customPromptController.text.trim().isNotEmpty
          ? _customPromptController.text.trim()
          : _buildPrompt(topic);
      final now = DateTime.now();
      final targetAccounts = _accounts
          .where((account) =>
              _selectedAccountIds.contains(account['id'].toString()))
          .map((account) => Map<String, dynamic>.from(account))
          .toList();

      final sourcesList = _sourcesController.text
          .split('\n')
          .map((s) => s.trim())
          .where((s) => s.isNotEmpty)
          .toList();

      final extraAdsList = _extraAdSlideController.text
          .split('\n')
          .map((s) => s.trim())
          .where((s) => s.isNotEmpty)
          .toList();

      final task = AutomationTask(
        id: 'task_${now.microsecondsSinceEpoch}',
        type: AutomationTaskType.contentGeneration,
        topicId: _selectedTopicId,
        payload: {
          'prompt': prompt,
          'topicName': topic['name'],
          'topicDescription': topic['description'] ?? '',
          'format': _format,
          'quantity': _quantity,
          'period': _period,
          'repetition': _repetition,
          'tone': _tone,
          'videoStyle': _videoStyle,
          'audience': _audienceController.text.trim(),
          'objective': _objectiveController.text.trim(),
          'preferredTextAccountId': _preferredTextAccountId,
          'preferredImageAccountId': _preferredImageAccountId,
          'preferredVideoAccountId': _preferredVideoAccountId,
          'evidenceSources': sourcesList,
          'extraAdSlideTexts': extraAdsList,
          'targetAccounts': targetAccounts,
          'source': 'content_generator',
        },
        createdAt: now,
        updatedAt: now,
      );

      final added = await _taskService.add(task);
      if (!added) {
        if (mounted) {
          _showMessage('Não foi possível registrar a geração.');
        }
        return;
      }

      final executor = AutomationTaskExecutor(taskService: _taskService);
      try {
        await executor.executeTask(task.id);
      } finally {
        executor.dispose();
      }

      final finishedTask = await _taskService.getById(task.id);
      if (!mounted) return;

      final payload = finishedTask?.payload ?? const <String, dynamic>{};
      final generated =
          (payload['result'] ?? payload['generatedText'] ?? '').toString();
      if (generated.isNotEmpty) {
        _resultController.text = generated;
      }

      final draftCount = payload['draftCount'] is num
          ? (payload['draftCount'] as num).toInt()
          : 0;
      if (draftCount > 0) {
        _showMessage(
          finishedTask?.status == AutomationTaskStatus.completed
              ? 'Conteúdo gerado e encaminhado para $draftCount postagem(ns). Abrindo Histórico e Configuração.'
              : 'Foram criados $draftCount rascunho(s), mas há materiais pendentes. Abrindo para revisão.',
        );
        await Navigator.push<void>(
          context,
          MaterialPageRoute(builder: (_) => const PostHistoryScreen()),
        );
      } else if (finishedTask?.status == AutomationTaskStatus.completed) {
        _showMessage(
          'Conteúdo gerado com sucesso! Veja o resultado abaixo.',
        );
      } else {
        _showMessage(
          finishedTask?.lastError ??
              'A geração não foi concluída. Consulte a Central de Automações.',
        );
      }
    } catch (error) {
      if (mounted) {
        _showMessage('Falha na geração: ${_friendlyErrorMessage(error)}');
      }
    } finally {
      if (mounted) setState(() => _addingToQueue = false);
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _copyResult() async {
    final text = _resultController.text.trim();

    if (text.isEmpty) {
      _showMessage(
        'Prepare um rascunho ou gere um conteúdo antes de copiar.',
      );
      return;
    }

    await Clipboard.setData(
      ClipboardData(text: text),
    );

    if (mounted) {
      _showMessage('Texto copiado.');
    }
  }

  @override
  void dispose() {
    _audienceController.dispose();
    _objectiveController.dispose();
    _customPromptController.dispose();
    _sourcesController.dispose();
    _extraAdSlideController.dispose();
    _resultController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final hasTopic = _selectedTopic != null;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Gerador de Conteúdo'),
        actions: [
          IconButton(
            tooltip: 'Salvar configuração atual para reutilizar',
            onPressed: _saveCurrentPreset,
            icon: const Icon(Icons.bookmark_add_outlined),
          ),
        ],
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                const Text(
                  'Prepare seu conteúdo',
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Selecione provedores, edite prompts, inclua fontes verificadas e monte carrosséis e vídeos.',
                ),
                const SizedBox(height: 16),

                if (_savedPresets.isNotEmpty) ...[
                  const Text(
                    'Configurações reutilizáveis salvas:',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 6),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: _savedPresets
                          .map(
                            (p) => Padding(
                              padding: const EdgeInsets.only(right: 8),
                              child: ActionChip(
                                avatar: const Icon(Icons.history, size: 16),
                                label: Text((p['name'] ?? 'Preset').toString()),
                                onPressed: () => _applyPreset(p),
                              ),
                            ),
                          )
                          .toList(),
                    ),
                  ),
                  const SizedBox(height: 16),
                ],

                const Text(
                  'Tema ativo',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 8),

                if (_topics.isEmpty)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(16),
                      child: Text(
                        'Nenhum tema ativo encontrado. '
                        'Volte à tela Temas de conteúdo para '
                        'cadastrar ou ativar um tema.',
                      ),
                    ),
                  )
                else
                  DropdownButtonFormField<String>(
                    initialValue: _selectedTopicId,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.topic_outlined),
                    ),
                    items: _topics.map((topic) {
                      final id = topic['id'] as String;
                      final name = topic['name'] as String;

                      return DropdownMenuItem<String>(
                        value: id,
                        child: Text(
                          name,
                          overflow: TextOverflow.ellipsis,
                        ),
                      );
                    }).toList(),
                    onChanged: (value) async {
                      setState(() {
                        _selectedTopicId = value;
                        _accounts = [];
                        _selectedAccountIds.clear();
                      });
                      if (value != null) await _loadAccountsForTopic(value);
                    },
                  ),

                const SizedBox(height: 20),

                DropdownButtonFormField<String>(
                  initialValue: _format,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Formato do conteúdo',
                    border: OutlineInputBorder(),
                  ),
                  items: _formats.map((format) {
                    return DropdownMenuItem<String>(
                      value: format,
                      child: Text(format),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _format = value;
                      });
                    }
                  },
                ),

                const SizedBox(height: 16),

                // SELEÇÃO DE PROVEDORES DE TEXTO, IMAGEM E VÍDEO
                DropdownButtonFormField<String?>(
                  initialValue: _preferredTextAccountId,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Provedor de Texto (ou Automático com Fallback)',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.text_fields),
                  ),
                  items: [
                    const DropdownMenuItem<String?>(
                      value: null,
                      child: Text('Automático por Prioridade + Fallback'),
                    ),
                    ..._textProviders.map(
                      (p) => DropdownMenuItem<String?>(
                        value: p.id,
                        child: Text(
                          '${p.name} (${p.provider} • P${p.priority})',
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ),
                  ],
                  onChanged: (val) =>
                      setState(() => _preferredTextAccountId = val),
                ),

                if (_format == 'Carrossel' ||
                    _format == 'Publicação completa') ...[
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String?>(
                    initialValue: _preferredImageAccountId,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText:
                          'Provedor de Imagens (ou Automático com Fallback)',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.image_outlined),
                    ),
                    items: [
                      const DropdownMenuItem<String?>(
                        value: null,
                        child: Text('Automático por Prioridade + Fallback'),
                      ),
                      ..._imageProviders.map(
                        (p) => DropdownMenuItem<String?>(
                          value: p.id,
                          child: Text(
                            '${p.name} (${p.provider} • P${p.priority})',
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ),
                    ],
                    onChanged: (val) =>
                        setState(() => _preferredImageAccountId = val),
                  ),
                ],

                if (_format == 'Roteiro para vídeo' ||
                    _format == 'Publicação completa') ...[
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String?>(
                    initialValue: _preferredVideoAccountId,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText:
                          'Provedor de Vídeo Assíncrono (ou Automático)',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.videocam_outlined),
                    ),
                    items: [
                      const DropdownMenuItem<String?>(
                        value: null,
                        child: Text('Automático por Prioridade + Fallback'),
                      ),
                      ..._videoProviders.map(
                        (p) => DropdownMenuItem<String?>(
                          value: p.id,
                          child: Text(
                            '${p.name} (${p.provider} • P${p.priority})',
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ),
                    ],
                    onChanged: (val) =>
                        setState(() => _preferredVideoAccountId = val),
                  ),
                ],

                const SizedBox(height: 16),

                DropdownButtonFormField<String>(
                  initialValue: _tone,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Tom do conteúdo',
                    border: OutlineInputBorder(),
                  ),
                  items: _tones.map((tone) {
                    return DropdownMenuItem<String>(
                      value: tone,
                      child: Text(tone),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _tone = value;
                      });
                    }
                  },
                ),

                if (_format == 'Roteiro para vídeo' ||
                    _format == 'Publicação completa') ...[
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    initialValue: _videoStyle,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'Estilo de edição do vídeo',
                      border: OutlineInputBorder(),
                    ),
                    items: _videoStyles.map((style) {
                      return DropdownMenuItem<String>(
                        value: style,
                        child: Text(style),
                      );
                    }).toList(),
                    onChanged: (value) {
                      if (value != null) {
                        setState(() {
                          _videoStyle = value;
                        });
                      }
                    },
                  ),
                ],

                const SizedBox(height: 16),

                DropdownButtonFormField<int>(
                  initialValue: _quantity,
                  decoration: const InputDecoration(
                    labelText: 'Quantidade de publicações',
                    border: OutlineInputBorder(),
                  ),
                  items: List.generate(10, (index) {
                    final value = index + 1;

                    return DropdownMenuItem<int>(
                      value: value,
                      child: Text('$value'),
                    );
                  }),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _quantity = value;
                      });
                    }
                  },
                ),

                const SizedBox(height: 16),

                DropdownButtonFormField<String>(
                  initialValue: _period,
                  decoration: const InputDecoration(
                    labelText: 'Período de produção',
                    border: OutlineInputBorder(),
                  ),
                  items: const ['Dia', 'Semana', 'Quinzena', 'Mês']
                      .map((value) => DropdownMenuItem(
                            value: value,
                            child: Text(value),
                          ))
                      .toList(),
                  onChanged: (value) {
                    if (value != null) setState(() => _period = value);
                  },
                ),

                const SizedBox(height: 16),

                DropdownButtonFormField<String>(
                  initialValue: _repetition,
                  decoration: const InputDecoration(
                    labelText: 'Repetição da programação',
                    border: OutlineInputBorder(),
                  ),
                  items: const ['Uma única vez', 'Continuamente']
                      .map((value) => DropdownMenuItem(
                            value: value,
                            child: Text(value),
                          ))
                      .toList(),
                  onChanged: (value) {
                    if (value != null) setState(() => _repetition = value);
                  },
                ),

                const SizedBox(height: 16),

                if (_accounts.isNotEmpty) ...[
                  const Text(
                    'Contas de destino (seleção individual por publicação)',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 6),
                  ..._accounts.map((account) {
                    final id = account['id'].toString();
                    final platform =
                        (account['platform'] ?? account['networkId'] ?? 'Rede')
                            .toString();
                    final name =
                        (account['name'] ?? account['username'] ?? platform)
                            .toString();
                    return CheckboxListTile(
                      contentPadding: EdgeInsets.zero,
                      value: _selectedAccountIds.contains(id),
                      title: Text('$platform · $name'),
                      subtitle: Text((account['username'] ?? '').toString()),
                      onChanged: (checked) {
                        setState(() {
                          if (checked == true) {
                            _selectedAccountIds.add(id);
                          } else {
                            _selectedAccountIds.remove(id);
                          }
                        });
                      },
                    );
                  }),
                ] else
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(12),
                      child: Text(
                        'Nenhuma conta social ativa cadastrada para este tema. '
                        'A geração poderá ser executada, mas não haverá encaminhamento automático.',
                      ),
                    ),
                  ),

                const SizedBox(height: 16),

                TextField(
                  controller: _audienceController,
                  decoration: const InputDecoration(
                    labelText: 'Público-alvo (opcional)',
                    hintText: 'Ex.: pequenos empreendedores',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.people_outline),
                  ),
                ),

                const SizedBox(height: 16),

                TextField(
                  controller: _objectiveController,
                  minLines: 2,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'Objetivo do conteúdo (opcional)',
                    hintText: 'Ex.: ensinar, informar ou divulgar',
                    border: OutlineInputBorder(),
                    alignLabelWithHint: true,
                  ),
                ),

                const SizedBox(height: 16),

                TextField(
                  controller: _sourcesController,
                  minLines: 2,
                  maxLines: 4,
                  decoration: const InputDecoration(
                    labelText:
                        'Fontes de pesquisa / evidências verificadas (1 por linha, opcional)',
                    hintText: 'https://fonte-confiavel.gov.br/...',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.fact_check_outlined),
                  ),
                ),

                if (_format == 'Carrossel' ||
                    _format == 'Publicação completa') ...[
                  const SizedBox(height: 16),
                  TextField(
                    controller: _extraAdSlideController,
                    minLines: 2,
                    maxLines: 4,
                    decoration: const InputDecoration(
                      labelText:
                          'Slides extras para publicidade após o 4º slide (1 por linha, sem alterar código)',
                      hintText:
                          'Ex.: Conheça nosso patrocinador oficial — Link na bio!',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.campaign_outlined),
                    ),
                  ),
                ],

                const SizedBox(height: 16),

                TextField(
                  controller: _customPromptController,
                  minLines: 4,
                  maxLines: 10,
                  decoration: const InputDecoration(
                    labelText:
                        'Editor de Prompt (opcional — clique em "Preparar rascunho" para preencher e editar)',
                    border: OutlineInputBorder(),
                    alignLabelWithHint: true,
                  ),
                ),

                const SizedBox(height: 20),

                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: hasTopic ? _prepareDraft : null,
                    icon: const Icon(Icons.edit_note),
                    label: const Text('Preparar rascunho / Editar Prompt'),
                  ),
                ),

                const SizedBox(height: 12),

                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed:
                        !hasTopic || _addingToQueue ? null : _generateContent,
                    icon: _addingToQueue
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                            ),
                          )
                        : const Icon(Icons.playlist_add),
                    label: Text(
                      _addingToQueue
                          ? 'Gerando conteúdo...'
                          : 'Gerar conteúdo agora',
                    ),
                  ),
                ),

                const SizedBox(height: 28),

                const Text(
                  'Resultado / rascunho',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 12),

                TextField(
                  controller: _resultController,
                  minLines: 8,
                  maxLines: 18,
                  decoration: const InputDecoration(
                    hintText:
                        'O rascunho ou o resultado da geração aparecerá aqui.',
                    border: OutlineInputBorder(),
                    alignLabelWithHint: true,
                  ),
                ),

                const SizedBox(height: 12),

                OutlinedButton.icon(
                  onPressed: _copyResult,
                  icon: const Icon(Icons.copy),
                  label: const Text('Copiar texto'),
                ),

                const SizedBox(height: 12),

                const Text(
                  'Todo texto gerado inclui obrigatoriamente o aviso de auxílio de inteligência artificial, e todo carrossel inclui no 4º slide a frase padrão de engajamento.',
                  style: TextStyle(fontSize: 12),
                ),
              ],
            ),
    );
  }
}