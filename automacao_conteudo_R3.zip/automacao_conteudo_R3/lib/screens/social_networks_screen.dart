import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/social_network.dart';
import '../services/social_network_registry.dart';
import '../services/social_publishing_service.dart';

class SocialNetworksScreen extends StatefulWidget {
  const SocialNetworksScreen({super.key});

  @override
  State<SocialNetworksScreen> createState() => _SocialNetworksScreenState();
}

class _SocialNetworksScreenState extends State<SocialNetworksScreen> {
  static const String _topicsKey = 'content_topics_v2';

  List<Map<String, dynamic>> _topics = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadTopics();
  }

  Future<void> _loadTopics() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getString(_topicsKey);

      if (saved != null) {
        final decoded = jsonDecode(saved) as List<dynamic>;
        _topics = decoded
            .map((item) => Map<String, dynamic>.from(item as Map))
            .toList();
      } else {
        final oldTopics = prefs.getStringList('content_topics') ?? [];

        _topics = oldTopics
            .map((name) => <String, dynamic>{
                  'name': name,
                  'description': '',
                  'active': true,
                })
            .toList();
      }
    } catch (_) {
      _topics = [];
    }

    if (!mounted) return;

    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final activeTopics =
        _topics.where((topic) => topic['active'] == true).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Redes sociais por tema'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : activeTopics.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.topic_outlined, size: 52),
                        const SizedBox(height: 12),
                        Text(
                          _topics.isEmpty
                              ? 'Nenhum tema cadastrado'
                              : 'Todos os temas estão inativos',
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'Cadastre um tema ou ative um tema existente '
                          'na tela Temas de conteúdo.',
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                )
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    const Text(
                      'Escolha um tema',
                      style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Cada tema possui suas próprias contas de Instagram, Facebook e TikTok com verificação real de autenticação.',
                    ),
                    const SizedBox(height: 20),
                    ...activeTopics.map((topic) {
                      final name = topic['name'] as String? ?? '';
                      final description =
                          topic['description'] as String? ?? '';
                      final topicId = topic['id'] as String?;

                      return Card(
                        child: ListTile(
                          leading: const CircleAvatar(
                            child: Icon(Icons.folder_outlined),
                          ),
                          title: Text(name),
                          subtitle: Text(
                            description.isEmpty
                                ? 'Gerencie e autentique as contas deste tema'
                                : description,
                          ),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => TopicSocialAccountsScreen(
                                  topicName: name,
                                  topicId: topicId,
                                ),
                              ),
                            );
                          },
                        ),
                      );
                    }),
                  ],
                ),
    );
  }
}

class TopicSocialAccountsScreen extends StatefulWidget {
  final String topicName;
  final String? topicId;

  const TopicSocialAccountsScreen({
    super.key,
    required this.topicName,
    this.topicId,
  });

  @override
  State<TopicSocialAccountsScreen> createState() =>
      _TopicSocialAccountsScreenState();
}

class _TopicSocialAccountsScreenState extends State<TopicSocialAccountsScreen> {
  final List<Map<String, dynamic>> _accounts = [];
  final SocialNetworkRegistry _registry = SocialNetworkRegistry();
  final SocialPublishingService _publishingService = SocialPublishingService();

  List<SocialNetwork> _catalogNetworks = [];

  bool _isLoading = true;
  bool _isSaving = false;

  static const List<String> _availableFormats = [
    'Legenda',
    'Carrossel',
    'Vídeo',
    'Publicação completa',
  ];

  static const List<SocialNetwork> _builtInNetworks = [
    SocialNetwork(
      id: 'instagram',
      name: 'Instagram',
      iconName: 'instagram',
      connectorType: 'official_graph_api',
    ),
    SocialNetwork(
      id: 'facebook',
      name: 'Facebook',
      iconName: 'facebook',
      connectorType: 'official_graph_api',
    ),
    SocialNetwork(
      id: 'tiktok',
      name: 'TikTok',
      iconName: 'tiktok',
      connectorType: 'official_content_posting_api',
    ),
  ];

  String get _effectiveTopicId => widget.topicId?.trim() ?? '';

  String get _legacyStorageKey =>
      'social_accounts_topic_${base64Url.encode(utf8.encode(widget.topicName))}';

  String get _storageKey {
    if (_effectiveTopicId.isEmpty) {
      return _legacyStorageKey;
    }

    return 'social_accounts_topic_id_$_effectiveTopicId';
  }

  String _createAccountId() {
    return 'account_${DateTime.now().microsecondsSinceEpoch}';
  }

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  @override
  void dispose() {
    _publishingService.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      String? saved = prefs.getString(_storageKey);

      if (saved == null &&
          _effectiveTopicId.isNotEmpty &&
          _storageKey != _legacyStorageKey) {
        saved = prefs.getString(_legacyStorageKey);
      }

      if (saved != null) {
        final decoded = jsonDecode(saved) as List<dynamic>;

        final loadedAccounts = decoded.map((item) {
          final account = Map<String, dynamic>.from(item as Map);

          account['id'] = account['id'] is String &&
                  (account['id'] as String).trim().isNotEmpty
              ? account['id']
              : _createAccountId();

          account['topicId'] = _effectiveTopicId.isNotEmpty
              ? _effectiveTopicId
              : account['topicId'];

          account['topicName'] = widget.topicName;
          account['platform'] = account['platform'] as String? ?? '';
          account['networkId'] = account['networkId'] as String? ?? '';
          account['name'] = account['name'] as String? ?? '';
          account['username'] = account['username'] as String? ?? '';
          account['externalAccountId'] =
              account['externalAccountId'] as String? ?? '';
          account['active'] = account['active'] == true;
          account['formats'] = account['formats'] is List
              ? List<String>.from(account['formats'] as List)
              : List<String>.from(_availableFormats);
          // Regra estrita (Seção 11): Nunca considerar conectada apenas porque foi cadastrada.
          account['connectionStatus'] =
              account['connectionStatus'] as String? ?? 'not_configured';
          account['tiktokDirectPostApproved'] =
              account['tiktokDirectPostApproved'] == true;

          return account;
        }).toList();

        _accounts.addAll(loadedAccounts);

        if (_effectiveTopicId.isNotEmpty) {
          await prefs.setString(
            _storageKey,
            jsonEncode(_accounts),
          );
        }
      }
    } catch (_) {
      _accounts.clear();
    }

    try {
      _catalogNetworks = await _registry.getAll();
    } catch (_) {
      _catalogNetworks = [];
    }

    if (!mounted) return;

    setState(() {
      _isLoading = false;
    });
  }

  List<SocialNetwork> get _availableNetworks {
    final result = <SocialNetwork>[..._builtInNetworks];
    final existingNames =
        result.map((network) => network.name.toLowerCase()).toSet();

    for (final network in _catalogNetworks) {
      if (!network.active) continue;

      if (existingNames.add(network.name.trim().toLowerCase())) {
        result.add(network);
      }
    }

    return result;
  }

  Future<bool> _saveAccounts() async {
    if (_isSaving) return false;

    setState(() {
      _isSaving = true;
    });

    bool saved = false;

    try {
      final prefs = await SharedPreferences.getInstance();
      saved = await prefs.setString(
        _storageKey,
        jsonEncode(_accounts),
      );
    } catch (_) {
      saved = false;
    }

    if (!mounted) return saved;

    setState(() {
      _isSaving = false;
    });

    if (!saved) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Não foi possível salvar as contas.'),
        ),
      );
    }

    return saved;
  }

  bool _isDuplicate(
    Map<String, dynamic> candidate, {
    String? ignoreId,
  }) {
    final networkId =
        (candidate['networkId'] as String? ?? '').trim().toLowerCase();
    final username =
        (candidate['username'] as String? ?? '').trim().toLowerCase();
    final name = (candidate['name'] as String? ?? '').trim().toLowerCase();

    return _accounts.any((account) {
      if (account['id'] == ignoreId) return false;

      final existingNetwork =
          (account['networkId'] as String? ?? '').trim().toLowerCase();

      if (existingNetwork != networkId) return false;

      final existingUsername =
          (account['username'] as String? ?? '').trim().toLowerCase();

      final existingName =
          (account['name'] as String? ?? '').trim().toLowerCase();

      if (username.isNotEmpty && existingUsername.isNotEmpty) {
        return username == existingUsername;
      }

      return name.isNotEmpty && name == existingName;
    });
  }

  Future<void> _verifyAccount(int index) async {
    if (index < 0 || index >= _accounts.length) return;
    final account = Map<String, dynamic>.from(_accounts[index]);
    final verification =
        await _publishingService.verifyAccountAuthentication(account);

    setState(() {
      _accounts[index]['connectionStatus'] = verification.status;
      _accounts[index]['lastVerificationMessage'] = verification.message;
      _accounts[index]['requiresManualFinalization'] =
          verification.requiresManualFinalization;
    });
    await _saveAccounts();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(verification.message)),
    );
  }

  Future<void> _addAccount() async {
    if (_isSaving || _isLoading) return;

    final networks = _availableNetworks;

    if (networks.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Não há redes ativas disponíveis no catálogo.'),
        ),
      );
      return;
    }

    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (_) => _AccountDialog(networks: networks),
    );

    if (result == null || !mounted) return;

    final accountId = _createAccountId();
    final oauthToken = (result['oauthToken'] ?? '').toString().trim();
    result.remove('oauthToken');

    final newAccount = <String, dynamic>{
      ...result,
      'id': accountId,
      'topicId': _effectiveTopicId.isEmpty ? null : _effectiveTopicId,
      'topicName': widget.topicName,
      // Permanece 'not_configured' até que a verificação real seja executada!
      'connectionStatus': 'not_configured',
    };

    if (_isDuplicate(newAccount)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Essa identificação já está cadastrada nesta rede.',
          ),
        ),
      );
      return;
    }

    if (oauthToken.isNotEmpty) {
      await _publishingService.saveSocialToken(
        accountId: accountId,
        accessToken: oauthToken,
      );
    }

    setState(() {
      _accounts.add(newAccount);
    });

    final saved = await _saveAccounts();

    if (!mounted) return;

    if (!saved) {
      setState(() {
        _accounts.removeWhere(
          (account) => account['id'] == newAccount['id'],
        );
      });
    }
  }

  Future<void> _editAccount(int index) async {
    if (_isSaving || index < 0 || index >= _accounts.length) return;

    final original = Map<String, dynamic>.from(_accounts[index]);

    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (_) => _AccountDialog(
        networks: _availableNetworks,
        initialAccount: original,
      ),
    );

    if (result == null || !mounted) return;

    final oauthToken = (result['oauthToken'] ?? '').toString().trim();
    result.remove('oauthToken');

    final updatedAccount = <String, dynamic>{
      ...original,
      ...result,
      'id': original['id'],
      'topicId': _effectiveTopicId.isEmpty ? null : _effectiveTopicId,
      'topicName': widget.topicName,
    };

    if (_isDuplicate(
      updatedAccount,
      ignoreId: original['id'] as String?,
    )) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Outra conta já utiliza essa identificação nesta rede.',
          ),
        ),
      );
      return;
    }

    if (oauthToken.isNotEmpty) {
      await _publishingService.saveSocialToken(
        accountId: original['id'].toString(),
        accessToken: oauthToken,
      );
    }

    setState(() {
      _accounts[index] = updatedAccount;
    });

    final saved = await _saveAccounts();

    if (!mounted) return;

    if (!saved) {
      setState(() {
        _accounts[index] = original;
      });
    }
  }

  Future<void> _toggleAccount(int index, bool active) async {
    if (_isSaving || index < 0 || index >= _accounts.length) return;

    final previousValue = _accounts[index]['active'];

    setState(() {
      _accounts[index]['active'] = active;
    });

    final saved = await _saveAccounts();

    if (!mounted) return;

    if (!saved) {
      setState(() {
        _accounts[index]['active'] = previousValue;
      });
    }
  }

  Future<void> _removeAccount(int index) async {
    if (_isSaving || index < 0 || index >= _accounts.length) return;

    final removedAccount = Map<String, dynamic>.from(_accounts[index]);
    final name = removedAccount['name'] as String? ?? '';

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Remover conta?'),
        content: Text('Deseja remover "$name" deste tema?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Remover'),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;

    await _publishingService.deleteSocialToken(
      removedAccount['id'].toString(),
    );

    setState(() {
      _accounts.removeAt(index);
    });

    final saved = await _saveAccounts();

    if (!mounted) return;

    if (!saved) {
      setState(() {
        _accounts.insert(
          index.clamp(0, _accounts.length),
          removedAccount,
        );
      });
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Conta "$name" removida desta lista.')),
    );
  }

  IconData _platformIcon(String platform) {
    switch (platform.toLowerCase()) {
      case 'instagram':
        return Icons.camera_alt_outlined;
      case 'facebook':
        return Icons.facebook;
      case 'tiktok':
        return Icons.music_note_outlined;
      default:
        return Icons.share_outlined;
    }
  }

  String _connectionLabel(String status) {
    switch (status) {
      case 'verified_connected':
      case 'connected':
        return 'Autenticada e verificada';
      case 'manual_required':
        return 'Autenticada (Exige finalização manual no app)';
      case 'auth_failed':
      case 'error':
        return 'Falha na verificação de token/permissão';
      default:
        return 'Apenas cadastrada (Não conectada — clique em Verificar)';
    }
  }

  @override
  Widget build(BuildContext context) {
    final activeCount =
        _accounts.where((account) => account['active'] == true).length;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.topicName),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _isLoading || _isSaving ? null : _addAccount,
        icon: const Icon(Icons.add),
        label: const Text('Adicionar conta'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _accounts.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.share_outlined, size: 52),
                        SizedBox(height: 12),
                        Text(
                          'Nenhuma conta cadastrada',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 8),
                        Text(
                          'Adicione as contas que pertencem a este tema.',
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                )
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
                  children: [
                    Text(
                      'Contas de ${widget.topicName}',
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '${_accounts.length} conta(s) cadastrada(s) • '
                      '$activeCount ativa(s)',
                    ),
                    const SizedBox(height: 12),
                    ..._accounts.asMap().entries.map((entry) {
                      final index = entry.key;
                      final account = entry.value;

                      final platform = account['platform'] as String? ?? '';
                      final name = account['name'] as String? ?? '';
                      final username = account['username'] as String? ?? '';
                      final active = account['active'] == true;
                      final formats = account['formats'] is List
                          ? List<String>.from(account['formats'] as List)
                          : <String>[];

                      final connectionStatus =
                          account['connectionStatus'] as String? ??
                              'not_configured';

                      return Card(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 6),
                          child: ListTile(
                            leading: Icon(
                              _platformIcon(platform),
                              size: 30,
                            ),
                            title: Text(name),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                if (username.isNotEmpty)
                                  Text(username.startsWith('@')
                                      ? username
                                      : '@$username'),
                                Text(
                                  '$platform • ${active ? 'Ativa' : 'Inativa'}',
                                ),
                                if (formats.isNotEmpty)
                                  Text('Formatos: ${formats.join(', ')}'),
                                Text(
                                  _connectionLabel(connectionStatus),
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    color: connectionStatus ==
                                            'verified_connected'
                                        ? Colors.green
                                        : Colors.orange,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                OutlinedButton.icon(
                                  onPressed: () => _verifyAccount(index),
                                  icon: const Icon(
                                    Icons.verified_user_outlined,
                                    size: 16,
                                  ),
                                  label: const Text(
                                    'Verificar Autenticação e Permissões',
                                  ),
                                ),
                              ],
                            ),
                            isThreeLine: true,
                            trailing: PopupMenuButton<String>(
                              enabled: !_isSaving,
                              onSelected: (value) {
                                if (value == 'edit') {
                                  _editAccount(index);
                                } else if (value == 'toggle') {
                                  _toggleAccount(index, !active);
                                } else if (value == 'delete') {
                                  _removeAccount(index);
                                }
                              },
                              itemBuilder: (_) => [
                                const PopupMenuItem(
                                  value: 'edit',
                                  child: Text('Editar conta'),
                                ),
                                PopupMenuItem(
                                  value: 'toggle',
                                  child: Text(
                                    active
                                        ? 'Desativar conta'
                                        : 'Ativar conta',
                                  ),
                                ),
                                const PopupMenuItem(
                                  value: 'delete',
                                  child: Text('Remover conta'),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    }),
                    if (_isSaving)
                      const Padding(
                        padding: EdgeInsets.only(top: 8),
                        child: LinearProgressIndicator(),
                      ),
                  ],
                ),
    );
  }
}

class _AccountDialog extends StatefulWidget {
  final List<SocialNetwork> networks;
  final Map<String, dynamic>? initialAccount;

  const _AccountDialog({
    required this.networks,
    this.initialAccount,
  });

  @override
  State<_AccountDialog> createState() => _AccountDialogState();
}

class _AccountDialogState extends State<_AccountDialog> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController _nameController;
  late final TextEditingController _usernameController;
  late final TextEditingController _externalIdController;
  late final TextEditingController _oauthTokenController;

  late SocialNetwork _selectedNetwork;
  late Set<String> _selectedFormats;
  late bool _tiktokDirectPostApproved;

  bool get _isEditing => widget.initialAccount != null;

  @override
  void initState() {
    super.initState();

    final initial = widget.initialAccount;

    _nameController = TextEditingController(
      text: initial?['name'] as String? ?? '',
    );

    _usernameController = TextEditingController(
      text: initial?['username'] as String? ?? '',
    );

    _externalIdController = TextEditingController(
      text: initial?['externalAccountId'] as String? ?? '',
    );

    _oauthTokenController = TextEditingController();

    final initialNetworkId = initial?['networkId'] as String? ?? '';

    _selectedNetwork = widget.networks.firstWhere(
      (network) => network.id == initialNetworkId,
      orElse: () => widget.networks.first,
    );

    final savedFormats = initial?['formats'];

    _selectedFormats = savedFormats is List
        ? Set<String>.from(savedFormats)
        : {
            'Legenda',
            'Carrossel',
            'Vídeo',
            'Publicação completa',
          };

    _tiktokDirectPostApproved = initial?['tiktokDirectPostApproved'] == true;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _usernameController.dispose();
    _externalIdController.dispose();
    _oauthTokenController.dispose();
    super.dispose();
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;

    Navigator.of(context).pop({
      'platform': _selectedNetwork.name,
      'networkId': _selectedNetwork.id,
      'name': _nameController.text.trim(),
      'username': _usernameController.text.trim(),
      'externalAccountId': _externalIdController.text.trim(),
      'oauthToken': _oauthTokenController.text.trim(),
      'tiktokDirectPostApproved': _tiktokDirectPostApproved,
      'formats': _selectedFormats.toList(),
      'active': widget.initialAccount?['active'] == false ? false : true,
    });
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(_isEditing ? 'Editar conta' : 'Adicionar conta'),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<String>(
                initialValue: _selectedNetwork.id,
                isExpanded: true,
                decoration: const InputDecoration(
                  labelText: 'Rede social',
                  border: OutlineInputBorder(),
                ),
                items: widget.networks.map((network) {
                  return DropdownMenuItem<String>(
                    value: network.id,
                    child: Text(network.name),
                  );
                }).toList(),
                onChanged: (value) {
                  if (value == null) return;

                  final selected = widget.networks.firstWhere(
                    (network) => network.id == value,
                  );

                  setState(() {
                    _selectedNetwork = selected;
                  });
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Nome da página ou conta',
                  hintText: 'Minha página de conteúdo',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value == null || value.trim().isEmpty
                    ? 'Informe o nome da conta.'
                    : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _usernameController,
                decoration: const InputDecoration(
                  labelText: '@usuário',
                  hintText: '@minhaconta',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _externalIdController,
                decoration: const InputDecoration(
                  labelText:
                      'ID Oficial na Plataforma (IG User ID / Page ID / TikTok Open ID)',
                  hintText: 'Ex.: 17841400000000000',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _oauthTokenController,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Token OAuth Oficial (armazenamento seguro separado)',
                  hintText: 'Cole o Access Token da conta/página',
                  border: OutlineInputBorder(),
                ),
              ),
              if (_selectedNetwork.id.toLowerCase().contains('tiktok')) ...[
                const SizedBox(height: 8),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Escopo Direct Post aprovado no TikTok'),
                  subtitle: const Text(
                    'Se desativado, o TikTok enviará o vídeo para o Inbox e exigirá finalização manual no app.',
                  ),
                  value: _tiktokDirectPostApproved,
                  onChanged: (val) =>
                      setState(() => _tiktokDirectPostApproved = val),
                ),
              ],
              const SizedBox(height: 16),
              const Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Formatos aceitos',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(height: 8),
              ..._SocialNetworksScreenStateFormats.values.map((format) {
                return CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  title: Text(format),
                  value: _selectedFormats.contains(format),
                  onChanged: (selected) {
                    setState(() {
                      if (selected == true) {
                        _selectedFormats.add(format);
                      } else {
                        _selectedFormats.remove(format);
                      }
                    });
                  },
                );
              }),
              const SizedBox(height: 8),
              const Text(
                'Regra de Segurança: O simples cadastro não marca a conta como conectada. Use o botão "Verificar Autenticação e Permissões" no cartão da conta.',
                style: TextStyle(fontSize: 12),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancelar'),
        ),
        FilledButton(
          onPressed: _submit,
          child: Text(_isEditing ? 'Salvar alterações' : 'Adicionar'),
        ),
      ],
    );
  }
}

class _SocialNetworksScreenStateFormats {
  static const List<String> values = [
    'Legenda',
    'Carrossel',
    'Vídeo',
    'Publicação completa',
  ];
}
