import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

import '../models/media_item.dart';
import '../models/post_schedule.dart';
import '../services/api_provider_credentials_storage.dart';
import '../services/content_verification_service.dart';
import '../services/media_library_service.dart';
import '../services/post_schedule_service.dart';
import 'media_library_screen.dart';

class PostScheduleScreen extends StatefulWidget {
  final PostSchedule? scheduleToEdit;

  const PostScheduleScreen({
    super.key,
    this.scheduleToEdit,
  });

  @override
  State<PostScheduleScreen> createState() => _PostScheduleScreenState();
}

class _PostScheduleScreenState extends State<PostScheduleScreen> {
  static const String _topicsStorageKey = 'content_topics_v2';

  final _formKey = GlobalKey<FormState>();
  final _contentController = TextEditingController();
  final _captionController = TextEditingController();
  final _videoScriptController = TextEditingController();
  final _videoPromptController = TextEditingController();
  final _sourcesController = TextEditingController();

  final List<TextEditingController> _carouselSlideControllers = [];
  List<String> _carouselImageUrls = [];
  List<String> _extraAdSlideTexts = [];
  List<String> _extraAdSlideImageUrls = [];

  String? _videoUrl;
  String? _videoApiAccountId;
  String? _videoApiProvider;
  VideoPlayerController? _videoController;
  bool _videoInitializing = false;
  String? _videoPreviewError;
  double _videoVolume = 1.0;
  int _currentSlideIndex = 0;

  final PostScheduleService _service = PostScheduleService();
  final ContentVerificationService _verificationService =
      ContentVerificationService();
  final MediaLibraryService _mediaLibraryService = MediaLibraryService();

  final List<String> _networks = [
    'Instagram',
    'Facebook',
    'TikTok',
    'YouTube',
    'LinkedIn',
    'X',
  ];

  final List<String> _formats = const [
    'Legenda',
    'Carrossel',
    'Roteiro para vídeo',
    'Publicação completa',
  ];

  List<Map<String, dynamic>> _topics = [];

  String? _selectedTopicId;
  String? _selectedNetwork = 'Instagram';

  String _contentFormat = 'Legenda';
  String _approvalStatus = 'Pendente';

  bool _automatic = false;
  bool _saving = false;
  bool _loadingTopics = true;

  DateTime? _scheduledAt;
  DateTime? _reEvaluateAt;

  bool get _isEditing => widget.scheduleToEdit != null;

  Map<String, dynamic>? get _selectedTopic {
    for (final topic in _topics) {
      if (topic['id'] == _selectedTopicId) {
        return topic;
      }
    }
    return null;
  }

  bool get _hasVideo =>
      _contentFormat == 'Roteiro para vídeo' ||
      _contentFormat == 'Publicação completa';

  bool get _hasCarousel =>
      _contentFormat == 'Carrossel' ||
      _contentFormat == 'Publicação completa';

  @override
  void initState() {
    super.initState();
    _loadInitialData();
  }

  Future<void> _loadInitialData() async {
    await _loadTopics();

    if (!mounted) return;

    final original = widget.scheduleToEdit;

    if (original != null) {
      _contentController.text = original.content;
      _captionController.text = original.caption;
      _videoScriptController.text = original.videoScript ?? '';
      _videoPromptController.text = original.videoPrompt ?? '';
      _sourcesController.text = original.evidenceSources.join('\n');
      _carouselImageUrls = List<String>.from(original.carouselImageUrls);
      _extraAdSlideTexts = List<String>.from(original.extraAdSlideTexts);
      _extraAdSlideImageUrls =
          List<String>.from(original.extraAdSlideImageUrls);
      _videoUrl = original.videoUrl;
      _videoApiAccountId = original.videoApiAccountId;
      _videoApiProvider = original.videoApiProvider;
      _reEvaluateAt = original.reEvaluateAt;

      if (_videoUrl != null && _videoUrl!.trim().isNotEmpty) {
        _initializeVideoPreview(
          _videoUrl!,
          accountId: _videoApiAccountId,
          provider: _videoApiProvider,
        );
      }

      _selectedNetwork = original.network;
      _selectedTopicId = original.topicId;
      _contentFormat = original.contentFormat;
      _approvalStatus = original.approvalStatus;
      _automatic = original.automatic;
      _scheduledAt = original.scheduledAt;

      if (!_networks.contains(_selectedNetwork)) {
        _networks.add(_selectedNetwork!);
      }

      if (!_formats.contains(_contentFormat)) {
        _contentFormat = 'Legenda';
      }

      if (_selectedTopicId != null &&
          !_topics.any((topic) => topic['id'] == _selectedTopicId)) {
        _selectedTopicId = null;
      }
    } else if (_topics.isNotEmpty) {
      _selectedTopicId = _topics.first['id'] as String;
    }

    for (final controller in _carouselSlideControllers) {
      controller.dispose();
    }
    _carouselSlideControllers.clear();
    final savedSlides = original?.carouselSlides ?? const <String>[];
    final normalizedSlides =
        PostSchedule.ensureMandatoryFourthSlide(savedSlides);
    for (var index = 0; index < 4; index++) {
      _carouselSlideControllers.add(
        TextEditingController(
          text: normalizedSlides[index],
        ),
      );
    }
    _currentSlideIndex = 0;

    if (!mounted) return;

    setState(() {});
  }

  ImageProvider _imageProvider(String source) {
    if (source.startsWith('data:') && source.contains(',')) {
      return MemoryImage(
        base64Decode(source.substring(source.indexOf(',') + 1)),
      );
    }
    return NetworkImage(source);
  }

  Future<void> _initializeVideoPreview(
    String url, {
    String? accountId,
    String? provider,
  }) async {
    final previous = _videoController;
    _videoController = null;
    await previous?.dispose();
    if (!mounted) return;
    setState(() {
      _videoInitializing = true;
      _videoPreviewError = null;
    });
    try {
      final uri = Uri.parse(url);
      final headers = <String, String>{};
      if ((provider ?? '').toLowerCase().contains('google') ||
          (provider ?? '').toLowerCase().contains('gemini')) {
        if (uri.host == 'generativelanguage.googleapis.com' &&
            accountId != null &&
            accountId.trim().isNotEmpty) {
          final key =
              await ApiProviderCredentialsStorage().readCredential(accountId);
          if (key != null && key.trim().isNotEmpty) {
            headers['x-goog-api-key'] = key.trim();
          }
        }
      }
      final controller = VideoPlayerController.networkUrl(
        uri,
        httpHeaders: headers,
      );
      await controller.initialize().timeout(const Duration(seconds: 45));
      await controller.setVolume(_videoVolume);
      controller.addListener(() {
        if (mounted) setState(() {});
      });
      if (!mounted) {
        await controller.dispose();
        return;
      }
      setState(() {
        _videoController = controller;
        _videoInitializing = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _videoInitializing = false;
        _videoPreviewError = error.toString();
      });
    }
  }

  Future<void> _loadTopics() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final storedData = prefs.getString(_topicsStorageKey);

      if (storedData != null && storedData.isNotEmpty) {
        final decoded = jsonDecode(storedData);

        if (decoded is List) {
          _topics = decoded
              .whereType<Map>()
              .map((item) => Map<String, dynamic>.from(item))
              .where((topic) {
                final id = topic['id'];
                final name = topic['name'];

                return topic['active'] == true &&
                    id is String &&
                    id.trim().isNotEmpty &&
                    name is String &&
                    name.trim().isNotEmpty;
              })
              .toList();
        }
      }
    } catch (_) {
      _topics = [];
    }

    if (!mounted) return;

    setState(() {
      _loadingTopics = false;
    });
  }

  Future<void> _selectDateTime() async {
    final now = DateTime.now();

    final date = await showDatePicker(
      context: context,
      initialDate: _scheduledAt ?? now,
      firstDate: DateTime(now.year, now.month, now.day),
      lastDate: DateTime(now.year + 5),
    );

    if (date == null || !mounted) return;

    final time = await showTimePicker(
      context: context,
      initialTime: _scheduledAt != null
          ? TimeOfDay.fromDateTime(_scheduledAt!)
          : TimeOfDay.fromDateTime(now),
    );

    if (time == null || !mounted) return;

    setState(() {
      _scheduledAt = DateTime(
        date.year,
        date.month,
        date.day,
        time.hour,
        time.minute,
      );
    });
  }

  String _formatDateTime(DateTime date) {
    final day = date.day.toString().padLeft(2, '0');
    final month = date.month.toString().padLeft(2, '0');
    final hour = date.hour.toString().padLeft(2, '0');
    final minute = date.minute.toString().padLeft(2, '0');

    return '$day/$month/${date.year} às $hour:$minute';
  }

  String _formatDuration(Duration d) {
    final min = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final sec = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$min:$sec';
  }

  Future<void> _addExtraAdSlide() async {
    final textCtrl = TextEditingController();
    final urlCtrl = TextEditingController();

    final added = await showDialog<Map<String, String>>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Adicionar Slide Extra de Publicidade'),
        content: SizedBox(
          width: 420,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: textCtrl,
                minLines: 2,
                maxLines: 4,
                decoration: const InputDecoration(
                  labelText: 'Texto / Chamada Publicitária do Slide Extra',
                  hintText: 'Ex.: Oferta exclusiva do parceiro — acesse o link!',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: urlCtrl,
                decoration: const InputDecoration(
                  labelText: 'URL da Imagem de Publicidade (opcional)',
                  hintText: 'https://...',
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () {
              if (textCtrl.text.trim().isEmpty) return;
              Navigator.pop(ctx, {
                'text': textCtrl.text.trim(),
                'url': urlCtrl.text.trim(),
              });
            },
            child: const Text('Adicionar Slide'),
          ),
        ],
      ),
    );

    textCtrl.dispose();
    urlCtrl.dispose();

    if (added != null) {
      setState(() {
        _extraAdSlideTexts.add(added['text']!);
        if (added['url']!.isNotEmpty) {
          _extraAdSlideImageUrls.add(added['url']!);
        }
      });
    }
  }

  Future<void> _pickMediaFromLibrary({required bool forVideo}) async {
    final selectedUrl = await Navigator.push<String>(
      context,
      MaterialPageRoute(
        builder: (_) => const MediaLibraryScreen(selectionMode: true),
      ),
    );
    if (selectedUrl == null || !mounted) return;
    setState(() {
      if (forVideo) {
        _videoUrl = selectedUrl;
        _initializeVideoPreview(selectedUrl);
      } else {
        _carouselImageUrls.add(selectedUrl);
      }
    });
  }

  Future<void> _saveVideoToLibrary() async {
    if (_videoUrl == null || _videoUrl!.trim().isEmpty) return;
    await _mediaLibraryService.add(
      MediaItem(
        id: 'vid_${DateTime.now().microsecondsSinceEpoch}',
        title: '${_selectedTopic?['name'] ?? "Vídeo"} • Postagem',
        mediaType: 'video',
        url: _videoUrl!,
        topicId: _selectedTopicId,
        topicName: _selectedTopic?['name']?.toString(),
        providerName: _videoApiProvider ?? 'Player',
        createdAt: DateTime.now(),
      ),
    );
    if (!mounted) return;
    _showMessage('Vídeo salvo na Biblioteca de Mídia!');
  }

  void _openFullscreenVideo() {
    if (_videoController == null || !_videoController!.value.isInitialized) {
      return;
    }
    showDialog<void>(
      context: context,
      builder: (ctx) => Dialog.fullscreen(
        backgroundColor: Colors.black,
        child: SafeArea(
          child: Stack(
            alignment: Alignment.center,
            children: [
              Center(
                child: AspectRatio(
                  aspectRatio: _videoController!.value.aspectRatio,
                  child: VideoPlayer(_videoController!),
                ),
              ),
              Positioned(
                top: 16,
                right: 16,
                child: IconButton.filled(
                  onPressed: () => Navigator.pop(ctx),
                  icon: const Icon(Icons.fullscreen_exit),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openZoomableSlideModal(int slideIndex, String slideText, String? imageUrl) {
    showDialog<void>(
      context: context,
      builder: (ctx) => Dialog(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 640, maxHeight: 720),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  children: [
                    Text(
                      'Inspeção Ampliada • Slide ${slideIndex + 1}',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                      onPressed: () => Navigator.pop(ctx),
                      icon: const Icon(Icons.close),
                    ),
                  ],
                ),
                Expanded(
                  child: InteractiveViewer(
                    minScale: 0.8,
                    maxScale: 4.0,
                    child: _buildVisualSlideCard(
                      index: slideIndex,
                      total: 4 + _extraAdSlideTexts.length,
                      text: slideText,
                      imageUrl: imageUrl,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _saveSchedule() async {
    if (_saving) return;
    if (!_formKey.currentState!.validate()) return;

    final rawSlides = _hasCarousel
        ? _carouselSlideControllers.map((c) => c.text.trim()).toList()
        : const <String>[];
    final finalSlides = _hasCarousel
        ? PostSchedule.ensureMandatoryFourthSlide(rawSlides)
        : const <String>[];

    final sourcesList = _sourcesController.text
        .split('\n')
        .map((s) => s.trim())
        .where((s) => s.isNotEmpty)
        .toList();

    final verification = _verificationService.verifyContent(
      content: '${_captionController.text}\n${_contentController.text}',
      explicitSources: sourcesList,
    );

    if (_approvalStatus == 'Aprovado' &&
        ((_hasCarousel && _carouselImageUrls.length < 4) ||
            (_hasVideo && (_videoUrl == null || _videoUrl!.trim().isEmpty)))) {
      _showMessage(
        'A aprovação está bloqueada: faltam imagens ou vídeo reais. Gere ou anexe todos os arquivos antes de aprovar.',
      );
      return;
    }

    if (_automatic && !verification.hasSufficientEvidence) {
      _showMessage(
        'Publicação automática bloqueada: ${verification.warnings.join(" ")}',
      );
      return;
    }

    if (_selectedNetwork == null) return;

    final topic = _selectedTopic;

    if (topic == null) {
      _showMessage('Selecione um tema ativo.');
      return;
    }

    if (_automatic &&
        (_scheduledAt == null || !_scheduledAt!.isAfter(DateTime.now()))) {
      _showMessage('Escolha uma data e um horário futuros.');
      return;
    }

    setState(() {
      _saving = true;
    });

    try {
      final now = DateTime.now();
      final original = widget.scheduleToEdit;
      final isReEvaluateLater = _approvalStatus == 'Reavaliar mais tarde';
      final computedReEvalDate = isReEvaluateLater
          ? ContentVerificationService.addSixMonths(now)
          : _reEvaluateAt;

      final schedule = PostSchedule(
        id: original?.id ?? now.microsecondsSinceEpoch.toString(),
        network: _selectedNetwork!,
        content: _contentController.text.trim(),
        caption: _captionController.text.trim(),
        contentFormat: _contentFormat,
        topicId: _selectedTopicId,
        topicName: topic['name'] as String,
        videoScript: _videoScriptController.text.trim(),
        videoUrl: _videoUrl,
        videoApiAccountId: _videoApiAccountId,
        videoApiProvider: _videoApiProvider,
        carouselImageUrls: _carouselImageUrls,
        extraAdSlideTexts: _extraAdSlideTexts,
        extraAdSlideImageUrls: _extraAdSlideImageUrls,
        evidenceSources: verification.detectedSources,
        hasSufficientEvidence: verification.hasSufficientEvidence,
        reEvaluateAt: computedReEvalDate,
        videoPrompt: _videoPromptController.text.trim(),
        lastError: original?.lastError,
        carouselSlides: finalSlides,
        scheduledAt: _automatic && !isReEvaluateLater ? _scheduledAt : null,
        scheduleStatus: isReEvaluateLater
            ? 'Reavaliar em 6 meses'
            : (_automatic ? 'Agendado' : 'Rascunho'),
        approvalStatus: _approvalStatus,
        automatic: isReEvaluateLater ? false : _automatic,
        status: isReEvaluateLater
            ? 'Reavaliar mais tarde'
            : (_automatic ? 'Agendada' : 'Rascunho'),
        createdAt: original?.createdAt ?? now,
        updatedAt: now,
        version: (original?.version ?? 0) + 1,
      );

      if (isReEvaluateLater) {
        await _verificationService.markReEvaluateLater(schedule);
      } else {
        final saved = _isEditing
            ? await _service.update(schedule)
            : await _service.add(schedule);
        if (!saved) {
          if (mounted) {
            _showMessage('Não foi possível salvar a postagem.');
          }
          return;
        }
      }

      if (!mounted) return;

      _showMessage(
        isReEvaluateLater
            ? 'Postagem marcada como "Reavaliar mais tarde"! Nova verificação agendada para +6 meses.'
            : (_isEditing
                ? 'Postagem atualizada com sucesso!'
                : 'Postagem salva com sucesso!'),
      );

      if (_isEditing) {
        Navigator.pop(context, true);
      } else {
        _formKey.currentState!.reset();
        _contentController.clear();
        _captionController.clear();
        _videoScriptController.clear();
        _videoPromptController.clear();
        _sourcesController.clear();

        setState(() {
          _selectedNetwork = 'Instagram';
          _selectedTopicId =
              _topics.isNotEmpty ? _topics.first['id'] as String : null;
          _contentFormat = 'Legenda';
          _approvalStatus = 'Pendente';
          _automatic = false;
          _scheduledAt = null;
        });
      }
    } catch (error) {
      if (!mounted) return;
      _showMessage('Erro ao salvar: $error');
    } finally {
      if (mounted) {
        setState(() {
          _saving = false;
        });
      }
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  void dispose() {
    _contentController.dispose();
    _captionController.dispose();
    _videoScriptController.dispose();
    _videoPromptController.dispose();
    _sourcesController.dispose();
    _videoController?.dispose();
    for (final controller in _carouselSlideControllers) {
      controller.dispose();
    }
    super.dispose();
  }

  Widget _buildVisualSlideCard({
    required int index,
    required int total,
    required String text,
    String? imageUrl,
    bool isExtraAd = false,
  }) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (imageUrl != null && imageUrl.trim().isNotEmpty)
            Image(
              image: _imageProvider(imageUrl),
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                color: const Color(0xFF1E293B),
              ),
            )
          else
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF0F172A), Color(0xFF1E3A8A)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
            ),
          // Camada escura (Scrim) para legibilidade máxima do texto sobre o fundo visual
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.black.withValues(alpha: 0.45),
                  Colors.black.withValues(alpha: 0.78),
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
          // Numeração do Slide no topo direito
          Positioned(
            top: 12,
            right: 12,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: isExtraAd
                    ? Colors.amber.withValues(alpha: 0.9)
                    : Colors.black.withValues(alpha: 0.65),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                isExtraAd
                    ? 'PUBLICIDADE • ${index + 1}/$total'
                    : 'Slide ${index + 1}/$total',
                style: TextStyle(
                  color: isExtraAd ? Colors.black : Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          // Texto centralizado com alto contraste
          Padding(
            padding: const EdgeInsets.all(20),
            child: Center(
              child: SingleChildScrollView(
                child: Text(
                  text.trim().isEmpty
                      ? (index == 3
                          ? PostSchedule.mandatoryFourthSlidePhrase
                          : 'Slide ${index + 1}')
                      : text,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    height: 1.4,
                    shadows: [
                      Shadow(
                        color: Colors.black87,
                        blurRadius: 6,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loadingTopics) {
      return Scaffold(
        appBar: AppBar(
          title: Text(_isEditing ? 'Editar Postagem' : 'Nova Postagem'),
        ),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    final totalSlidesCount = 4 + _extraAdSlideTexts.length;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          _isEditing ? 'Editar Postagem' : 'Configuração de Postagens',
        ),
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 760),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    _isEditing ? 'Editar postagem' : 'Nova postagem',
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Organize o conteúdo, o carrossel de 4 slides + publicidade, o player de vídeo com áudio, as fontes e a aprovação.',
                  ),
                  const SizedBox(height: 24),

                  DropdownButtonFormField<String>(
                    initialValue: _selectedTopicId,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'Tema',
                      border: OutlineInputBorder(),
                    ),
                    items: _topics.map((topic) {
                      return DropdownMenuItem<String>(
                        value: topic['id'] as String,
                        child: Text(topic['name'] as String),
                      );
                    }).toList(),
                    onChanged: _saving
                        ? null
                        : (value) {
                            setState(() {
                              _selectedTopicId = value;
                            });
                          },
                    validator: (value) {
                      if (value == null) {
                        return 'Selecione um tema ativo.';
                      }
                      return null;
                    },
                  ),

                  const SizedBox(height: 16),

                  DropdownButtonFormField<String>(
                    initialValue: _selectedNetwork,
                    decoration: const InputDecoration(
                      labelText: 'Rede social',
                      border: OutlineInputBorder(),
                    ),
                    items: _networks.map((network) {
                      return DropdownMenuItem<String>(
                        value: network,
                        child: Text(network),
                      );
                    }).toList(),
                    onChanged: _saving
                        ? null
                        : (value) {
                            setState(() {
                              _selectedNetwork = value;
                            });
                          },
                    validator: (value) =>
                        value == null ? 'Escolha uma rede social.' : null,
                  ),

                  const SizedBox(height: 16),

                  DropdownButtonFormField<String>(
                    initialValue: _contentFormat,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'Formato do conteúdo',
                      border: OutlineInputBorder(),
                    ),
                    items: _formats.map((format) {
                      return DropdownMenuItem<String>(
                        value: format,
                        child: Text(format),
                      );
                    }).toList(),
                    onChanged: _saving
                        ? null
                        : (value) {
                            if (value != null) {
                              setState(() {
                                _contentFormat = value;
                              });
                            }
                          },
                  ),

                  const SizedBox(height: 16),

                  TextFormField(
                    controller: _captionController,
                    minLines: 3,
                    maxLines: 6,
                    maxLength: 5000,
                    enabled: !_saving,
                    decoration: const InputDecoration(
                      labelText: 'Legenda',
                      hintText: 'Digite a legenda da publicação...',
                      border: OutlineInputBorder(),
                      alignLabelWithHint: true,
                    ),
                  ),

                  const SizedBox(height: 16),

                  TextFormField(
                    controller: _contentController,
                    minLines: 5,
                    maxLines: 10,
                    maxLength: 10000,
                    enabled: !_saving,
                    decoration: const InputDecoration(
                      labelText: 'Conteúdo / material da publicação',
                      hintText: 'Escreva ou cole o conteúdo aqui...',
                      border: OutlineInputBorder(),
                      alignLabelWithHint: true,
                    ),
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return 'Digite o conteúdo da postagem.';
                      }
                      return null;
                    },
                  ),

                  const SizedBox(height: 16),

                  TextFormField(
                    controller: _sourcesController,
                    minLines: 2,
                    maxLines: 4,
                    enabled: !_saving,
                    decoration: const InputDecoration(
                      labelText:
                          'Fontes confiáveis e evidências (1 por linha)',
                      hintText: 'https://...',
                      border: OutlineInputBorder(),
                    ),
                  ),

                  if (_hasCarousel) ...[
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        const Expanded(
                          child: ListTile(
                            contentPadding: EdgeInsets.zero,
                            leading: Icon(Icons.view_carousel_outlined),
                            title: Text(
                              'Montador de Carrossel (4 Slides + Publicidade)',
                            ),
                            subtitle: Text(
                              'Toque na prévia para ampliar (zoom). O 4º slide inclui a frase obrigatória.',
                            ),
                          ),
                        ),
                        OutlinedButton.icon(
                          onPressed: _addExtraAdSlide,
                          icon: const Icon(Icons.add_business_outlined),
                          label: const Text('+ Slide Publicidade'),
                        ),
                      ],
                    ),
                    // Prévia Visual dos Slides com texto sobreposto e numeração
                    SizedBox(
                      height: 260,
                      child: PageView.builder(
                        itemCount: totalSlidesCount,
                        onPageChanged: (index) {
                          setState(() => _currentSlideIndex = index);
                        },
                        itemBuilder: (context, index) {
                          final isExtra = index >= 4;
                          final slideText = isExtra
                              ? _extraAdSlideTexts[index - 4]
                              : _carouselSlideControllers[index].text;
                          final imgUrl = isExtra
                              ? ((index - 4) < _extraAdSlideImageUrls.length
                                  ? _extraAdSlideImageUrls[index - 4]
                                  : null)
                              : (index < _carouselImageUrls.length
                                  ? _carouselImageUrls[index]
                                  : null);
                          return Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 6),
                            child: GestureDetector(
                              onTap: () => _openZoomableSlideModal(
                                index,
                                slideText,
                                imgUrl,
                              ),
                              child: _buildVisualSlideCard(
                                index: index,
                                total: totalSlidesCount,
                                text: slideText,
                                imageUrl: imgUrl,
                                isExtraAd: isExtra,
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 8),
                    Center(
                      child: Text(
                        'Visualizando Slide ${_currentSlideIndex + 1} de $totalSlidesCount (Toque no slide para dar Zoom)',
                      ),
                    ),
                    const SizedBox(height: 12),
                    for (var i = 0; i < 4; i++)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: TextFormField(
                          controller: _carouselSlideControllers[i],
                          minLines: 2,
                          maxLines: 4,
                          onChanged: (_) => setState(() {}),
                          decoration: InputDecoration(
                            labelText: i == 3
                                ? 'Slide 4 de 4 (Inclui frase obrigatória de engajamento)'
                                : 'Texto do Slide ${i + 1} de 4',
                            border: const OutlineInputBorder(),
                          ),
                        ),
                      ),
                    Wrap(
                      spacing: 8,
                      children: [
                        OutlinedButton.icon(
                          onPressed: () =>
                              _pickMediaFromLibrary(forVideo: false),
                          icon: const Icon(Icons.perm_media_outlined),
                          label: const Text('Anexar Imagem da Biblioteca'),
                        ),
                      ],
                    ),
                  ],

                  if (_hasVideo) ...[
                    const SizedBox(height: 16),
                    if (_videoUrl != null && _videoUrl!.trim().isNotEmpty) ...[
                      Card(
                        clipBehavior: Clip.antiAlias,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            if (_videoInitializing)
                              const SizedBox(
                                height: 200,
                                child:
                                    Center(child: CircularProgressIndicator()),
                              )
                            else if (_videoController?.value.isInitialized ==
                                true) ...[
                              AspectRatio(
                                aspectRatio:
                                    _videoController!.value.aspectRatio,
                                child: VideoPlayer(_videoController!),
                              ),
                              // CONTROLES COMPLETOS DE REPRODUÇÃO, PAUSA, VOLUME, DURAÇÃO E TELA CHEIA
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 8,
                                ),
                                child: Column(
                                  children: [
                                    VideoProgressIndicator(
                                      _videoController!,
                                      allowScrubbing: true,
                                    ),
                                    const SizedBox(height: 6),
                                    Row(
                                      children: [
                                        IconButton(
                                          tooltip: _videoController!
                                                  .value.isPlaying
                                              ? 'Pausar'
                                              : 'Reproduzir',
                                          onPressed: () => setState(() {
                                            _videoController!.value.isPlaying
                                                ? _videoController!.pause()
                                                : _videoController!.play();
                                          }),
                                          icon: Icon(
                                            _videoController!.value.isPlaying
                                                ? Icons.pause_circle_filled
                                                : Icons.play_circle_filled,
                                            size: 32,
                                          ),
                                        ),
                                        Text(
                                          '${_formatDuration(_videoController!.value.position)} / ${_formatDuration(_videoController!.value.duration)}',
                                          style: const TextStyle(fontSize: 12),
                                        ),
                                        const SizedBox(width: 12),
                                        Icon(
                                          _videoVolume == 0
                                              ? Icons.volume_off
                                              : Icons.volume_up,
                                          size: 20,
                                        ),
                                        Expanded(
                                          child: Slider(
                                            value: _videoVolume,
                                            min: 0.0,
                                            max: 1.0,
                                            onChanged: (val) async {
                                              setState(
                                                  () => _videoVolume = val);
                                              await _videoController!
                                                  .setVolume(val);
                                            },
                                          ),
                                        ),
                                        IconButton(
                                          tooltip: 'Tela cheia',
                                          onPressed: _openFullscreenVideo,
                                          icon: const Icon(Icons.fullscreen),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ] else
                              Padding(
                                padding: const EdgeInsets.all(12),
                                child: Text(
                                  _videoPreviewError == null
                                      ? 'O vídeo foi gerado, mas ainda não foi possível carregar a prévia.'
                                      : 'Falha ao carregar o vídeo: $_videoPreviewError',
                                ),
                              ),
                            ListTile(
                              leading: const Icon(Icons.video_file),
                              title: const Text('Vídeo com áudio configurado'),
                              subtitle: SelectableText(_videoUrl!),
                              trailing: Wrap(
                                spacing: 4,
                                children: [
                                  IconButton(
                                    tooltip: 'Salvar na Biblioteca de Mídia',
                                    icon: const Icon(Icons.bookmark_add_outlined),
                                    onPressed: _saveVideoToLibrary,
                                  ),
                                  IconButton(
                                    tooltip: 'Copiar endereço do vídeo',
                                    icon: const Icon(Icons.copy),
                                    onPressed: () => Clipboard.setData(
                                      ClipboardData(text: _videoUrl!),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                    const SizedBox(height: 12),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: OutlinedButton.icon(
                        onPressed: () =>
                            _pickMediaFromLibrary(forVideo: true),
                        icon: const Icon(Icons.video_library_outlined),
                        label: const Text('Selecionar Vídeo da Biblioteca'),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _videoScriptController,
                      minLines: 4,
                      maxLines: 8,
                      enabled: !_saving,
                      decoration: const InputDecoration(
                        labelText: 'Roteiro do vídeo',
                        hintText: 'Cenas, narração e sequência do vídeo...',
                        border: OutlineInputBorder(),
                        alignLabelWithHint: true,
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _videoPromptController,
                      minLines: 3,
                      maxLines: 6,
                      enabled: !_saving,
                      decoration: const InputDecoration(
                        labelText: 'Orientações para produção do vídeo',
                        hintText: 'Descreva o estilo visual e os detalhes...',
                        border: OutlineInputBorder(),
                        alignLabelWithHint: true,
                      ),
                    ),
                  ],

                  const SizedBox(height: 20),

                  DropdownButtonFormField<String>(
                    initialValue: _approvalStatus,
                    decoration: const InputDecoration(
                      labelText:
                          'Status de aprovação e verificação de conteúdo',
                      border: OutlineInputBorder(),
                    ),
                    items: const [
                      DropdownMenuItem(
                        value: 'Pendente',
                        child: Text('Pendente (Revisão Humana)'),
                      ),
                      DropdownMenuItem(
                        value: 'Aprovado',
                        child: Text('Aprovado (Evidências Verificadas)'),
                      ),
                      DropdownMenuItem(
                        value: 'Reavaliar mais tarde',
                        child: Text(
                          'Reavaliar mais tarde (Programar nova verificação em 6 meses)',
                        ),
                      ),
                      DropdownMenuItem(
                        value: 'Reprovado',
                        child: Text('Reprovado'),
                      ),
                    ],
                    onChanged: _saving
                        ? null
                        : (value) {
                            if (value != null) {
                              setState(() {
                                _approvalStatus = value;
                                if (value == 'Reavaliar mais tarde') {
                                  _automatic = false;
                                }
                              });
                            }
                          },
                  ),

                  const SizedBox(height: 12),

                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Agendar postagem automática'),
                    subtitle: const Text(
                      'Exige conteúdo Aprovado e com evidências verificadas.',
                    ),
                    value: _automatic,
                    onChanged: _saving ||
                            _approvalStatus == 'Reavaliar mais tarde'
                        ? null
                        : (value) {
                            setState(() {
                              _automatic = value;
                              if (!value) {
                                _scheduledAt = null;
                              }
                            });
                          },
                  ),

                  if (_automatic) ...[
                    const SizedBox(height: 8),
                    OutlinedButton.icon(
                      onPressed: _saving ? null : _selectDateTime,
                      icon: const Icon(Icons.calendar_month),
                      label: Text(
                        _scheduledAt == null
                            ? 'Escolher data e horário'
                            : _formatDateTime(_scheduledAt!),
                      ),
                    ),
                  ],

                  const SizedBox(height: 24),

                  FilledButton.icon(
                    onPressed: _saving ? null : _saveSchedule,
                    icon: _saving
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                            ),
                          )
                        : Icon(
                            _isEditing ? Icons.save_as : Icons.save,
                          ),
                    label: Text(
                      _saving
                          ? 'Salvando...'
                          : _isEditing
                              ? 'Salvar alterações'
                              : 'Salvar configuração',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
