import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/media_item.dart';
import '../services/media_library_service.dart';

class MediaLibraryScreen extends StatefulWidget {
  final bool selectionMode;

  const MediaLibraryScreen({
    super.key,
    this.selectionMode = false,
  });

  @override
  State<MediaLibraryScreen> createState() => _MediaLibraryScreenState();
}

class _MediaLibraryScreenState extends State<MediaLibraryScreen> {
  final MediaLibraryService _service = MediaLibraryService();
  final TextEditingController _searchController = TextEditingController();

  List<MediaItem> _items = [];
  String _selectedType = 'all';
  int _cachedBytes = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadMedia();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadMedia() async {
    setState(() => _loading = true);
    final items = await _service.getAll();
    final bytes = await _service.totalCachedBytes();
    if (!mounted) return;
    setState(() {
      _items = items;
      _cachedBytes = bytes;
      _loading = false;
    });
  }

  List<MediaItem> get _filteredItems {
    final query = _searchController.text.trim().toLowerCase();
    return _items.where((item) {
      if (_selectedType != 'all' &&
          item.mediaType.toLowerCase() != _selectedType) {
        return false;
      }
      if (query.isEmpty) return true;
      return item.title.toLowerCase().contains(query) ||
          (item.topicName ?? '').toLowerCase().contains(query) ||
          (item.providerName ?? '').toLowerCase().contains(query) ||
          (item.promptUsed ?? '').toLowerCase().contains(query) ||
          item.tags.any((t) => t.toLowerCase().contains(query));
    }).toList();
  }

  String _formatMegabytes(int bytes) {
    final mb = bytes / (1024 * 1024);
    return '${mb.toStringAsFixed(2)} MB';
  }

  Future<void> _addManualMedia() async {
    final titleCtrl = TextEditingController();
    final urlCtrl = TextEditingController();
    final topicCtrl = TextEditingController();
    String mediaType = 'image';

    final created = await showDialog<MediaItem>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Cadastrar Mídia na Biblioteca'),
          content: SizedBox(
            width: 440,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: titleCtrl,
                    decoration: const InputDecoration(
                      labelText: 'Título de identificação',
                      hintText: 'Ex.: Slide de Campanha Institucional',
                    ),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    initialValue: mediaType,
                    decoration: const InputDecoration(
                      labelText: 'Tipo de arquivo',
                    ),
                    items: const [
                      DropdownMenuItem(value: 'image', child: Text('Imagem')),
                      DropdownMenuItem(value: 'video', child: Text('Vídeo')),
                      DropdownMenuItem(value: 'audio', child: Text('Áudio / Narração')),
                    ],
                    onChanged: (val) {
                      if (val != null) setDialogState(() => mediaType = val);
                    },
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: urlCtrl,
                    decoration: const InputDecoration(
                      labelText: 'URL na Nuvem ou Data URI',
                      hintText: 'https://...',
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: topicCtrl,
                    decoration: const InputDecoration(
                      labelText: 'Tema associado (opcional)',
                    ),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () {
                if (titleCtrl.text.trim().isEmpty ||
                    urlCtrl.text.trim().isEmpty) {
                  return;
                }
                Navigator.pop(
                  ctx,
                  MediaItem(
                    id: 'media_${DateTime.now().microsecondsSinceEpoch}',
                    title: titleCtrl.text.trim(),
                    mediaType: mediaType,
                    url: urlCtrl.text.trim(),
                    topicName: topicCtrl.text.trim().isEmpty
                        ? null
                        : topicCtrl.text.trim(),
                    providerName: 'Cadastro Manual / Nuvem',
                    cloudSynced: true,
                    cachedLocally: false,
                    createdAt: DateTime.now(),
                  ),
                );
              },
              child: const Text('Salvar na Biblioteca'),
            ),
          ],
        ),
      ),
    );

    titleCtrl.dispose();
    urlCtrl.dispose();
    topicCtrl.dispose();

    if (created != null) {
      await _service.add(created);
      await _loadMedia();
    }
  }

  Future<void> _pruneCache() async {
    final freed = await _service.pruneLocalCache();
    await _loadMedia();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Cache local otimizado: $freed arquivo(s) mantidos apenas na nuvem para economizar espaço no dispositivo.',
        ),
      ),
    );
  }

  void _openPreview(MediaItem item) {
    showDialog<void>(
      context: context,
      builder: (ctx) => Dialog(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 760, maxHeight: 680),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        item.title,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    IconButton(
                      onPressed: () => Navigator.pop(ctx),
                      icon: const Icon(Icons.close),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: item.mediaType == 'image'
                      ? InteractiveViewer(
                          minScale: 0.8,
                          maxScale: 4.0,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: _buildImagePreview(item.url),
                          ),
                        )
                      : Container(
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            color: Theme.of(context)
                                .colorScheme
                                .surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                item.mediaType == 'video'
                                    ? Icons.play_circle_fill
                                    : Icons.audiotrack,
                                size: 64,
                              ),
                              const SizedBox(height: 12),
                              Text(
                                'Arquivo de ${item.mediaType == "video" ? "Vídeo" : "Áudio"}',
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                              const SizedBox(height: 8),
                              SelectableText(
                                item.url,
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
                ),
                const SizedBox(height: 12),
                if (item.promptUsed != null && item.promptUsed!.isNotEmpty)
                  Text(
                    'Prompt utilizado: ${item.promptUsed}',
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 10,
                  alignment: WrapAlignment.end,
                  children: [
                    OutlinedButton.icon(
                      onPressed: () {
                        Clipboard.setData(ClipboardData(text: item.url));
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Endereço copiado para reutilização.'),
                          ),
                        );
                      },
                      icon: const Icon(Icons.copy),
                      label: const Text('Copiar URL'),
                    ),
                    if (widget.selectionMode)
                      FilledButton.icon(
                        onPressed: () {
                          Navigator.pop(ctx);
                          Navigator.pop(context, item.url);
                        },
                        icon: const Icon(Icons.check),
                        label: const Text('Reutilizar este arquivo'),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildImagePreview(String source) {
    if (source.startsWith('data:') && source.contains(',')) {
      try {
        final bytes = base64Decode(source.substring(source.indexOf(',') + 1));
        return Image.memory(bytes, fit: BoxFit.contain);
      } catch (_) {}
    }
    return Image.network(
      source,
      fit: BoxFit.contain,
      errorBuilder: (_, __, ___) => const Center(
        child: Icon(Icons.broken_image_outlined, size: 48),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filteredItems;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Biblioteca de Mídia Centralizada'),
        actions: [
          IconButton(
            tooltip: 'Otimizar cache local',
            onPressed: _pruneCache,
            icon: const Icon(Icons.cleaning_services_outlined),
          ),
          IconButton(
            tooltip: 'Recarregar',
            onPressed: _loadMedia,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addManualMedia,
        icon: const Icon(Icons.add_photo_alternate_outlined),
        label: const Text('Adicionar Mídia'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _searchController,
                        onChanged: (_) => setState(() {}),
                        decoration: const InputDecoration(
                          prefixIcon: Icon(Icons.search),
                          hintText:
                              'Pesquisar por título, tema, provedor ou prompt...',
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Chip(
                      avatar: const Icon(Icons.storage_outlined, size: 16),
                      label: Text(
                        'Cache local: ${_formatMegabytes(_cachedBytes)} / 50 MB',
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      _buildFilterChip('all', 'Todos (${_items.length})'),
                      const SizedBox(width: 8),
                      _buildFilterChip('image', 'Imagens'),
                      const SizedBox(width: 8),
                      _buildFilterChip('video', 'Vídeos'),
                      const SizedBox(width: 8),
                      _buildFilterChip('audio', 'Áudios'),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : filtered.isEmpty
                    ? const Center(
                        child: Padding(
                          padding: EdgeInsets.all(24),
                          child: Text(
                            'Nenhum arquivo de mídia encontrado. As imagens e vídeos gerados aparecerão automaticamente aqui.',
                            textAlign: TextAlign.center,
                          ),
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 90),
                        itemCount: filtered.length,
                        itemBuilder: (context, index) {
                          final item = filtered[index];
                          return Card(
                            child: ListTile(
                              onTap: () => _openPreview(item),
                              leading: CircleAvatar(
                                child: Icon(
                                  item.mediaType == 'video'
                                      ? Icons.videocam_outlined
                                      : item.mediaType == 'audio'
                                          ? Icons.audiotrack_outlined
                                          : Icons.image_outlined,
                                ),
                              ),
                              title: Text(
                                item.title,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              subtitle: Text(
                                '${item.providerName ?? "Nuvem"}'
                                '${item.topicName != null ? " • Tema: ${item.topicName}" : ""}'
                                ' • ${item.cachedLocally ? "Cache Local" : "Nuvem Remota"}',
                              ),
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  if (widget.selectionMode)
                                    FilledButton.tonal(
                                      onPressed: () =>
                                          Navigator.pop(context, item.url),
                                      child: const Text('Usar'),
                                    ),
                                  IconButton(
                                    tooltip: 'Excluir da biblioteca',
                                    onPressed: () async {
                                      await _service.remove(item.id);
                                      await _loadMedia();
                                    },
                                    icon: const Icon(Icons.delete_outline),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip(String value, String label) {
    final selected = _selectedType == value;
    return ChoiceChip(
      selected: selected,
      label: Text(label),
      onSelected: (_) => setState(() => _selectedType = value),
    );
  }
}
