import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/theme_controller.dart';
import '../models/automation_task.dart';
import '../services/api_provider_registry.dart';
import '../services/automation_task_service.dart';
import '../services/media_library_service.dart';
import '../services/post_schedule_service.dart';
import 'api_center_screen.dart';
import 'api_fallback_history_screen.dart';
import 'api_fallback_test_screen.dart';
import 'automation_center_screen.dart';
import 'content_generator_screen.dart';
import 'diagnostic_center_screen.dart';
import 'media_library_screen.dart';
import 'network_catalog_screen.dart';
import 'post_history_screen.dart';
import 'post_schedule_screen.dart';
import 'production_director_screen.dart';
import 'social_networks_screen.dart';
import 'statistics_reports_screen.dart';
import 'topics_screen.dart';
import 'worker_access_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _activeTopicsCount = 0;
  int _activeApisCount = 0;
  int _pendingTasksCount = 0;
  int _scheduledPostsCount = 0;
  int _mediaLibraryCount = 0;
  int _attentionAlertsCount = 0;

  @override
  void initState() {
    super.initState();
    _refreshIndicators();
  }

  Future<void> _refreshIndicators() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final topicsRaw = prefs.getString('content_topics_v2');
      var topicsCount = 0;
      if (topicsRaw != null && topicsRaw.isNotEmpty) {
        final decoded = jsonDecode(topicsRaw);
        if (decoded is List) {
          topicsCount = decoded
              .whereType<Map>()
              .where((t) => t['active'] == true)
              .length;
        }
      }

      final providers = await ApiProviderRegistry().getAll();
      final activeApis =
          providers.where((p) => p.active && p.hasQuotaAvailable).length;
      final failingOrNoQuota = providers
          .where((p) => p.active && (!p.hasQuotaAvailable || p.lastError != null))
          .length;

      final tasks = await AutomationTaskService().getAll();
      final pendingTasks = tasks
          .where((t) =>
              t.status == AutomationTaskStatus.pending ||
              t.status == AutomationTaskStatus.running)
          .length;
      final failedTasks =
          tasks.where((t) => t.status == AutomationTaskStatus.failed).length;

      final posts = await PostScheduleService().getAll();
      final mediaItems = await MediaLibraryService().getAll();

      if (!mounted) return;
      setState(() {
        _activeTopicsCount = topicsCount;
        _activeApisCount = activeApis;
        _pendingTasksCount = pendingTasks;
        _scheduledPostsCount = posts.length;
        _mediaLibraryCount = mediaItems.length;
        _attentionAlertsCount = failingOrNoQuota + failedTasks;
      });
    } catch (_) {
      // Em ambiente de teste sem SharedPreferences inicializado, mantém zeros seguros.
    }
  }

  Future<void> _navigate(BuildContext context, Widget screen) async {
    await Navigator.push<void>(
      context,
      MaterialPageRoute(builder: (_) => screen),
    );
    if (mounted) {
      _refreshIndicators();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final colorScheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Automação de Conteúdo'),
        centerTitle: false,
        actions: [
          IconButton(
            tooltip: 'Central de Diagnóstico',
            onPressed: () =>
                _navigate(context, const DiagnosticCenterScreen()),
            icon: Badge(
              isLabelVisible: _attentionAlertsCount > 0,
              label: Text('$_attentionAlertsCount'),
              child: const Icon(Icons.health_and_safety_outlined),
            ),
          ),
          IconButton(
            tooltip: isDark ? 'Mudar para Tema Claro' : 'Mudar para Tema Escuro',
            onPressed: () => ThemeController.instance.toggleTheme(),
            icon: Icon(
              isDark ? Icons.light_mode_outlined : Icons.dark_mode_outlined,
            ),
          ),
          IconButton(
            tooltip: 'Atualizar indicadores',
            onPressed: _refreshIndicators,
            icon: const Icon(Icons.refresh),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final width = constraints.maxWidth;
            // Otimizado para Galaxy Tab S8 Ultra (telas amplas >= 1000px), tablets (>= 680px) e celulares
            final crossAxisCount = width >= 1150
                ? 3
                : width >= 680
                    ? 2
                    : 1;

            return SingleChildScrollView(
              padding: EdgeInsets.symmetric(
                horizontal: width >= 900 ? 28 : 16,
                vertical: 20,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // CABEÇALHO TECNOLÓGICO PREMIUM
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      gradient: LinearGradient(
                        colors: isDark
                            ? const [Color(0xFF0F2942), Color(0xFF1E1B4B)]
                            : const [Color(0xFF0F766E), Color(0xFF1E3A8A)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.white.withValues(alpha: 0.16),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: const Text(
                                'EDIÇÃO R3 • MULTI-PLATAFORMA & GALAXY TAB S8 ULTRA',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: 0.6,
                                ),
                              ),
                            ),
                            const Spacer(),
                            TextButton.icon(
                              style: TextButton.styleFrom(
                                foregroundColor: Colors.white,
                              ),
                              onPressed: () =>
                                  ThemeController.instance.toggleTheme(),
                              icon: Icon(
                                isDark ? Icons.light_mode : Icons.dark_mode,
                                size: 18,
                              ),
                              label: Text(isDark ? 'Tema Claro' : 'Tema Escuro'),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Text(
                          'Painel principal',
                          style: Theme.of(context)
                              .textTheme
                              .headlineSmall
                              ?.copyWith(
                                fontWeight: FontWeight.w800,
                                color: Colors.white,
                              ),
                        ),
                        const SizedBox(height: 6),
                        const Text(
                          'Centralize temas, textos, imagens, carrosséis de 4 slides, vídeos com áudio, '
                          'Diretor de Produção com IA, verificação semestral e publicação nas redes sociais.',
                          style: TextStyle(
                            color: Color(0xFFE2E8F0),
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 18),
                        Wrap(
                          spacing: 12,
                          runSpacing: 12,
                          children: [
                            _buildKpiBadge(
                              label: 'Temas Ativos',
                              value: '$_activeTopicsCount',
                              icon: Icons.topic_outlined,
                            ),
                            _buildKpiBadge(
                              label: 'APIs c/ Cota',
                              value: '$_activeApisCount',
                              icon: Icons.api_outlined,
                            ),
                            _buildKpiBadge(
                              label: 'Fila Automação',
                              value: '$_pendingTasksCount',
                              icon: Icons.schedule_send_outlined,
                            ),
                            _buildKpiBadge(
                              label: 'Postagens',
                              value: '$_scheduledPostsCount',
                              icon: Icons.calendar_month_outlined,
                            ),
                            _buildKpiBadge(
                              label: 'Mídias Salvas',
                              value: '$_mediaLibraryCount',
                              icon: Icons.perm_media_outlined,
                            ),
                            _buildKpiBadge(
                              label: 'Alertas',
                              value: '$_attentionAlertsCount',
                              icon: Icons.warning_amber_rounded,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 28),
                  _buildSectionTitle(
                    context,
                    'Criação, Produção com IA e Redes Sociais',
                  ),
                  const SizedBox(height: 12),

                  _buildResponsiveGrid(
                    crossAxisCount: crossAxisCount,
                    children: [
                      _buildMenuCard(
                        context: context,
                        title: 'Temas de conteúdo',
                        description:
                            'Cadastre e organize os temas para gerar textos, carrosséis e vídeos.',
                        icon: Icons.topic_outlined,
                        badge: '$_activeTopicsCount ativos',
                        onTap: () => _navigate(context, const TopicsScreen()),
                      ),
                      _buildMenuCard(
                        context: context,
                        title: 'Gerador de Conteúdo',
                        description:
                            'Gere legendas com fontes, carrosséis de 4 slides + anúncios e vídeos assíncronos.',
                        icon: Icons.auto_awesome_outlined,
                        badge: 'IA + Fontes',
                        onTap: () =>
                            _navigate(context, const ContentGeneratorScreen()),
                      ),
                      _buildMenuCard(
                        context: context,
                        title: 'Diretor de Produção com IA',
                        description:
                            'Transforme roteiros em planos divididos em cenas com continuidade visual.',
                        icon: Icons.movie_filter_outlined,
                        badge: 'Cenas & Prompts',
                        onTap: () => _navigate(
                          context,
                          const ProductionDirectorScreen(),
                        ),
                      ),
                      _buildMenuCard(
                        context: context,
                        title: 'Configuração de Postagens',
                        description:
                            'Revise slides, player de vídeo com áudio, evidências e estado Reavaliar mais tarde.',
                        icon: Icons.calendar_month_outlined,
                        badge: 'Carrossel & Vídeo',
                        onTap: () =>
                            _navigate(context, const PostScheduleScreen()),
                      ),
                      _buildMenuCard(
                        context: context,
                        title: 'Histórico de Postagens',
                        description:
                            'Consulte rascunhos, reavaliações de 6 meses e publicações independentes.',
                        icon: Icons.history_outlined,
                        badge: '$_scheduledPostsCount itens',
                        onTap: () =>
                            _navigate(context, const PostHistoryScreen()),
                      ),
                      _buildMenuCard(
                        context: context,
                        title: 'Biblioteca de Mídia',
                        description:
                            'Centralize imagens, vídeos e áudios com busca, filtros, nuvem e cache controlado.',
                        icon: Icons.perm_media_outlined,
                        badge: '$_mediaLibraryCount arquivos',
                        onTap: () =>
                            _navigate(context, const MediaLibraryScreen()),
                      ),
                      _buildMenuCard(
                        context: context,
                        title: 'Redes sociais por tema',
                        description:
                            'Cadastre múltiplas contas (Instagram, Facebook, TikTok) e valide tokens e permissões.',
                        icon: Icons.share_outlined,
                        badge: 'Multi-contas',
                        onTap: () =>
                            _navigate(context, const SocialNetworksScreen()),
                      ),
                      _buildMenuCard(
                        context: context,
                        title: 'Central de Redes',
                        description:
                            'Gerencie o catálogo oficial de redes sociais e requisitos de publicação.',
                        icon: Icons.hub_outlined,
                        onTap: () =>
                            _navigate(context, const NetworkCatalogScreen()),
                      ),
                    ],
                  ),

                  const SizedBox(height: 28),
                  _buildSectionTitle(
                    context,
                    'Central de APIs, Nuvem e Fallback Inteligente',
                  ),
                  const SizedBox(height: 12),

                  _buildResponsiveGrid(
                    crossAxisCount: crossAxisCount,
                    children: [
                      _buildMenuCard(
                        context: context,
                        title: 'Central de APIs',
                        description:
                            'Categorias (Texto, Imagem, Vídeo, Social), URLs, prioridades, cotas gratuitas e testes.',
                        icon: Icons.api_outlined,
                        badge: '$_activeApisCount ativas',
                        onTap: () =>
                            _navigate(context, const ApiCenterScreen()),
                      ),
                      _buildMenuCard(
                        context: context,
                        title: 'Central de Automações',
                        description:
                            'Fila em nuvem, agendamento, deduplicação, retentativas e recuperação de tarefas.',
                        icon: Icons.precision_manufacturing_outlined,
                        badge: '$_pendingTasksCount na fila',
                        onTap: () =>
                            _navigate(context, const AutomationCenterScreen()),
                      ),
                      _buildMenuCard(
                        context: context,
                        title: 'Acesso ao Servidor',
                        description:
                            'Configure o Worker/nuvem para execução independente do tablet ou notebook.',
                        icon: Icons.cloud_outlined,
                        onTap: () =>
                            _navigate(context, const WorkerAccessScreen()),
                      ),
                      _buildMenuCard(
                        context: context,
                        title: 'Teste de alternativas',
                        description:
                            'Simule falhas ou fim de cota e confira o acionamento automático de fallback.',
                        icon: Icons.swap_horiz,
                        onTap: () =>
                            _navigate(context, ApiFallbackTestScreen()),
                      ),
                      _buildMenuCard(
                        context: context,
                        title: 'Histórico de falhas de APIs',
                        description:
                            'Audite todas as trocas automáticas entre provedores principais e secundários.',
                        icon: Icons.history,
                        onTap: () => _navigate(
                          context,
                          const ApiFallbackHistoryScreen(),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 28),
                  _buildSectionTitle(
                    context,
                    'Diagnóstico, Estatísticas e Verificação',
                  ),
                  const SizedBox(height: 12),

                  _buildResponsiveGrid(
                    crossAxisCount: crossAxisCount,
                    children: [
                      _buildMenuCard(
                        context: context,
                        title: 'Central de Diagnóstico',
                        description:
                            'Verifique APIs funcionando, com falha, sem cota, fila pendente, sincronização e contas.',
                        icon: Icons.monitor_heart_outlined,
                        badge: _attentionAlertsCount > 0
                            ? '$_attentionAlertsCount alertas'
                            : 'Tudo OK',
                        onTap: () =>
                            _navigate(context, const DiagnosticCenterScreen()),
                      ),
                      _buildMenuCard(
                        context: context,
                        title: 'Estatísticas e Relatórios',
                        description:
                            'Desempenho por tema, rede social, conta, vídeos e melhores horários (dados reais).',
                        icon: Icons.analytics_outlined,
                        badge: 'Sem dados fictícios',
                        onTap: () =>
                            _navigate(context, const StatisticsReportsScreen()),
                      ),
                    ],
                  ),

                  const SizedBox(height: 24),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(
                            Icons.verified_user_outlined,
                            color: colorScheme.primary,
                          ),
                          const SizedBox(width: 12),
                          const Expanded(
                            child: Text(
                              'Segurança e Transparência Ativas: Credenciais de provedores e de redes sociais são armazenadas separadamente no cofre seguro do dispositivo. Todos os textos incluem aviso obrigatório de IA, o 4º slide dos carrosséis inclui a chamada de engajamento padrão e nenhuma conta social é marcada como conectada sem validação real de token e permissões.',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildKpiBadge({
    required String label,
    required String value,
    required IconData icon,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withValues(alpha: 0.18)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: Colors.white, size: 20),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                ),
              ),
              Text(
                label,
                style: const TextStyle(
                  color: Color(0xFFCBD5E1),
                  fontSize: 11,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildResponsiveGrid({
    required int crossAxisCount,
    required List<Widget> children,
  }) {
    if (crossAxisCount <= 1) {
      return Column(children: children);
    }

    final rows = <Widget>[];
    for (var i = 0; i < children.length; i += crossAxisCount) {
      final slice = children.skip(i).take(crossAxisCount).toList();
      while (slice.length < crossAxisCount) {
        slice.add(const SizedBox.shrink());
      }
      rows.add(
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: slice
                .map(
                  (w) => Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: w,
                    ),
                  ),
                )
                .toList(),
          ),
        ),
      );
    }
    return Column(children: rows);
  }

  Widget _buildSectionTitle(BuildContext context, String title) {
    return Text(
      title,
      style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
          ),
    );
  }

  Widget _buildMenuCard({
    required BuildContext context,
    required String title,
    required String description,
    required IconData icon,
    required VoidCallback onTap,
    String? badge,
  }) {
    final colorScheme = Theme.of(context).colorScheme;
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                radius: 22,
                backgroundColor: colorScheme.primaryContainer,
                foregroundColor: colorScheme.onPrimaryContainer,
                child: Icon(icon),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            title,
                            style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 15,
                            ),
                          ),
                        ),
                        if (badge != null)
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: colorScheme.secondaryContainer,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              badge,
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: colorScheme.onSecondaryContainer,
                              ),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      description,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 6),
              const Icon(Icons.chevron_right),
            ],
          ),
        ),
      ),
    );
  }
}
