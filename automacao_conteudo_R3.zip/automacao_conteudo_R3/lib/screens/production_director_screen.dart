import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/automation_task.dart';
import '../models/production_plan.dart';
import '../services/automation_task_service.dart';
import '../services/production_director_service.dart';

class ProductionDirectorScreen extends StatefulWidget {
  const ProductionDirectorScreen({super.key});

  @override
  State<ProductionDirectorScreen> createState() =>
      _ProductionDirectorScreenState();
}

class _ProductionDirectorScreenState extends State<ProductionDirectorScreen> {
  final ProductionDirectorService _directorService =
      ProductionDirectorService();
  final AutomationTaskService _taskService = AutomationTaskService();

  final TextEditingController _scriptController = TextEditingController();
  final TextEditingController _styleController = TextEditingController(
    text: 'Cinematográfico Tecnológico Premium (Luz suave e alta nitidez)',
  );

  List<Map<String, dynamic>> _topics = [];
  List<ProductionPlan> _savedPlans = [];
  String? _selectedTopicId;
  ProductionPlan? _activePlan;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadInitialData();
  }

  @override
  void dispose() {
    _scriptController.dispose();
    _styleController.dispose();
    super.dispose();
  }

  Future<void> _loadInitialData() async {
    final prefs = await SharedPreferences.getInstance();
    final rawTopics = prefs.getString('content_topics_v2');
    final loadedTopics = <Map<String, dynamic>>[];
    if (rawTopics != null && rawTopics.isNotEmpty) {
      try {
        final decoded = jsonDecode(rawTopics);
        if (decoded is List) {
          for (final item in decoded) {
            if (item is Map && item['active'] == true) {
              loadedTopics.add(Map<String, dynamic>.from(item));
            }
          }
        }
      } catch (_) {}
    }

    final plans = await _directorService.getAll();
    if (!mounted) return;
    setState(() {
      _topics = loadedTopics;
      _selectedTopicId =
          loadedTopics.isNotEmpty ? loadedTopics.first['id']?.toString() : null;
      _savedPlans = plans;
      _activePlan = plans.isNotEmpty ? plans.first : null;
      _loading = false;
    });
  }

  String get _selectedTopicName {
    for (final t in _topics) {
      if (t['id'] == _selectedTopicId) {
        return (t['name'] ?? 'Tema').toString();
      }
    }
    return 'Tema Geral';
  }

  Future<void> _generateProductionPlan() async {
    final plan = _directorService.buildPlanFromTopic(
      topicName: _selectedTopicName,
      topicId: _selectedTopicId,
      scriptOrIdea: _scriptController.text,
      visualStyle: _styleController.text.trim().isEmpty
          ? 'Cinematográfico Moderno'
          : _styleController.text.trim(),
    );
    await _directorService.upsert(plan);
    final plans = await _directorService.getAll();
    if (!mounted) return;
    setState(() {
      _savedPlans = plans;
      _activePlan = plan;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Plano de Produção dividido em 4 cenas com continuidade visual gerado e salvo!',
        ),
      ),
    );
  }

  Future<void> _editScene(ProductionScene scene) async {
    if (_activePlan == null) return;
    final imgCtrl = TextEditingController(text: scene.imagePrompt);
    final vidCtrl = TextEditingController(text: scene.videoPrompt);
    final narCtrl = TextEditingController(text: scene.narrationText);
    final subCtrl = TextEditingController(text: scene.subtitleText);

    final updatedScene = await showDialog<ProductionScene>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Editar ${scene.title}'),
        content: SizedBox(
          width: 520,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: imgCtrl,
                  minLines: 2,
                  maxLines: 4,
                  decoration: const InputDecoration(
                    labelText: 'Prompt específico para Provedor de Imagem',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: vidCtrl,
                  minLines: 2,
                  maxLines: 4,
                  decoration: const InputDecoration(
                    labelText: 'Prompt específico para Provedor de Vídeo',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: narCtrl,
                  minLines: 2,
                  maxLines: 4,
                  decoration: const InputDecoration(
                    labelText: 'Narração / Locução da Cena',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: subCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Legenda sobreposta (Slide / Vídeo)',
                  ),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(
              ctx,
              scene.copyWith(
                imagePrompt: imgCtrl.text.trim(),
                videoPrompt: vidCtrl.text.trim(),
                narrationText: narCtrl.text.trim(),
                subtitleText: subCtrl.text.trim(),
              ),
            ),
            child: const Text('Salvar Cena'),
          ),
        ],
      ),
    );

    imgCtrl.dispose();
    vidCtrl.dispose();
    narCtrl.dispose();
    subCtrl.dispose();

    if (updatedScene != null) {
      final newScenes = _activePlan!.scenes
          .map((s) =>
              s.sceneNumber == updatedScene.sceneNumber ? updatedScene : s)
          .toList();
      final updatedPlan = _activePlan!.copyWith(
        scenes: newScenes,
        updatedAt: DateTime.now(),
      );
      await _directorService.upsert(updatedPlan);
      final plans = await _directorService.getAll();
      if (!mounted) return;
      setState(() {
        _activePlan = updatedPlan;
        _savedPlans = plans;
      });
    }
  }

  Future<void> _sendPlanToAutomationQueue() async {
    final plan = _activePlan;
    if (plan == null) return;
    final now = DateTime.now();

    final compiledPrompt = StringBuffer()
      ..writeln('PUBLICAÇÃO 1:')
      ..writeln('LEGENDA: ${plan.title} — ${plan.baseScript}')
      ..writeln();

    for (final scene in plan.scenes) {
      compiledPrompt.writeln(
        'SLIDE ${scene.sceneNumber}: ${scene.subtitleText} (${scene.narrationText})',
      );
    }

    compiledPrompt.writeln('\nROTEIRO:');
    for (final scene in plan.scenes) {
      compiledPrompt.writeln(
        'Cena ${scene.sceneNumber} (${scene.durationSeconds}s): ${scene.visualDescription} | Narração: ${scene.narrationText}',
      );
    }

    final task = AutomationTask(
      id: 'task_director_${now.microsecondsSinceEpoch}',
      type: AutomationTaskType.contentGeneration,
      priority: 1,
      topicId: plan.topicId,
      payload: {
        'prompt': compiledPrompt.toString(),
        'topicName': plan.topicName,
        'format': 'Publicação completa',
        'quantity': 1,
        'productionPlanId': plan.id,
        'source': 'production_director',
      },
      createdAt: now,
      updatedAt: now,
    );

    await _taskService.add(task);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Plano de Produção enviado para a Fila da Central de Automações!',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Diretor de Produção com IA'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          const Text(
                            'Novo Planejamento Multi-Cenas',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 6),
                          const Text(
                            'Transforme qualquer tema e roteiro em cenas estruturadas com prompts por provedor, narração, legendas e continuidade visual.',
                          ),
                          const SizedBox(height: 16),
                          if (_topics.isNotEmpty)
                            DropdownButtonFormField<String>(
                              initialValue: _selectedTopicId,
                              decoration: const InputDecoration(
                                labelText: 'Tema base',
                              ),
                              items: _topics
                                  .map(
                                    (t) => DropdownMenuItem<String>(
                                      value: t['id']?.toString(),
                                      child: Text((t['name'] ?? '').toString()),
                                    ),
                                  )
                                  .toList(),
                              onChanged: (val) =>
                                  setState(() => _selectedTopicId = val),
                            ),
                          const SizedBox(height: 12),
                          TextField(
                            controller: _styleController,
                            decoration: const InputDecoration(
                              labelText:
                                  'Diretriz de Continuidade Visual entre Cenas',
                            ),
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            controller: _scriptController,
                            minLines: 3,
                            maxLines: 5,
                            decoration: const InputDecoration(
                              labelText: 'Ideia central ou roteiro inicial',
                              hintText:
                                  'Descreva os pontos principais que o Diretor de Produção deve dividir em cenas...',
                            ),
                          ),
                          const SizedBox(height: 16),
                          FilledButton.icon(
                            onPressed: _generateProductionPlan,
                            icon: const Icon(Icons.movie_creation_outlined),
                            label: const Text(
                              'Gerar Plano de Produção em 4 Cenas',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  if (_activePlan != null) ...[
                    const SizedBox(height: 24),
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _activePlan!.title,
                                style: Theme.of(context)
                                    .textTheme
                                    .titleLarge
                                    ?.copyWith(fontWeight: FontWeight.bold),
                              ),
                              Text(
                                'Duração total estimada: ${_activePlan!.totalDurationSeconds}s • ${_activePlan!.scenes.length} cenas sincronizadas',
                              ),
                            ],
                          ),
                        ),
                        FilledButton.tonalIcon(
                          onPressed: _sendPlanToAutomationQueue,
                          icon: const Icon(Icons.send_outlined),
                          label: const Text('Enviar para Fila de Automação'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Row(
                          children: [
                            const Icon(Icons.palette_outlined),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                _activePlan!.visualContinuityGuide,
                                style: const TextStyle(fontSize: 13),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    ..._activePlan!.scenes.map(
                      (scene) => Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  CircleAvatar(
                                    child: Text('${scene.sceneNumber}'),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Text(
                                      scene.title,
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                      ),
                                    ),
                                  ),
                                  Chip(
                                    label: Text('${scene.durationSeconds}s'),
                                  ),
                                  IconButton(
                                    tooltip: 'Editar prompts e narração da cena',
                                    onPressed: () => _editScene(scene),
                                    icon: const Icon(Icons.edit_outlined),
                                  ),
                                ],
                              ),
                              const Divider(),
                              Text(
                                'Prompt de Imagem (${scene.targetImageProvider}):',
                                style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              Text(scene.imagePrompt),
                              const SizedBox(height: 8),
                              Text(
                                'Prompt de Vídeo (${scene.targetVideoProvider}):',
                                style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              Text(scene.videoPrompt),
                              const SizedBox(height: 8),
                              Text(
                                'Narração / Áudio: "${scene.narrationText}"',
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'Legenda da Cena: "${scene.subtitleText}"',
                                style: const TextStyle(
                                  fontStyle: FontStyle.italic,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
    );
  }
}
