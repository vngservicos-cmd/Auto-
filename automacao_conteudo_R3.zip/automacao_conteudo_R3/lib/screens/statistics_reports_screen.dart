import 'package:flutter/material.dart';

import '../services/statistics_service.dart';

class StatisticsReportsScreen extends StatefulWidget {
  const StatisticsReportsScreen({super.key});

  @override
  State<StatisticsReportsScreen> createState() =>
      _StatisticsReportsScreenState();
}

class _StatisticsReportsScreenState extends State<StatisticsReportsScreen> {
  final StatisticsService _service = StatisticsService();
  DashboardAnalyticsBundle? _bundle;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    setState(() => _loading = true);
    final data = await _service.buildAnalytics();
    if (!mounted) return;
    setState(() {
      _bundle = data;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final bundle = _bundle;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Estatísticas e Relatórios'),
        actions: [
          IconButton(
            tooltip: 'Atualizar relatórios',
            onPressed: _loadStats,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: _loading || bundle == null
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          Icon(
                            Icons.verified_outlined,
                            color: Theme.of(context).colorScheme.primary,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              bundle.anyPlatformMetricsProvided
                                  ? 'Exibindo métricas operacionais locais e dados reais fornecidos pelas plataformas conectadas.'
                                  : 'Política de Dados Reais (Seção 13): Nenhuma métrica externa (alcance, impressões ou engajamento) é inventada. Enquanto as plataformas sociais não fornecerem dados via API, são exibidos apenas os contadores reais de produção local.',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Wrap(
                    spacing: 12,
                    runSpacing: 12,
                    children: [
                      _buildStatTile(
                        'Total de Postagens',
                        '${bundle.totalPosts}',
                        Icons.article_outlined,
                      ),
                      _buildStatTile(
                        'Publicadas',
                        '${bundle.publishedCount}',
                        Icons.check_circle_outline,
                      ),
                      _buildStatTile(
                        'Pendentes de Revisão',
                        '${bundle.pendingCount}',
                        Icons.pending_actions_outlined,
                      ),
                      _buildStatTile(
                        'Reavaliar em 6 Meses',
                        '${bundle.reEvaluateCount}',
                        Icons.update_outlined,
                      ),
                      _buildStatTile(
                        'Conteúdos c/ Vídeo',
                        '${bundle.totalVideos}',
                        Icons.videocam_outlined,
                      ),
                    ],
                  ),
                  const SizedBox(height: 28),
                  _buildGroupSection(
                    title: 'Desempenho por Tema',
                    items: bundle.byTopic,
                  ),
                  const SizedBox(height: 24),
                  _buildGroupSection(
                    title: 'Desempenho por Rede Social',
                    items: bundle.byNetwork,
                  ),
                  const SizedBox(height: 24),
                  _buildGroupSection(
                    title: 'Resultados por Conta e Desempenho de Vídeos',
                    items: bundle.byAccount,
                  ),
                  const SizedBox(height: 24),
                  Text(
                    'Melhores Horários Identificados',
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  if (bundle.bestHours.isEmpty)
                    const Card(
                      child: Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'Cadastre ou publique postagens para identificar a distribuição de horários.',
                        ),
                      ),
                    )
                  else
                    ...bundle.bestHours.map(
                      (h) => Card(
                        child: ListTile(
                          leading: const CircleAvatar(
                            child: Icon(Icons.access_time),
                          ),
                          title: Text(
                            'Faixa das ${h.hour.toString().padLeft(2, "0")}:00h',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(
                            h.basedOnPlatformMetrics
                                ? '${h.postsCount} publicação(ões) • Engajamento real fornecido: ${h.totalEngagement}'
                                : '${h.postsCount} publicação(ões) agendada(s)/criada(s) neste horário (aguardando métricas da plataforma)',
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
    );
  }

  Widget _buildStatTile(String label, String value, IconData icon) {
    return SizedBox(
      width: 195,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon),
              const SizedBox(height: 8),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                ),
              ),
              Text(label, style: const TextStyle(fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildGroupSection({
    required String title,
    required List<GroupPerformanceSummary> items,
  }) {
    final maxPosts = items.isEmpty
        ? 1
        : items
            .map((e) => e.totalPosts)
            .reduce((a, b) => a > b ? a : b)
            .clamp(1, 999999);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context)
              .textTheme
              .titleLarge
              ?.copyWith(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        if (items.isEmpty)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text('Nenhum registro cadastrado nesta categoria.'),
            ),
          )
        else
          ...items.map((item) {
            final ratio = item.totalPosts / maxPosts;
            return Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            item.label,
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                            ),
                          ),
                        ),
                        Text(
                          '${item.totalPosts} post(s) • ${item.approvedPosts} aprovado(s) • ${item.videoPostsCount} vídeo(s)',
                          style: const TextStyle(fontSize: 12),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    LinearProgressIndicator(
                      value: ratio,
                      minHeight: 8,
                      borderRadius: BorderRadius.circular(4),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      item.hasPlatformMetrics
                          ? 'Alcance: ${item.totalReach} • Impressões: ${item.totalImpressions} • Engajamento: ${item.totalEngagement} • Views de Vídeo: ${item.totalVideoViews}'
                          : 'Alcance / Impressões / Engajamento: Aguardando dados oficiais da plataforma social.',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
            );
          }),
      ],
    );
  }
}
