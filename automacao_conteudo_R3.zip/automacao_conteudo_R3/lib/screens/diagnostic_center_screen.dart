import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/api_provider.dart';
import '../models/automation_task.dart';
import '../services/api_provider_credentials_storage.dart';
import '../services/api_provider_registry.dart';
import '../services/api_provider_sync_queue.dart';
import '../services/automation_task_service.dart';

class DiagnosticCenterScreen extends StatefulWidget {
  const DiagnosticCenterScreen({super.key});

  @override
  State<DiagnosticCenterScreen> createState() => _DiagnosticCenterScreenState();
}

class _DiagnosticCenterScreenState extends State<DiagnosticCenterScreen> {
  final ApiProviderRegistry _apiRegistry = ApiProviderRegistry();
  final ApiProviderCredentialsStorage _credStorage =
      ApiProviderCredentialsStorage();
  final AutomationTaskService _taskService = AutomationTaskService();
  final ApiProviderSyncQueue _syncQueue = ApiProviderSyncQueue();

  List<ApiProvider> _workingApis = [];
  List<ApiProvider> _failingApis = [];
  List<ApiProvider> _noQuotaProviders = [];
  List<String> _missingCredentialApis = [];
  List<AutomationTask> _pendingTasks = [];
  List<AutomationTask> _failedTasks = [];
  int _pendingSyncItemsCount = 0;
  List<String> _unconfiguredSocialAccounts = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _runDiagnostics();
  }

  Future<void> _runDiagnostics() async {
    setState(() => _loading = true);

    final providers = await _apiRegistry.getAll();
    final working = <ApiProvider>[];
    final failing = <ApiProvider>[];
    final noQuota = <ApiProvider>[];
    final missingCreds = <String>[];

    for (final p in providers) {
      if (!p.active) continue;
      final key = await _credStorage.readCredential(p.id);
      if (key == null || key.trim().isEmpty) {
        missingCreds.add('${p.name} (${p.provider}) — Sem chave cadastrada');
      }
      if (!p.hasQuotaAvailable) {
        noQuota.add(p);
      } else if (p.availabilityStatus == 'error' ||
          (p.lastError != null && p.lastError!.trim().isNotEmpty)) {
        failing.add(p);
      } else {
        working.add(p);
      }
    }

    final tasks = await _taskService.getAll();
    final pending = tasks
        .where((t) =>
            t.status == AutomationTaskStatus.pending ||
            t.status == AutomationTaskStatus.running)
        .toList();
    final failed =
        tasks.where((t) => t.status == AutomationTaskStatus.failed).toList();

    final syncItems = await _syncQueue.getAll();

    final prefs = await SharedPreferences.getInstance();
    final unconfiguredSocial = <String>[];
    for (final key in prefs.getKeys()) {
      if (key.startsWith('social_accounts_topic_id_')) {
        final raw = prefs.getString(key);
        if (raw == null) continue;
        try {
          final decoded = jsonDecode(raw);
          if (decoded is List) {
            for (final acc in decoded) {
              if (acc is Map && acc['active'] == true) {
                final status =
                    (acc['connectionStatus'] ?? 'not_configured').toString();
                if (status != 'verified_connected') {
                  unconfiguredSocial.add(
                    '${acc['platform'] ?? "Rede"}: ${acc['name'] ?? "Conta"} (${acc['topicName'] ?? "Tema"}) — Requer token OAuth / verificação',
                  );
                }
              }
            }
          }
        } catch (_) {}
      }
    }

    if (!mounted) return;
    setState(() {
      _workingApis = working;
      _failingApis = failing;
      _noQuotaProviders = noQuota;
      _missingCredentialApis = missingCreds;
      _pendingTasks = pending;
      _failedTasks = failed;
      _pendingSyncItemsCount = syncItems.length;
      _unconfiguredSocialAccounts = unconfiguredSocial;
      _loading = false;
    });
  }

  Future<void> _recoverInterrupted() async {
    final count = await _taskService.recoverInterruptedTasks();
    await _runDiagnostics();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$count tarefa(s) interrompida(s) recuperada(s).'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Central de Diagnóstico do Sistema'),
        actions: [
          IconButton(
            tooltip: 'Executar varredura completa',
            onPressed: _runDiagnostics,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                _buildDiagnosticCard(
                  title:
                      'APIs Funcionando e Disponíveis (${_workingApis.length})',
                  icon: Icons.check_circle_outline,
                  color: Colors.green,
                  items: _workingApis
                      .map(
                        (p) =>
                            '${p.name} (${p.provider}) • Capacidades: ${p.capabilities.join(", ")} • Prioridade ${p.priority}',
                      )
                      .toList(),
                  emptyText: 'Nenhuma API ativa e operacional no momento.',
                ),
                const SizedBox(height: 12),
                _buildDiagnosticCard(
                  title: 'APIs com Falhas Registradas (${_failingApis.length})',
                  icon: Icons.error_outline,
                  color: Colors.redAccent,
                  items: _failingApis
                      .map(
                        (p) =>
                            '${p.name} (${p.provider}): ${p.lastError ?? "Erro na última chamada"}',
                      )
                      .toList(),
                  emptyText: 'Nenhuma falha ativa nas APIs cadastradas.',
                ),
                const SizedBox(height: 12),
                _buildDiagnosticCard(
                  title:
                      'Provedores Sem Cota ou Teste Expirado (${_noQuotaProviders.length})',
                  icon: Icons.hourglass_empty,
                  color: Colors.orange,
                  items: _noQuotaProviders
                      .map(
                        (p) =>
                            '${p.name} (${p.provider}) • Usado hoje: ${p.usedQuotaToday}/${p.dailyQuotaLimit ?? "limite atingido"}',
                      )
                      .toList(),
                  emptyText:
                      'Todos os provedores ativos possuem cota disponível.',
                ),
                const SizedBox(height: 12),
                _buildDiagnosticCard(
                  title:
                      'Tarefas Pendentes (${_pendingTasks.length}) e Com Erro (${_failedTasks.length})',
                  icon: Icons.playlist_play_outlined,
                  color: Colors.blueAccent,
                  items: [
                    ..._pendingTasks.map(
                      (t) =>
                          '[${t.status.name.toUpperCase()}] Tarefa ${t.id} (${t.type.name})',
                    ),
                    ..._failedTasks.map(
                      (t) =>
                          '[FALHA - Tentativa ${t.attemptCount}/${t.maxAttempts}] ${t.id}: ${t.lastError ?? ""}',
                    ),
                  ],
                  emptyText: 'Nenhuma tarefa pendente ou travada na fila.',
                  trailingAction: TextButton.icon(
                    onPressed: _recoverInterrupted,
                    icon: const Icon(Icons.restore),
                    label: const Text('Recuperar interrompidas'),
                  ),
                ),
                const SizedBox(height: 12),
                _buildDiagnosticCard(
                  title:
                      'Sincronização com a Nuvem ($_pendingSyncItemsCount operação(ões) na fila)',
                  icon: Icons.cloud_sync_outlined,
                  color:
                      _pendingSyncItemsCount > 0 ? Colors.amber : Colors.teal,
                  items: _pendingSyncItemsCount > 0
                      ? [
                          'Há $_pendingSyncItemsCount alteração(ões) locais aguardando sincronização com o Worker/Nuvem.'
                        ]
                      : [],
                  emptyText: 'Sincronização local/nuvem em dia (0 pendências).',
                ),
                const SizedBox(height: 12),
                _buildDiagnosticCard(
                  title:
                      'Integrações que Precisam de Configuração (${_missingCredentialApis.length + _unconfiguredSocialAccounts.length})',
                  icon: Icons.build_circle_outlined,
                  color: Colors.purpleAccent,
                  items: [
                    ..._missingCredentialApis,
                    ..._unconfiguredSocialAccounts,
                  ],
                  emptyText:
                      'Todas as integrações e contas sociais ativas possuem credenciais configuradas.',
                ),
              ],
            ),
    );
  }

  Widget _buildDiagnosticCard({
    required String title,
    required IconData icon,
    required Color color,
    required List<String> items,
    required String emptyText,
    Widget? trailingAction,
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: color),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
                if (trailingAction != null) trailingAction,
              ],
            ),
            const Divider(),
            if (items.isEmpty)
              Text(
                emptyText,
                style: Theme.of(context).textTheme.bodySmall,
              )
            else
              ...items.map(
                (line) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('• '),
                      Expanded(child: Text(line)),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
