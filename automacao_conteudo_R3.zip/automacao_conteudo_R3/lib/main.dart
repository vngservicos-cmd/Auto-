import 'package:flutter/material.dart';

import 'core/theme_controller.dart';
import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await ThemeController.instance.loadSavedTheme();
  runApp(const AutomacaoConteudoApp());
}

class AutomacaoConteudoApp extends StatelessWidget {
  const AutomacaoConteudoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: ThemeController.instance,
      builder: (context, themeMode, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Automação de Conteúdo',
          theme: ThemeController.buildLightTheme(),
          darkTheme: ThemeController.buildDarkTheme(),
          themeMode: themeMode,
          home: const HomeScreen(),
        );
      },
    );
  }
}
