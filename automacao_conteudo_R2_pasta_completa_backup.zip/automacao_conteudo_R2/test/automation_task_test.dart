import 'package:flutter_test/flutter_test.dart';
import 'package:automacao_conteudo/models/automation_task.dart';

void main() {
  group('AutomationTask', () {
    test('serializa e recupera metadados de geração', () {
      final createdAt = DateTime.utc(2026, 11, 1, 12);
      final task = AutomationTask(
        id: 'task_test_1',
        type: AutomationTaskType.contentGeneration,
        topicId: 'topic_test',
        payload: {
          'format': 'Legenda',
          'quantity': 2,
          'period': 'Dia',
          'repetition': 'Continuamente',
          'prompt': 'Crie duas legendas.',
        },
        createdAt: createdAt,
        updatedAt: createdAt,
      );

      final restored = AutomationTask.fromJson(task.toJson());

      expect(restored.id, task.id);
      expect(restored.payload['quantity'], 2);
      expect(restored.payload['period'], 'Dia');
      expect(restored.payload['repetition'], 'Continuamente');
      expect(restored.status, AutomationTaskStatus.pending);
    });
  });
}
