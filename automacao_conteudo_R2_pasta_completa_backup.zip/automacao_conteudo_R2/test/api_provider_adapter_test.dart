import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:automacao_conteudo/services/api_provider_adapter.dart';

void main() {
  group('OpenAiCompatibleTextAdapter', () {
    test('envia modelo, endpoint configurado e extrai texto', () async {
      var calledUri = '';
      var calledModel = '';
      final client = MockClient((request) async {
        calledUri = request.url.toString();
        final body = jsonDecode(request.body) as Map<String, dynamic>;
        calledModel = body['model'] as String;
        return http.Response(
          jsonEncode({
            'choices': [
              {'message': {'content': 'Texto gerado no teste'}}
            ],
          }),
          200,
        );
      });
      final adapter = OpenAiCompatibleTextAdapter(client: client);
      final text = await adapter.generateContent(
        apiKey: 'test-key',
        modelId: 'modelo-teste',
        prompt: 'Gere uma frase.',
        endpointUrl: 'https://api.example.test/v1/chat/completions',
      );
      expect(text, 'Texto gerado no teste');
      expect(calledUri, 'https://api.example.test/v1/chat/completions');
      expect(calledModel, 'modelo-teste');
      adapter.dispose();
    });

    test('retorna erro HTTP detalhado para chave ou limite inválido', () async {
      final client = MockClient((_) async => http.Response(
            jsonEncode({'error': {'message': 'invalid api key'}}),
            401,
          ));
      final adapter = OpenAiCompatibleTextAdapter(client: client);
      await expectLater(
        adapter.generateContent(
          apiKey: 'bad-key',
          modelId: 'modelo-teste',
          prompt: 'Teste',
        ),
        throwsA(isA<ApiProviderException>().having(
          (error) => error.message,
          'message',
          contains('invalid api key'),
        )),
      );
      adapter.dispose();
    });
  });
}
