import 'package:flutter_test/flutter_test.dart';
import 'package:automacao_conteudo/models/post_schedule.dart';

void main() {
  group('PostSchedule — materiais gerados', () {
    test('preserva URLs das imagens e do vídeo ao serializar', () {
      final now = DateTime.utc(2026, 11, 1);
      final schedule = PostSchedule(
        id: 'media_test_1',
        network: 'Instagram',
        content: 'Conteúdo de teste',
        caption: 'Legenda de teste',
        contentFormat: 'Publicação completa',
        carouselSlides: const ['1', '2', '3', '4'],
        carouselImageUrls: const [
          'https://cdn.example.test/1.png',
          'https://cdn.example.test/2.png',
          'https://cdn.example.test/3.png',
          'https://cdn.example.test/4.png',
        ],
        videoUrl: 'https://cdn.example.test/video.mp4',
        videoApiAccountId: 'video-account-1',
        videoApiProvider: 'Google Gemini',
        videoScript: 'Roteiro',
        scheduledAt: null,
        automatic: false,
        status: 'Pendente de aprovação',
        createdAt: now,
      );

      final restored = PostSchedule.fromJson(schedule.toJson());
      expect(restored.carouselImageUrls, hasLength(4));
      expect(restored.carouselImageUrls.first,
          'https://cdn.example.test/1.png');
      expect(restored.videoUrl, 'https://cdn.example.test/video.mp4');
      expect(restored.videoApiAccountId, 'video-account-1');
      expect(restored.videoApiProvider, 'Google Gemini');
    });

    test('mantém compatibilidade com registros antigos sem mídia', () {
      final restored = PostSchedule.fromJson({
        'id': 'legacy',
        'network': 'Instagram',
        'content': 'Texto antigo',
        'scheduledAt': null,
        'automatic': false,
        'status': 'Rascunho',
        'createdAt': DateTime.utc(2026, 1, 1).toIso8601String(),
      });
      expect(restored.carouselImageUrls, isEmpty);
      expect(restored.videoUrl, isNull);
    });
  });
}
