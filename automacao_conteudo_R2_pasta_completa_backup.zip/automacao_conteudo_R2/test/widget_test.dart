import 'package:flutter_test/flutter_test.dart';
import 'package:automacao_conteudo/main.dart';

void main() {
  testWidgets('apresenta o painel principal do aplicativo',
      (WidgetTester tester) async {
    await tester.pumpWidget(const AutomacaoConteudoApp());

    expect(find.text('Automação de Conteúdo'), findsOneWidget);
    expect(find.text('Painel principal'), findsOneWidget);
    expect(find.text('Gerador de Conteúdo'), findsOneWidget);
  });
}
