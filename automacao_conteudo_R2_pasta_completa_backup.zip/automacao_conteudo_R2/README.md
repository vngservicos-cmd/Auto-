# Automação de Conteúdo

Aplicativo Flutter para geração e preparação de publicações com IA.

## Preparação

```powershell
flutter pub get
flutter analyze
flutter test
flutter run -d chrome
```

Para executar no tablet Android, conecte o dispositivo e use `flutter devices` seguido de `flutter run -d <ID>`.

A Central de APIs separa contas por capacidade. Credenciais ficam no armazenamento seguro do dispositivo. Informe a URL completa no campo Endpoint da API quando o fornecedor exigir endpoint personalizado.

A versão atual inclui geração de texto Gemini/OpenAI-compatible, geração de imagens por Gemini/OpenAI Images, geração de vídeo REST com retorno direto ou polling comum, prévias de mídia e bloqueio de aprovação quando faltam arquivos. Consulte `DOCUMENTACAO/` para contratos suportados, limitações e roteiro de testes.

**Estado:** pacote de projeto preparado para testes de integração; ainda não homologado em Flutter/Android e não contém publicação social homologada.
