
enum AutomationTaskType {
  contentGeneration,
  review,
  synchronization,
  publication,
  metricsCollection,
}

enum AutomationTaskStatus {
  pending,
  running,
  completed,
  failed,
  cancelled,
}

enum AutomationTaskExecutionStatus {
  running,
  completed,
  failed,
}

/// Representa uma execução individual de uma tarefa.
class AutomationTaskExecution {
  final int attemptNumber;
  final DateTime startedAt;
  final DateTime? completedAt;
  final AutomationTaskExecutionStatus status;
  final String? providerName;
  final String? error;

  const AutomationTaskExecution({
    required this.attemptNumber,
    required this.startedAt,
    this.completedAt,
    required this.status,
    this.providerName,
    this.error,
  });

  Map<String, dynamic> toJson() {
    return {
      'attemptNumber': attemptNumber,
      'startedAt': startedAt.toIso8601String(),
      'completedAt': completedAt?.toIso8601String(),
      'status': status.name,
      'providerName': providerName,
      'error': error,
    };
  }

  factory AutomationTaskExecution.fromJson(
    Map<String, dynamic> json,
  ) {
    DateTime parseRequiredDate(dynamic value) {
      final parsed = DateTime.tryParse(value?.toString() ?? '');

      if (parsed == null) {
        throw const FormatException(
          'Data inválida no histórico de execução.',
        );
      }

      return parsed;
    }

    DateTime? parseOptionalDate(dynamic value) {
      if (value == null || value.toString().isEmpty) {
        return null;
      }

      final parsed = DateTime.tryParse(value.toString());

      if (parsed == null) {
        throw const FormatException(
          'Data de conclusão inválida no histórico.',
        );
      }

      return parsed;
    }

    final statusValue = json['status']?.toString();

    final executionStatus = AutomationTaskExecutionStatus.values
        .where((item) => item.name == statusValue)
        .firstOrNull;

    if (executionStatus == null) {
      throw const FormatException(
        'Situação inválida no histórico de execução.',
      );
    }

    final execution = AutomationTaskExecution(
      attemptNumber: json['attemptNumber'] is num
          ? (json['attemptNumber'] as num).toInt()
          : 0,
      startedAt: parseRequiredDate(json['startedAt']),
      completedAt: parseOptionalDate(json['completedAt']),
      status: executionStatus,
      providerName: json['providerName']?.toString(),
      error: json['error']?.toString(),
    );

    if (execution.attemptNumber < 0) {
      throw const FormatException(
        'Número de tentativa inválido no histórico.',
      );
    }

    return execution;
  }
}

class AutomationTask {
  static const Object _notProvided = Object();

  final String id;
  final AutomationTaskType type;
  final AutomationTaskStatus status;
  final int priority;

  final String? topicId;
  final String? accountId;
  final String? publicationId;
  final String? campaignId;

  final Map<String, dynamic> payload;

  final int attemptCount;
  final int maxAttempts;

  final DateTime createdAt;
  final DateTime updatedAt;
  final DateTime? scheduledAt;
  final DateTime? startedAt;
  final DateTime? completedAt;
  final DateTime? nextAttemptAt;

  final String? lastError;

  // Histórico das execuções individuais da tarefa.
  final List<AutomationTaskExecution> executionHistory;

  const AutomationTask({
    required this.id,
    required this.type,
    this.status = AutomationTaskStatus.pending,
    this.priority = 0,
    this.topicId,
    this.accountId,
    this.publicationId,
    this.campaignId,
    this.payload = const {},
    this.attemptCount = 0,
    this.maxAttempts = 3,
    required this.createdAt,
    required this.updatedAt,
    this.scheduledAt,
    this.startedAt,
    this.completedAt,
    this.nextAttemptAt,
    this.lastError,
    this.executionHistory = const [],
  });

  bool get canRetry =>
      status == AutomationTaskStatus.failed &&
      attemptCount < maxAttempts;

  bool get isPending => status == AutomationTaskStatus.pending;

  bool get isRunning => status == AutomationTaskStatus.running;

  bool get isCompleted => status == AutomationTaskStatus.completed;

  bool get isTerminal =>
      status == AutomationTaskStatus.completed ||
      status == AutomationTaskStatus.cancelled;

  bool get isReady {
    if (status != AutomationTaskStatus.pending && !canRetry) {
      return false;
    }

    final now = DateTime.now();

    if (scheduledAt != null && scheduledAt!.isAfter(now)) {
      return false;
    }

    if (nextAttemptAt != null && nextAttemptAt!.isAfter(now)) {
      return false;
    }

    return true;
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'type': type.name,
      'status': status.name,
      'priority': priority,
      'topicId': topicId,
      'accountId': accountId,
      'publicationId': publicationId,
      'campaignId': campaignId,
      'payload': payload,
      'attemptCount': attemptCount,
      'maxAttempts': maxAttempts,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
      'scheduledAt': scheduledAt?.toIso8601String(),
      'startedAt': startedAt?.toIso8601String(),
      'completedAt': completedAt?.toIso8601String(),
      'nextAttemptAt': nextAttemptAt?.toIso8601String(),
      'lastError': lastError,
      'executionHistory': executionHistory
          .map((execution) => execution.toJson())
          .toList(),
    };
  }

  factory AutomationTask.fromJson(Map<String, dynamic> json) {
    DateTime parseRequiredDate(dynamic value, String field) {
      final parsed = DateTime.tryParse(value?.toString() ?? '');

      if (parsed == null) {
        throw FormatException(
          'Data obrigatória inválida na tarefa: $field.',
        );
      }

      return parsed;
    }

    DateTime? parseOptionalDate(dynamic value) {
      if (value == null || value.toString().isEmpty) {
        return null;
      }

      return DateTime.tryParse(value.toString());
    }

    T parseEnum<T extends Enum>(
      List<T> values,
      dynamic value,
      String field,
    ) {
      for (final item in values) {
        if (item.name == value?.toString()) {
          return item;
        }
      }

      throw FormatException(
        'Valor inválido para o campo $field.',
      );
    }

    final rawPayload = json['payload'];
    final payload = rawPayload is Map
        ? Map<String, dynamic>.from(rawPayload)
        : <String, dynamic>{};

    final rawHistory = json['executionHistory'];
    final executionHistory = <AutomationTaskExecution>[];

    // Compatibilidade com tarefas antigas que não possuem histórico.
    if (rawHistory != null) {
      if (rawHistory is! List) {
        throw const FormatException(
          'O histórico de execução possui formato inválido.',
        );
      }

      for (final item in rawHistory) {
        if (item is! Map) {
          throw const FormatException(
            'Foi encontrado um registro inválido no histórico.',
          );
        }

        executionHistory.add(
          AutomationTaskExecution.fromJson(
            Map<String, dynamic>.from(item),
          ),
        );
      }
    }

    final task = AutomationTask(
      id: json['id']?.toString() ?? '',
      type: parseEnum(
        AutomationTaskType.values,
        json['type'],
        'type',
      ),
      status: parseEnum(
        AutomationTaskStatus.values,
        json['status'] ?? 'pending',
        'status',
      ),
      priority: json['priority'] is num
          ? (json['priority'] as num).toInt()
          : 0,
      topicId: json['topicId']?.toString(),
      accountId: json['accountId']?.toString(),
      publicationId: json['publicationId']?.toString(),
      campaignId: json['campaignId']?.toString(),
      payload: payload,
      attemptCount: json['attemptCount'] is num
          ? (json['attemptCount'] as num).toInt()
          : 0,
      maxAttempts: json['maxAttempts'] is num
          ? (json['maxAttempts'] as num).toInt()
          : 3,
      createdAt: parseRequiredDate(
        json['createdAt'],
        'createdAt',
      ),
      updatedAt: parseRequiredDate(
        json['updatedAt'],
        'updatedAt',
      ),
      scheduledAt: parseOptionalDate(json['scheduledAt']),
      startedAt: parseOptionalDate(json['startedAt']),
      completedAt: parseOptionalDate(json['completedAt']),
      nextAttemptAt: parseOptionalDate(json['nextAttemptAt']),
      lastError: json['lastError']?.toString(),
      executionHistory: executionHistory,
    );

    task.validate();
    return task;
  }

  void validate() {
    if (id.trim().isEmpty) {
      throw const FormatException(
        'A tarefa precisa ter um identificador permanente.',
      );
    }

    if (attemptCount < 0 || maxAttempts < 1) {
      throw const FormatException(
        'Os limites de tentativas da tarefa são inválidos.',
      );
    }

    if (attemptCount > maxAttempts) {
      throw const FormatException(
        'A tarefa ultrapassou o limite de tentativas.',
      );
    }

    for (final execution in executionHistory) {
      if (execution.attemptNumber < 0) {
        throw const FormatException(
          'O histórico contém um número de tentativa inválido.',
        );
      }
    }
  }

  AutomationTask copyWith({
    AutomationTaskType? type,
    AutomationTaskStatus? status,
    int? priority,
    Object? topicId = _notProvided,
    Object? accountId = _notProvided,
    Object? publicationId = _notProvided,
    Object? campaignId = _notProvided,
    Map<String, dynamic>? payload,
    int? attemptCount,
    int? maxAttempts,
    DateTime? createdAt,
    DateTime? updatedAt,
    Object? scheduledAt = _notProvided,
    Object? startedAt = _notProvided,
    Object? completedAt = _notProvided,
    Object? nextAttemptAt = _notProvided,
    Object? lastError = _notProvided,
    List<AutomationTaskExecution>? executionHistory,
  }) {
    return AutomationTask(
      id: id,
      type: type ?? this.type,
      status: status ?? this.status,
      priority: priority ?? this.priority,
      topicId: identical(topicId, _notProvided)
          ? this.topicId
          : topicId as String?,
      accountId: identical(accountId, _notProvided)
          ? this.accountId
          : accountId as String?,
      publicationId: identical(publicationId, _notProvided)
          ? this.publicationId
          : publicationId as String?,
      campaignId: identical(campaignId, _notProvided)
          ? this.campaignId
          : campaignId as String?,
      payload: payload ?? this.payload,
      attemptCount: attemptCount ?? this.attemptCount,
      maxAttempts: maxAttempts ?? this.maxAttempts,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
      scheduledAt: identical(scheduledAt, _notProvided)
          ? this.scheduledAt
          : scheduledAt as DateTime?,
      startedAt: identical(startedAt, _notProvided)
          ? this.startedAt
          : startedAt as DateTime?,
      completedAt: identical(completedAt, _notProvided)
          ? this.completedAt
          : completedAt as DateTime?,
      nextAttemptAt: identical(nextAttemptAt, _notProvided)
          ? this.nextAttemptAt
          : nextAttemptAt as DateTime?,
      lastError: identical(lastError, _notProvided)
          ? this.lastError
          : lastError as String?,
      executionHistory:
          executionHistory ?? this.executionHistory,
    );
  }
}

