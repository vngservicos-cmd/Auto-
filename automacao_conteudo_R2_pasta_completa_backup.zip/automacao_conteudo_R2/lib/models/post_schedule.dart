
class PostSchedule {
  final String id;

  final String network;
  final String content;

  // Conteúdo e origem
  final String caption;
  final String contentFormat;
  final String? topicId;
  final String? topicName;

  // Vínculos permanentes
  final String? accountId;
  final String? campaignId;
  final String? publicationGroupId;

  // Identificação externa da publicação
  final String? externalPostId;
  final DateTime? publishedAt;

  // Materiais complementares
  final List<String> carouselSlides;
  final List<String> carouselImageUrls;
  final String? videoUrl;
  final String? videoApiAccountId;
  final String? videoApiProvider;
  final String? videoScript;
  final String? videoPrompt;

  // Agendamento
  final DateTime? scheduledAt;
  final String scheduleStatus;

  // Aprovação: independente do agendamento
  final String approvalStatus;

  // Compatibilidade com versões anteriores
  final bool automatic;
  final String status;

  // Controle de tentativas e falhas
  final DateTime? lastAttemptAt;
  final int attemptCount;
  final String? lastError;

  // Controle e histórico
  final DateTime createdAt;
  final DateTime? updatedAt;
  final int version;

  const PostSchedule({
    required this.id,
    required this.network,
    required this.content,
    required this.scheduledAt,
    required this.automatic,
    required this.status,
    required this.createdAt,
    String? caption,
    this.contentFormat = 'Legenda para rede social',
    this.topicId,
    this.topicName,
    this.accountId,
    this.campaignId,
    this.publicationGroupId,
    this.externalPostId,
    this.publishedAt,
    this.carouselSlides = const [],
    this.carouselImageUrls = const [],
    this.videoUrl,
    this.videoApiAccountId,
    this.videoApiProvider,
    this.videoScript,
    this.videoPrompt,
    String? scheduleStatus,
    this.approvalStatus = 'Pendente',
    this.lastAttemptAt,
    this.attemptCount = 0,
    this.lastError,
    this.updatedAt,
    this.version = 1,
  })  : caption = caption ?? content,
        scheduleStatus = scheduleStatus ??
            (scheduledAt == null ? 'Não agendado' : 'Agendado');

  static const Object _notProvided = Object();

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'network': network,
      'content': content,
      'caption': caption,
      'contentFormat': contentFormat,
      'topicId': topicId,
      'topicName': topicName,

      // Novos vínculos
      'accountId': accountId,
      'campaignId': campaignId,
      'publicationGroupId': publicationGroupId,

      // Identificação externa
      'externalPostId': externalPostId,
      'publishedAt': publishedAt?.toIso8601String(),

      'carouselSlides': carouselSlides,
      'carouselImageUrls': carouselImageUrls,
      'videoUrl': videoUrl,
      'videoApiAccountId': videoApiAccountId,
      'videoApiProvider': videoApiProvider,
      'videoScript': videoScript,
      'videoPrompt': videoPrompt,
      'scheduledAt': scheduledAt?.toIso8601String(),
      'scheduleStatus': scheduleStatus,
      'approvalStatus': approvalStatus,
      'automatic': automatic,
      'status': status,

      // Tentativas e falhas
      'lastAttemptAt': lastAttemptAt?.toIso8601String(),
      'attemptCount': attemptCount,
      'lastError': lastError,

      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt?.toIso8601String(),
      'version': version,
    };
  }

  factory PostSchedule.fromJson(Map<String, dynamic> json) {
    DateTime? parseDate(dynamic value) {
      if (value == null || value.toString().isEmpty) {
        return null;
      }

      return DateTime.tryParse(value.toString());
    }

    final content = json['content']?.toString() ?? '';
    final scheduledAt = parseDate(json['scheduledAt']);

    final rawSlides = json['carouselSlides'];
    final rawImages = json['carouselImageUrls'];

    final slides = rawSlides is List
        ? rawSlides.map((item) => item.toString()).toList()
        : <String>[];
    final images = rawImages is List
        ? rawImages.map((item) => item.toString()).toList()
        : <String>[];

    return PostSchedule(
      id: json['id']?.toString() ?? '',
      network: json['network']?.toString() ?? '',
      content: content,
      caption: json['caption']?.toString() ?? content,
      contentFormat: json['contentFormat']?.toString() ??
          'Legenda para rede social',
      topicId: json['topicId']?.toString(),
      topicName: json['topicName']?.toString(),

      // Novos vínculos: ausentes em registros antigos
      accountId: json['accountId']?.toString(),
      campaignId: json['campaignId']?.toString(),
      publicationGroupId: json['publicationGroupId']?.toString(),

      // Identificação externa
      externalPostId: json['externalPostId']?.toString(),
      publishedAt: parseDate(json['publishedAt']),

      carouselSlides: slides,
      carouselImageUrls: images,
      videoUrl: json['videoUrl']?.toString(),
      videoApiAccountId: json['videoApiAccountId']?.toString(),
      videoApiProvider: json['videoApiProvider']?.toString(),
      videoScript: json['videoScript']?.toString(),
      videoPrompt: json['videoPrompt']?.toString(),
      scheduledAt: scheduledAt,
      scheduleStatus: json['scheduleStatus']?.toString() ??
          (scheduledAt == null ? 'Não agendado' : 'Agendado'),
      approvalStatus:
          json['approvalStatus']?.toString() ?? 'Pendente',
      automatic: json['automatic'] == true,
      status: json['status']?.toString() ?? 'Rascunho',

      // Tentativas e falhas
      lastAttemptAt: parseDate(json['lastAttemptAt']),
      attemptCount: json['attemptCount'] is num
          ? (json['attemptCount'] as num).toInt()
          : 0,
      lastError: json['lastError']?.toString(),

      createdAt: parseDate(json['createdAt']) ?? DateTime.now(),
      updatedAt: parseDate(json['updatedAt']),
      version: json['version'] is num
          ? (json['version'] as num).toInt()
          : 1,
    );
  }

  PostSchedule copyWith({
    String? network,
    String? content,
    String? caption,
    String? contentFormat,
    Object? topicId = _notProvided,
    Object? topicName = _notProvided,
    Object? accountId = _notProvided,
    Object? campaignId = _notProvided,
    Object? publicationGroupId = _notProvided,
    Object? externalPostId = _notProvided,
    Object? publishedAt = _notProvided,
    List<String>? carouselSlides,
    List<String>? carouselImageUrls,
    Object? videoUrl = _notProvided,
    Object? videoApiAccountId = _notProvided,
    Object? videoApiProvider = _notProvided,
    Object? videoScript = _notProvided,
    Object? videoPrompt = _notProvided,
    Object? scheduledAt = _notProvided,
    String? scheduleStatus,
    String? approvalStatus,
    bool? automatic,
    String? status,
    Object? lastAttemptAt = _notProvided,
    int? attemptCount,
    Object? lastError = _notProvided,
    DateTime? updatedAt,
    int? version,
  }) {
    final newScheduledAt = identical(scheduledAt, _notProvided)
        ? this.scheduledAt
        : scheduledAt as DateTime?;

    return PostSchedule(
      id: id,
      network: network ?? this.network,
      content: content ?? this.content,
      caption: caption ?? this.caption,
      contentFormat: contentFormat ?? this.contentFormat,

      topicId: identical(topicId, _notProvided)
          ? this.topicId
          : topicId as String?,
      topicName: identical(topicName, _notProvided)
          ? this.topicName
          : topicName as String?,

      accountId: identical(accountId, _notProvided)
          ? this.accountId
          : accountId as String?,
      campaignId: identical(campaignId, _notProvided)
          ? this.campaignId
          : campaignId as String?,
      publicationGroupId:
          identical(publicationGroupId, _notProvided)
              ? this.publicationGroupId
              : publicationGroupId as String?,

      externalPostId: identical(externalPostId, _notProvided)
          ? this.externalPostId
          : externalPostId as String?,
      publishedAt: identical(publishedAt, _notProvided)
          ? this.publishedAt
          : publishedAt as DateTime?,

      carouselSlides: carouselSlides ?? this.carouselSlides,
      carouselImageUrls: carouselImageUrls ?? this.carouselImageUrls,
      videoUrl: identical(videoUrl, _notProvided) ? this.videoUrl : videoUrl as String?,
      videoApiAccountId: identical(videoApiAccountId, _notProvided) ? this.videoApiAccountId : videoApiAccountId as String?,
      videoApiProvider: identical(videoApiProvider, _notProvided) ? this.videoApiProvider : videoApiProvider as String?,
      videoScript: identical(videoScript, _notProvided)
          ? this.videoScript
          : videoScript as String?,
      videoPrompt: identical(videoPrompt, _notProvided)
          ? this.videoPrompt
          : videoPrompt as String?,

      scheduledAt: newScheduledAt,
      scheduleStatus: scheduleStatus ??
          (identical(scheduledAt, _notProvided)
              ? this.scheduleStatus
              : newScheduledAt == null
                  ? 'Não agendado'
                  : 'Agendado'),

      approvalStatus: approvalStatus ?? this.approvalStatus,
      automatic: automatic ?? this.automatic,
      status: status ?? this.status,

      lastAttemptAt: identical(lastAttemptAt, _notProvided)
          ? this.lastAttemptAt
          : lastAttemptAt as DateTime?,
      attemptCount: attemptCount ?? this.attemptCount,
      lastError: identical(lastError, _notProvided)
          ? this.lastError
          : lastError as String?,

      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
      version: version ?? this.version + 1,
    );
  }
}
