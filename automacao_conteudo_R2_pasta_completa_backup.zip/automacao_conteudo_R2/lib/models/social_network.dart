
class SocialNetwork {
  final String id;
  final String name;
  final String? iconName;
  final String? websiteUrl;
  final bool active;
  final String connectorType;
  final Map<String, dynamic> configuration;

  const SocialNetwork({
    required this.id,
    required this.name,
    this.iconName,
    this.websiteUrl,
    this.active = true,
    this.connectorType = 'manual',
    this.configuration = const {},
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'iconName': iconName,
      'websiteUrl': websiteUrl,
      'active': active,
      'connectorType': connectorType,
      'configuration': configuration,
    };
  }

  factory SocialNetwork.fromJson(Map<String, dynamic> json) {
    return SocialNetwork(
      id: json['id'] as String? ?? '',
      name: json['name'] as String? ?? '',
      iconName: json['iconName'] as String?,
      websiteUrl: json['websiteUrl'] as String?,
      active: json['active'] as bool? ?? true,
      connectorType: json['connectorType'] as String? ?? 'manual',
      configuration: json['configuration'] is Map
          ? Map<String, dynamic>.from(
              json['configuration'] as Map,
            )
          : const {},
    );
  }

  SocialNetwork copyWith({
    String? name,
    String? iconName,
    String? websiteUrl,
    bool? active,
    String? connectorType,
    Map<String, dynamic>? configuration,
  }) {
    return SocialNetwork(
      id: id,
      name: name ?? this.name,
      iconName: iconName ?? this.iconName,
      websiteUrl: websiteUrl ?? this.websiteUrl,
      active: active ?? this.active,
      connectorType: connectorType ?? this.connectorType,
      configuration: configuration ?? this.configuration,
    );
  }
}
