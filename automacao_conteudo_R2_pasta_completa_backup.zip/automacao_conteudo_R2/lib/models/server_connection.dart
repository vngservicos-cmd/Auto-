
class ServerConnection {
  const ServerConnection({
    required this.id,
    required this.name,
    required this.baseUrl,
    required this.serverType,
    required this.active,
    required this.createdAt,
    required this.updatedAt,
  });

  final String id;
  final String name;
  final String baseUrl;
  final String serverType;
  final bool active;
  final DateTime createdAt;
  final DateTime updatedAt;

  ServerConnection copyWith({
    String? name,
    String? baseUrl,
    String? serverType,
    bool? active,
    DateTime? updatedAt,
  }) {
    return ServerConnection(
      id: id,
      name: name ?? this.name,
      baseUrl: baseUrl ?? this.baseUrl,
      serverType: serverType ?? this.serverType,
      active: active ?? this.active,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'baseUrl': baseUrl,
      'serverType': serverType,
      'active': active,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory ServerConnection.fromJson(Map<String, dynamic> json) {
    return ServerConnection(
      id: json['id'] as String,
      name: json['name'] as String,
      baseUrl: json['baseUrl'] as String,
      serverType: json['serverType'] as String? ?? 'custom',
      active: json['active'] as bool? ?? true,
      createdAt: DateTime.parse(json['createdAt'] as String),
      updatedAt: DateTime.parse(json['updatedAt'] as String),
    );
  }
}
