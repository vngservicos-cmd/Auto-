
class ApiFallbackEvent {
  final String id;
  final String failedProviderName;
  final String failedProviderId;
  final String capability;
  final String? alternativeProviderName;
  final String? alternativeProviderId;
  final String action;
  final String message;
  final bool? alternativeWasFree;
  final DateTime occurredAt;

  const ApiFallbackEvent({
    required this.id,
    required this.failedProviderName,
    required this.failedProviderId,
    required this.capability,
    this.alternativeProviderName,
    this.alternativeProviderId,
    required this.action,
    required this.message,
    this.alternativeWasFree,
    required this.occurredAt,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'failedProviderName': failedProviderName,
      'failedProviderId': failedProviderId,
      'capability': capability,
      'alternativeProviderName': alternativeProviderName,
      'alternativeProviderId': alternativeProviderId,
      'action': action,
      'message': message,
      'alternativeWasFree': alternativeWasFree,
      'occurredAt': occurredAt.toIso8601String(),
    };
  }

  factory ApiFallbackEvent.fromJson(
    Map<String, dynamic> json,
  ) {
    return ApiFallbackEvent(
      id: json['id'] as String? ?? '',
      failedProviderName:
          json['failedProviderName'] as String? ?? 'Desconhecida',
      failedProviderId:
          json['failedProviderId'] as String? ?? '',
      capability: json['capability'] as String? ?? 'text',
      alternativeProviderName:
          json['alternativeProviderName'] as String?,
      alternativeProviderId:
          json['alternativeProviderId'] as String?,
      action: json['action'] as String? ?? 'unknown',
      message: json['message'] as String? ?? '',
      alternativeWasFree:
          json['alternativeWasFree'] as bool?,
      occurredAt: DateTime.tryParse(
            json['occurredAt'] as String? ?? '',
          ) ??
          DateTime.now(),
    );
  }
}
