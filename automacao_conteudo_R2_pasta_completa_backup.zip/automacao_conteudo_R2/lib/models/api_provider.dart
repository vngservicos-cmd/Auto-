
class ApiProvider {
  final String id;
  final String name;
  final String provider;
  final String capability;
  final String connectionType;
  final String? modelId;

  final bool active;
  final bool isFree;
  final bool hasFreeTrial;

  final int priority;
  final int? trialDays;
  final DateTime? trialEndsAt;
  final DateTime? quotaRenewsAt;

  final String? websiteUrl;
  final String? notes;

  final DateTime createdAt;

  ApiProvider({
    required this.id,
    required this.name,
    required this.provider,
    required this.capability,
    this.connectionType = 'manual',
    this.modelId,
    this.active = true,
    this.isFree = true,
    this.hasFreeTrial = false,
    this.priority = 1,
    this.trialDays,
    this.trialEndsAt,
    this.quotaRenewsAt,
    this.websiteUrl,
    this.notes,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.fromMillisecondsSinceEpoch(0);

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'provider': provider,
      'capability': capability,
      'connectionType': connectionType,
      'modelId': modelId,
      'active': active,
      'isFree': isFree,
      'hasFreeTrial': hasFreeTrial,
      'priority': priority,
      'trialDays': trialDays,
      'trialEndsAt': trialEndsAt?.toIso8601String(),
      'quotaRenewsAt': quotaRenewsAt?.toIso8601String(),
      'websiteUrl': websiteUrl,
      'notes': notes,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory ApiProvider.fromJson(Map<String, dynamic> json) {
    return ApiProvider(
      id: json['id'] as String? ?? '',
      name: json['name'] as String? ?? '',
      provider: json['provider'] as String? ?? '',
      capability: json['capability'] as String? ?? 'text',
      connectionType: json['connectionType'] as String? ?? 'manual',
      modelId: json['modelId'] as String?,
      active: json['active'] as bool? ?? true,
      isFree: json['isFree'] as bool? ?? true,
      hasFreeTrial: json['hasFreeTrial'] as bool? ?? false,
      priority: json['priority'] as int? ?? 1,
      trialDays: json['trialDays'] as int?,
      trialEndsAt: _parseDate(json['trialEndsAt']),
      quotaRenewsAt: _parseDate(json['quotaRenewsAt']),
      websiteUrl: json['websiteUrl'] as String?,
      notes: json['notes'] as String?,
      createdAt: _parseDate(json['createdAt']) ??
          DateTime.fromMillisecondsSinceEpoch(0),
    );
  }

  static DateTime? _parseDate(dynamic value) {
    if (value is! String || value.isEmpty) {
      return null;
    }
    return DateTime.tryParse(value);
  }

  ApiProvider copyWith({
    String? name,
    String? provider,
    String? capability,
    String? connectionType,
    String? modelId,
    bool? active,
    bool? isFree,
    bool? hasFreeTrial,
    int? priority,
    int? trialDays,
    DateTime? trialEndsAt,
    DateTime? quotaRenewsAt,
    String? websiteUrl,
    String? notes,
  }) {
    return ApiProvider(
      id: id,
      name: name ?? this.name,
      provider: provider ?? this.provider,
      capability: capability ?? this.capability,
      connectionType: connectionType ?? this.connectionType,
      modelId: modelId ?? this.modelId,
      active: active ?? this.active,
      isFree: isFree ?? this.isFree,
      hasFreeTrial: hasFreeTrial ?? this.hasFreeTrial,
      priority: priority ?? this.priority,
      trialDays: trialDays ?? this.trialDays,
      trialEndsAt: trialEndsAt ?? this.trialEndsAt,
      quotaRenewsAt: quotaRenewsAt ?? this.quotaRenewsAt,
      websiteUrl: websiteUrl ?? this.websiteUrl,
      notes: notes ?? this.notes,
      createdAt: createdAt,
    );
  }
}
