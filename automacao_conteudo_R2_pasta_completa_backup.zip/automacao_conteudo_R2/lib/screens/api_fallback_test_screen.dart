
import 'package:flutter/material.dart';

import '../models/api_provider.dart';
import '../models/api_fallback_event.dart';
import '../services/api_fallback_service.dart';
import '../services/api_fallback_history_service.dart';

class ApiFallbackTestScreen extends StatefulWidget {
  const ApiFallbackTestScreen({super.key});

  @override
  State<ApiFallbackTestScreen> createState() =>
      _ApiFallbackTestScreenState();
}

class _ApiFallbackTestScreenState
    extends State<ApiFallbackTestScreen> {
  final ApiFallbackService _fallbackService =
      ApiFallbackService();

  final ApiFallbackHistoryService _historyService =
      ApiFallbackHistoryService();

  bool _processing = false;

  String _message = 'Nenhuma simulação realizada ainda.';

  Future<void> _simulateFailure() async {
    if (_processing) return;

    setState(() {
      _processing = true;
      _message = 'Executando simulação...';
    });

    try {
      final failedProvider = ApiProvider(
        id: 'api_teste_falhou',
        name: 'API de teste',
        provider: 'Teste',
        capability: 'text',
        active: false,
        isFree: true,
        priority: 1,
      );

      final providers = <ApiProvider>[
        failedProvider,
        ApiProvider(
          id: 'alternativa_gratuita',
          name: 'Alternativa gratuita',
          provider: 'Teste',
          capability: 'text',
          active: true,
          isFree: true,
          priority: 2,
        ),
        ApiProvider(
          id: 'alternativa_paga',
          name: 'Alternativa paga',
          provider: 'Teste',
          capability: 'text',
          active: true,
          isFree: false,
          priority: 1,
        ),
      ];

      final result = _fallbackService.chooseAlternative(
        providers: providers,
        failedProvider: failedProvider,
      );

      final alternative = result.provider;
      final occurredAt = DateTime.now();

      final event = ApiFallbackEvent(
        id: occurredAt.microsecondsSinceEpoch.toString(),
        failedProviderName: failedProvider.name,
        failedProviderId: failedProvider.id,
        capability: failedProvider.capability,
        alternativeProviderName: alternative?.name,
        alternativeProviderId: alternative?.id,
        action: result.action.name,
        message: result.message,
        alternativeWasFree: alternative?.isFree,
        occurredAt: occurredAt,
      );

      await _historyService.add(event);

      if (!mounted) return;

      setState(() {
        _message = [
          result.message,
          if (alternative != null)
            'Alternativa selecionada: ${alternative.name}.',
          'Ação: ${result.action.name}.',
          'Nenhuma chamada real foi executada.',
          'Resultado registrado no histórico.',
        ].join('\n\n');
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _message =
            'A simulação não pôde ser concluída. '
            'Verifique o serviço de alternativas e o histórico.';
      });
    } finally {
      if (mounted) {
        setState(() {
          _processing = false;
        });
      }
    }
  }

  Future<void> _showHistoryCount() async {
    try {
      final events = await _historyService.getAll();

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Registros no histórico: ${events.length}',
          ),
        ),
      );
    } catch (_) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Não foi possível consultar o histórico.',
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Teste de alternativas'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Icon(
            Icons.swap_horiz,
            size: 64,
          ),
          const SizedBox(height: 16),
          Text(
            'Simulação de falhas de APIs',
            style: Theme.of(context).textTheme.headlineSmall,
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 12),
          const Text(
            'Esta tela testa a seleção de alternativas usando '
            'provedores fictícios. Nenhuma chamada real é feita.',
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: SelectableText(_message),
            ),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _processing ? null : _simulateFailure,
            icon: _processing
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                    ),
                  )
                : const Icon(Icons.play_arrow),
            label: Text(
              _processing ? 'Executando...' : 'Simular falha',
            ),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: _processing ? null : _showHistoryCount,
            icon: const Icon(Icons.history),
            label: const Text('Consultar histórico'),
          ),
        ],
      ),
    );
  }
}
