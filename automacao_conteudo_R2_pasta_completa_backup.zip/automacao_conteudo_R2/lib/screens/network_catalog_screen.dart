
import 'package:flutter/material.dart';

import '../models/social_network.dart';
import '../services/social_network_registry.dart';

class NetworkCatalogScreen extends StatefulWidget {
  const NetworkCatalogScreen({super.key});

  @override
  State<NetworkCatalogScreen> createState() =>
      _NetworkCatalogScreenState();
}

class _NetworkCatalogScreenState extends State<NetworkCatalogScreen> {
  final SocialNetworkRegistry _registry = SocialNetworkRegistry();

  List<SocialNetwork> _networks = [];
  bool _loading = true;
  bool _loadError = false;

  @override
  void initState() {
    super.initState();
    _loadNetworks();
  }

  Future<void> _loadNetworks() async {
    if (mounted) {
      setState(() {
        _loading = true;
        _loadError = false;
      });
    }

    try {
      final networks = await _registry.getAll();

      if (!mounted) return;

      setState(() {
        _networks = networks;
        _loading = false;
        _loadError = false;
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _loading = false;
        _loadError = true;
      });
    }
  }

  void _showMessage(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _addNetwork() async {
    final result = await showDialog<SocialNetwork>(
      context: context,
      builder: (_) => const _AddNetworkDialog(),
    );

    if (result == null || !mounted) return;

    try {
      await _registry.add(result);
      await _loadNetworks();

      if (!mounted) return;

      if (_loadError) {
        _showMessage(
          'Rede cadastrada, mas não foi possível atualizar a lista.',
        );
      } else {
        _showMessage('${result.name} foi cadastrada.');
      }
    } on ArgumentError catch (error) {
      _showMessage(error.message.toString());
    } catch (_) {
      _showMessage('Não foi possível salvar a rede.');
    }
  }

  Future<void> _toggleNetwork(SocialNetwork network) async {
    try {
      await _registry.update(
        network.copyWith(active: !network.active),
      );

      await _loadNetworks();

      if (_loadError) {
        _showMessage(
          'Rede atualizada, mas não foi possível atualizar a lista.',
        );
      }
    } catch (_) {
      _showMessage('Não foi possível atualizar a rede.');
    }
  }

  Future<void> _removeNetwork(SocialNetwork network) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Remover rede?'),
        content: Text(
          'Deseja remover "${network.name}" do catálogo? '
          'Isso não apaga contas já cadastradas nos temas.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Remover'),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;

    try {
      await _registry.remove(network.id);
      await _loadNetworks();

      if (_loadError) {
        _showMessage(
          'Rede removida, mas não foi possível atualizar a lista.',
        );
      } else {
        _showMessage('${network.name} foi removida do catálogo.');
      }
    } catch (_) {
      _showMessage('Não foi possível remover a rede.');
    }
  }

  Widget _buildEmptyState() {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.hub_outlined, size: 52),
            SizedBox(height: 12),
            Text(
              'Nenhuma rede adicional cadastrada',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Adicione redes que você deseja organizar '
              'no catálogo.',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.error_outline,
              size: 48,
            ),
            const SizedBox(height: 12),
            const Text(
              'Não foi possível carregar o catálogo de redes.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: _loadNetworks,
              icon: const Icon(Icons.refresh),
              label: const Text('Tentar novamente'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNetworkCard(SocialNetwork network) {
    final isManual = network.connectorType == 'manual';

    return Card(
      child: ListTile(
        leading: Icon(
          isManual
              ? Icons.link_outlined
              : Icons.check_circle_outline,
          size: 30,
        ),
        title: Text(network.name),
        subtitle: Text(
          '${network.active ? 'Ativa' : 'Inativa'}'
          ' • ${isManual ? 'Cadastro manual' : 'Conector configurado'}'
          '${network.websiteUrl == null ? '' : '\n${network.websiteUrl}'}',
        ),
        isThreeLine: network.websiteUrl != null,
        trailing: PopupMenuButton<String>(
          onSelected: (value) {
            if (value == 'toggle') {
              _toggleNetwork(network);
            } else if (value == 'delete') {
              _removeNetwork(network);
            }
          },
          itemBuilder: (context) => [
            PopupMenuItem(
              value: 'toggle',
              child: Text(
                network.active ? 'Desativar' : 'Ativar',
              ),
            ),
            const PopupMenuItem(
              value: 'delete',
              child: Text('Remover do catálogo'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Central de Redes'),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _loading ? null : _addNetwork,
        icon: const Icon(Icons.add),
        label: const Text('Adicionar nova rede'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _loadError
              ? _buildErrorState()
              : _networks.isEmpty
                  ? _buildEmptyState()
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(
                        16,
                        16,
                        16,
                        96,
                      ),
                      itemCount: _networks.length,
                      itemBuilder: (context, index) {
                        return _buildNetworkCard(_networks[index]);
                      },
                    ),
    );
  }
}

class _AddNetworkDialog extends StatefulWidget {
  const _AddNetworkDialog();

  @override
  State<_AddNetworkDialog> createState() =>
      _AddNetworkDialogState();
}

class _AddNetworkDialogState extends State<_AddNetworkDialog> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _websiteController = TextEditingController();

  bool _saving = false;

  @override
  void dispose() {
    _nameController.dispose();
    _websiteController.dispose();
    super.dispose();
  }

  String _makeId(String name) {
    final normalized = name
        .toLowerCase()
        .trim()
        .replaceAll(RegExp(r'[^a-z0-9]+'), '-')
        .replaceAll(RegExp(r'^-+|-+$'), '');

    final timestamp = DateTime.now().microsecondsSinceEpoch;

    return normalized.isEmpty
        ? 'rede-$timestamp'
        : '$normalized-$timestamp';
  }

  String? _validateWebsite(String? value) {
    final website = value?.trim() ?? '';

    if (website.isEmpty) return null;

    final uri = Uri.tryParse(website);

    if (uri == null ||
        !uri.hasAuthority ||
        (uri.scheme != 'http' && uri.scheme != 'https') ||
        uri.host.isEmpty) {
      return 'Informe um endereço válido começando com http:// ou https://.';
    }

    return null;
  }

  void _save() {
    if (_saving || !_formKey.currentState!.validate()) return;

    setState(() {
      _saving = true;
    });

    final name = _nameController.text.trim();
    final website = _websiteController.text.trim();

    Navigator.of(context).pop(
      SocialNetwork(
        id: _makeId(name),
        name: name,
        websiteUrl: website.isEmpty ? null : website,
        connectorType: 'manual',
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Adicionar nova rede'),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: _nameController,
                enabled: !_saving,
                decoration: const InputDecoration(
                  labelText: 'Nome da rede',
                  hintText: 'Ex.: NewRede',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Informe o nome da rede.';
                  }

                  return null;
                },
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _websiteController,
                enabled: !_saving,
                keyboardType: TextInputType.url,
                decoration: const InputDecoration(
                  labelText: 'Site (opcional)',
                  hintText: 'https://exemplo.com',
                  border: OutlineInputBorder(),
                ),
                validator: _validateWebsite,
              ),
              const SizedBox(height: 12),
              const Text(
                'A rede será cadastrada em modo manual. '
                'A publicação automática exige um conector compatível.',
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: _saving
              ? null
              : () => Navigator.of(context).pop(),
          child: const Text('Cancelar'),
        ),
        FilledButton(
          onPressed: _saving ? null : _save,
          child: Text(_saving ? 'Salvando...' : 'Salvar'),
        ),
      ],
    );
  }
}
