
import 'package:flutter/material.dart';

import '../models/api_provider.dart';
import '../services/api_provider_registry.dart';

class ApiCenterScreen extends StatefulWidget {
  const ApiCenterScreen({super.key});

  @override
  State<ApiCenterScreen> createState() => _ApiCenterScreenState();
}

class _ApiCenterScreenState extends State<ApiCenterScreen> {
  final ApiProviderRegistry _registry = ApiProviderRegistry();

  List<ApiProvider> _providers = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadProviders();
  }

  Future<void> _loadProviders() async {
    final providers = await _registry.getAll();

    if (!mounted) return;

    setState(() {
      _providers = providers;
      _loading = false;
    });
  }

  Future<void> _openForm([ApiProvider? existing]) async {
    final result = await showDialog<ApiProvider>(
      context: context,
      builder: (_) => _ApiProviderDialog(existing: existing),
    );

    if (result == null) return;

    final success = existing == null
        ? await _registry.add(result)
        : await _registry.update(result);

    if (!mounted) return;

    if (success) {
      await _loadProviders();
      _showMessage(
        existing == null
            ? 'API cadastrada com sucesso.'
            : 'API atualizada com sucesso.',
      );
    } else {
      _showMessage(
        'Não foi possível salvar. Verifique o cadastro.',
      );
    }
  }

  Future<void> _toggleActive(ApiProvider provider) async {
    final updated = provider.copyWith(active: !provider.active);
    final success = await _registry.update(updated);

    if (!mounted) return;

    if (success) {
      await _loadProviders();
      _showMessage(
        updated.active ? 'API ativada.' : 'API desativada.',
      );
    }
  }

  Future<void> _deleteProvider(ApiProvider provider) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Excluir API?'),
        content: Text(
          'Deseja excluir "${provider.name}" do cadastro? '
          'Essa ação não pode ser desfeita.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    final success = await _registry.remove(provider.id);

    if (!mounted) return;

    if (success) {
      await _loadProviders();
      _showMessage('API excluída do cadastro.');
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  IconData _iconFor(String capability) {
    switch (capability) {
      case 'image':
        return Icons.image_outlined;
      case 'video':
        return Icons.video_library_outlined;
      case 'audio':
        return Icons.graphic_eq;
      default:
        return Icons.text_fields;
    }
  }

  String _capabilityName(String capability) {
    switch (capability) {
      case 'image':
        return 'Imagem';
      case 'video':
        return 'Vídeo';
      case 'audio':
        return 'Áudio';
      default:
        return 'Texto';
    }
  }

  String _formatDate(DateTime date) {
    final day = date.day.toString().padLeft(2, '0');
    final month = date.month.toString().padLeft(2, '0');
    return '$day/$month/${date.year}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Central de APIs'),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openForm(),
        icon: const Icon(Icons.add),
        label: const Text('Adicionar API'),
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : _providers.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.api, size: 64),
                        const SizedBox(height: 16),
                        Text(
                          'Nenhuma API cadastrada',
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'Cadastre serviços de texto, imagem, vídeo '
                          'ou áudio para organizar suas opções.',
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 16),
                        FilledButton.icon(
                          onPressed: () => _openForm(),
                          icon: const Icon(Icons.add),
                          label: const Text(
                            'Cadastrar primeira API',
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(
                    12,
                    12,
                    12,
                    90,
                  ),
                  itemCount: _providers.length,
                  itemBuilder: (context, index) {
                    final provider = _providers[index];

                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: ListTile(
                        leading: CircleAvatar(
                          child: Icon(
                            _iconFor(provider.capability),
                          ),
                        ),
                        title: Text(provider.name),
                        subtitle: Padding(
                          padding: const EdgeInsets.only(top: 6),
                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment.start,
                            children: [
                              Text(provider.provider),
                              const SizedBox(height: 4),
                              Text(
                                '${_capabilityName(provider.capability)}'
                                ' • ${provider.isFree ? "Gratuita" : "Paga"}'
                                '${provider.hasFreeTrial ? " • Teste grátis" : ""}',
                              ),
                              Text(
                                'Prioridade: ${provider.priority}'
                                ' • ${provider.active ? "Ativa" : "Desativada"}',
                              ),
                              if (provider.trialEndsAt != null)
                                Text(
                                  'Fim do teste: '
                                  '${_formatDate(provider.trialEndsAt!)}',
                                ),
                              if (provider.websiteUrl != null)
                                Text(
                                  provider.websiteUrl!,
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodySmall,
                                ),
                              if (provider.notes != null)
                                Text(
                                  provider.notes!,
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodySmall,
                                ),
                            ],
                          ),
                        ),
                        trailing: PopupMenuButton<String>(
                          tooltip: 'Opções da API',
                          onSelected: (value) {
                            switch (value) {
                              case 'toggle':
                                _toggleActive(provider);
                                break;
                              case 'edit':
                                _openForm(provider);
                                break;
                              case 'delete':
                                _deleteProvider(provider);
                                break;
                            }
                          },
                          itemBuilder: (_) => [
                            PopupMenuItem(
                              value: 'toggle',
                              child: Text(
                                provider.active
                                    ? 'Desativar'
                                    : 'Ativar',
                              ),
                            ),
                            const PopupMenuItem(
                              value: 'edit',
                              child: Text('Editar'),
                            ),
                            const PopupMenuItem(
                              value: 'delete',
                              child: Text('Excluir'),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}

class _ApiProviderDialog extends StatefulWidget {
  final ApiProvider? existing;

  const _ApiProviderDialog({
    this.existing,
  });

  @override
  State<_ApiProviderDialog> createState() =>
      _ApiProviderDialogState();
}

class _ApiProviderDialogState extends State<_ApiProviderDialog> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController _nameController;
  late final TextEditingController _providerController;
  late final TextEditingController _websiteController;
  late final TextEditingController _notesController;

  late String _capability;
  late bool _isFree;
  late bool _hasFreeTrial;
  late bool _active;
  late int _priority;
  late DateTime? _trialEndsAt;

  @override
  void initState() {
    super.initState();

    final existing = widget.existing;

    _nameController = TextEditingController(
      text: existing?.name ?? '',
    );
    _providerController = TextEditingController(
      text: existing?.provider ?? '',
    );
    _websiteController = TextEditingController(
      text: existing?.websiteUrl ?? '',
    );
    _notesController = TextEditingController(
      text: existing?.notes ?? '',
    );

    _capability = existing?.capability ?? 'text';
    _isFree = existing?.isFree ?? true;
    _hasFreeTrial = existing?.hasFreeTrial ?? false;
    _active = existing?.active ?? true;
    _priority = existing?.priority ?? 1;
    _trialEndsAt = existing?.trialEndsAt;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _providerController.dispose();
    _websiteController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _chooseTrialDate() async {
    final now = DateTime.now();

    final selected = await showDatePicker(
      context: context,
      initialDate:
          _trialEndsAt ?? now.add(const Duration(days: 30)),
      firstDate: DateTime(now.year - 1),
      lastDate: DateTime(now.year + 10),
    );

    if (selected != null && mounted) {
      setState(() {
        _trialEndsAt = selected;
      });
    }
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;

    final existing = widget.existing;

    final provider = ApiProvider(
      id: existing?.id ??
          'api_${DateTime.now().microsecondsSinceEpoch}',
      name: _nameController.text.trim(),
      provider: _providerController.text.trim(),
      capability: _capability,
      connectionType: existing?.connectionType ?? 'manual',
      active: _active,
      isFree: _isFree,
      hasFreeTrial: _hasFreeTrial,
      priority: _priority,
      trialEndsAt: _hasFreeTrial ? _trialEndsAt : null,
      trialDays: existing?.trialDays,
      quotaRenewsAt: existing?.quotaRenewsAt,
      websiteUrl: _websiteController.text.trim().isEmpty
          ? null
          : _websiteController.text.trim(),
      notes: _notesController.text.trim().isEmpty
          ? null
          : _notesController.text.trim(),
      createdAt: existing?.createdAt ?? DateTime.now(),
    );

    Navigator.pop(context, provider);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(
        widget.existing == null
            ? 'Adicionar API'
            : 'Editar API',
      ),
      content: SizedBox(
        width: 440,
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Nome da API ou serviço',
                    hintText: 'Ex.: Serviço de geração de texto',
                  ),
                  validator: (value) =>
                      value == null || value.trim().isEmpty
                          ? 'Informe o nome do serviço.'
                          : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _providerController,
                  decoration: const InputDecoration(
                    labelText: 'Empresa ou fornecedor',
                  ),
                  validator: (value) =>
                      value == null || value.trim().isEmpty
                          ? 'Informe o fornecedor.'
                          : null,
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  initialValue: _capability,
                  decoration: const InputDecoration(
                    labelText: 'Tipo de serviço',
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: 'text',
                      child: Text('Geração de texto'),
                    ),
                    DropdownMenuItem(
                      value: 'image',
                      child: Text('Geração de imagens'),
                    ),
                    DropdownMenuItem(
                      value: 'video',
                      child: Text('Geração de vídeos'),
                    ),
                    DropdownMenuItem(
                      value: 'audio',
                      child: Text('Áudio e voz'),
                    ),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _capability = value;
                      });
                    }
                  },
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<int>(
                  initialValue: _priority,
                  decoration: const InputDecoration(
                    labelText: 'Prioridade de uso',
                  ),
                  items: List.generate(
                    10,
                    (index) => DropdownMenuItem(
                      value: index + 1,
                      child: Text('Prioridade ${index + 1}'),
                    ),
                  ),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _priority = value;
                      });
                    }
                  },
                ),
                const SizedBox(height: 8),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Serviço gratuito'),
                  value: _isFree,
                  onChanged: (value) {
                    setState(() {
                      _isFree = value;
                    });
                  },
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Possui teste grátis por prazo'),
                  value: _hasFreeTrial,
                  onChanged: (value) {
                    setState(() {
                      _hasFreeTrial = value;
                      if (!value) {
                        _trialEndsAt = null;
                      }
                    });
                  },
                ),
                if (_hasFreeTrial)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Data de fim do teste'),
                    subtitle: Text(
                      _trialEndsAt == null
                          ? 'Data não informada'
                          : '${_trialEndsAt!.day.toString().padLeft(2, '0')}/'
                            '${_trialEndsAt!.month.toString().padLeft(2, '0')}/'
                            '${_trialEndsAt!.year}',
                    ),
                    trailing: const Icon(Icons.calendar_month),
                    onTap: _chooseTrialDate,
                  ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('API ativa'),
                  value: _active,
                  onChanged: (value) {
                    setState(() {
                      _active = value;
                    });
                  },
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _websiteController,
                  decoration: const InputDecoration(
                    labelText: 'Site oficial (opcional)',
                  ),
                  keyboardType: TextInputType.url,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _notesController,
                  decoration: const InputDecoration(
                    labelText: 'Observações (opcional)',
                  ),
                  maxLines: 2,
                ),
              ],
            ),
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancelar'),
        ),
        FilledButton(
          onPressed: _save,
          child: const Text('Salvar'),
        ),
      ],
    );
  }
}
