import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../services/api_access_token_storage.dart';
import '../services/server_connection_storage.dart';

import 'package:automacao_conteudo/models/server_connection.dart';

class WorkerAccessScreen extends StatefulWidget {
  const WorkerAccessScreen({super.key});

  @override
  State<WorkerAccessScreen> createState() => _WorkerAccessScreenState();
}

class _WorkerAccessScreenState extends State<WorkerAccessScreen> {
  final ServerConnectionStorage _storage = ServerConnectionStorage();
  final ApiAccessTokenStorage _legacyStorage = ApiAccessTokenStorage();

  List<ServerConnection> _servers = [];
  String? _activeServerId;

  bool _loading = true;
  bool _working = false;

  final Map<String, String> _testMessages = {};
  final Map<String, bool> _testResults = {};
  final Set<String> _testingServers = {};

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    try {
      await _migrateLegacyCloudflare();
      await _loadServers();
    } catch (error) {
      if (!mounted) return;
      setState(() => _loading = false);
      _showMessage('Não foi possível carregar os servidores: $error');
    }
  }

  Future<void> _migrateLegacyCloudflare() async {
    final servers = await _storage.getAll();

    if (servers.isNotEmpty) return;

    final legacyToken = await _legacyStorage.readToken();

    if (legacyToken == null || legacyToken.trim().isEmpty) return;

    final now = DateTime.now();

    final server = ServerConnection(
      id: 'cloudflare_worker_default',
      name: 'Cloudflare Worker',
      baseUrl:
          'https://automacao-conteudo-backend.vngservicos.workers.dev',
      serverType: 'cloudflare',
      active: true,
      createdAt: now,
      updatedAt: now,
    );

    await _storage.add(server, legacyToken);
  }

  Future<void> _loadServers() async {
    final servers = await _storage.getAll();
    final activeServer = await _storage.getActive();

    if (!mounted) return;

    setState(() {
      _servers = servers;
      _activeServerId = activeServer?.id;
      _loading = false;
    });
  }

  Future<void> _addServer() async {
    final data = await _showServerDialog();

    if (data == null) return;

    final now = DateTime.now();
    final id = 'server_${now.microsecondsSinceEpoch}';

    final server = ServerConnection(
      id: id,
      name: data['name'] as String,
      baseUrl: data['baseUrl'] as String,
      serverType: data['serverType'] as String,
      active: true,
      createdAt: now,
      updatedAt: now,
    );

    try {
      setState(() => _working = true);

      await _storage.add(server, data['token'] as String);
      await _loadServers();

      if (!mounted) return;
      setState(() => _working = false);

      _showMessage('Servidor cadastrado com sucesso.');
    } catch (error) {
      if (!mounted) return;
      setState(() => _working = false);
      _showMessage('Não foi possível cadastrar o servidor: $error');
    }
  }

  Future<void> _editServer(ServerConnection server) async {
    final data = await _showServerDialog(server: server);

    if (data == null) return;

    try {
      setState(() => _working = true);

      final updated = server.copyWith(
        name: data['name'] as String,
        baseUrl: data['baseUrl'] as String,
        serverType: data['serverType'] as String,
        updatedAt: DateTime.now(),
      );

      await _storage.update(updated);

      final token = (data['token'] as String).trim();
      if (token.isNotEmpty) {
        await _storage.saveToken(server.id, token);
      }

      await _loadServers();

      if (!mounted) return;
      setState(() => _working = false);

      _showMessage('Servidor atualizado.');
    } catch (error) {
      if (!mounted) return;
      setState(() => _working = false);
      _showMessage('Não foi possível atualizar: $error');
    }
  }

  Future<Map<String, dynamic>?> _showServerDialog({
    ServerConnection? server,
  }) async {
    final nameController = TextEditingController(
      text: server?.name ?? '',
    );
    final urlController = TextEditingController(
      text: server?.baseUrl ?? '',
    );
    final tokenController = TextEditingController();

    String serverType = server?.serverType ?? 'custom';
    String? validationMessage;

    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: Text(
                server == null ? 'Adicionar servidor' : 'Editar servidor',
              ),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: nameController,
                      decoration: const InputDecoration(
                        labelText: 'Nome do servidor',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: urlController,
                      keyboardType: TextInputType.url,
                      autocorrect: false,
                      decoration: const InputDecoration(
                        labelText: 'Endereço (URL)',
                        hintText: 'https://servidor.com',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      initialValue: serverType,
                      decoration: const InputDecoration(
                        labelText: 'Tipo de servidor',
                        border: OutlineInputBorder(),
                      ),
                      items: const [
                        DropdownMenuItem(
                          value: 'cloudflare',
                          child: Text('Cloudflare Worker'),
                        ),
                        DropdownMenuItem(
                          value: 'custom',
                          child: Text('Servidor personalizado'),
                        ),
                        DropdownMenuItem(
                          value: 'other',
                          child: Text('Outro backend'),
                        ),
                      ],
                      onChanged: (value) {
                        if (value != null) {
                          setDialogState(() => serverType = value);
                        }
                      },
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: tokenController,
                      obscureText: true,
                      autocorrect: false,
                      enableSuggestions: false,
                      decoration: InputDecoration(
                        labelText: server == null
                            ? 'Token de acesso'
                            : 'Novo token (opcional)',
                        hintText: server == null
                            ? 'Informe o token'
                            : 'Deixe vazio para manter o atual',
                        border: const OutlineInputBorder(),
                      ),
                    ),
                    if (validationMessage != null) ...[
                      const SizedBox(height: 12),
                      Text(
                        validationMessage!,
                        style: TextStyle(
                          color: Theme.of(context).colorScheme.error,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('Cancelar'),
                ),
                FilledButton(
                  onPressed: () {
                    final name = nameController.text.trim();
                    final url = urlController.text.trim();
                    final token = tokenController.text.trim();

                    final uri = Uri.tryParse(url);

                    if (name.isEmpty) {
                      setDialogState(() {
                        validationMessage = 'Informe o nome do servidor.';
                      });
                      return;
                    }

                    if (uri == null ||
                        !uri.hasAuthority ||
                        (uri.scheme != 'https' && uri.scheme != 'http')) {
                      setDialogState(() {
                        validationMessage =
                            'Informe uma URL válida começando com http:// ou https://.';
                      });
                      return;
                    }

                    if (uri.query.isNotEmpty || uri.fragment.isNotEmpty) {
                      setDialogState(() {
                        validationMessage =
                            'Informe somente o endereço base, sem parâmetros ou fragmentos.';
                      });
                      return;
                    }

                    if (server == null && token.isEmpty) {
                      setDialogState(() {
                        validationMessage = 'Informe o token de acesso.';
                      });
                      return;
                    }

                    Navigator.pop(dialogContext, {
                      'name': name,
                      'baseUrl': url.replaceFirst(RegExp(r'/+$'), ''),
                      'serverType': serverType,
                      'token': token,
                    });
                  },
                  child: const Text('Salvar'),
                ),
              ],
            );
          },
        );
      },
    );

    nameController.dispose();
    urlController.dispose();
    tokenController.dispose();

    return result;
  }

  Future<void> _testServer(ServerConnection server) async {
    setState(() {
      _testingServers.add(server.id);
      _testMessages.remove(server.id);
      _testResults.remove(server.id);
    });

    try {
      final token = await _storage.readToken(server.id);

      if (token == null || token.isEmpty) {
        throw Exception('Este servidor não possui token configurado.');
      }

      final uri = Uri.parse('${server.baseUrl}/api/provedores');

      final response = await http
          .get(
            uri,
            headers: {
              'Content-Type': 'application/json; charset=utf-8',
              'Authorization': 'Bearer $token',
            },
          )
          .timeout(const Duration(seconds: 20));

      if (response.statusCode < 200 || response.statusCode >= 300) {
        if (response.statusCode == 401 || response.statusCode == 403) {
          throw Exception('Token inválido ou acesso não autorizado.');
        }

        throw Exception(
          'O servidor respondeu com o código ${response.statusCode}.',
        );
      }

      final body = utf8.decode(response.bodyBytes);
      final data = jsonDecode(body);

      if (data is! Map || data['provedores'] is! List) {
        throw Exception(
          'O servidor respondeu, mas não possui o formato de API esperado.',
        );
      }

      final count = (data['provedores'] as List).length;

      if (!mounted) return;

      setState(() {
        _testResults[server.id] = true;
        _testMessages[server.id] =
            'Conexão confirmada. $count provedor(es) encontrado(s).';
      });
    } catch (error) {
      if (!mounted) return;

      setState(() {
        _testResults[server.id] = false;
        _testMessages[server.id] = error.toString().replaceFirst(
              'Exception: ',
              '',
            );
      });
    } finally {
      if (mounted) {
        setState(() => _testingServers.remove(server.id));
      }
    }
  }

  Future<void> _selectServer(ServerConnection server) async {
    try {
      await _storage.setActive(server.id);
      await _loadServers();

      if (!mounted) return;
      _showMessage('Servidor ativo atualizado.');
    } catch (error) {
      _showMessage('Não foi possível selecionar o servidor: $error');
    }
  }

  Future<void> _toggleServer(ServerConnection server) async {
    try {
      final updated = server.copyWith(
        active: !server.active,
        updatedAt: DateTime.now(),
      );

      await _storage.update(updated);
      await _loadServers();

      if (!mounted) return;

      _showMessage(
        updated.active ? 'Servidor ativado.' : 'Servidor desativado.',
      );
    } catch (error) {
      _showMessage('Não foi possível alterar o servidor: $error');
    }
  }

  Future<void> _deleteServer(ServerConnection server) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Excluir servidor?'),
          content: Text(
            'O servidor "${server.name}" e seu token local serão removidos. '
            'Essa operação não exclui nada do servidor remoto.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Excluir'),
            ),
          ],
        );
      },
    );

    if (confirmed != true) return;

    try {
      await _storage.remove(server.id);
      await _loadServers();

      if (!mounted) return;
      _showMessage('Servidor removido.');
    } catch (error) {
      _showMessage('Não foi possível remover o servidor: $error');
    }
  }

  void _showMessage(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  String _serverTypeLabel(String type) {
    switch (type) {
      case 'cloudflare':
        return 'Cloudflare Worker';
      case 'other':
        return 'Outro backend';
      default:
        return 'Servidor personalizado';
    }
  }

  Widget _buildServerCard(ServerConnection server) {
    final isSelected = _activeServerId == server.id;
    final isTesting = _testingServers.contains(server.id);
    final testMessage = _testMessages[server.id];
    final testSuccess = _testResults[server.id];

    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  child: Icon(
                    server.serverType == 'cloudflare'
                        ? Icons.cloud
                        : Icons.dns_outlined,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        server.name,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      Text(_serverTypeLabel(server.serverType)),
                    ],
                  ),
                ),
                if (isSelected)
                  const Chip(
                    avatar: Icon(Icons.check_circle, size: 17),
                    label: Text('Selecionado'),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            SelectableText(
              server.baseUrl,
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(
                  server.active ? Icons.check_circle_outline : Icons.pause,
                  size: 18,
                  color: server.active ? Colors.green : Colors.orange,
                ),
                const SizedBox(width: 6),
                Text(server.active ? 'Ativo' : 'Desativado'),
              ],
            ),
            if (testMessage != null) ...[
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: testSuccess == true
                      ? Colors.green.withValues(alpha: 0.10)
                      : Theme.of(context).colorScheme.errorContainer,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      testSuccess == true
                          ? Icons.check_circle_outline
                          : Icons.error_outline,
                      size: 20,
                    ),
                    const SizedBox(width: 8),
                    Expanded(child: Text(testMessage)),
                  ],
                ),
              ),
            ],
            const Divider(height: 24),
            Wrap(
              spacing: 6,
              runSpacing: 4,
              children: [
                TextButton.icon(
                  onPressed: isTesting ? null : () => _testServer(server),
                  icon: isTesting
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.wifi_tethering),
                  label: const Text('Testar'),
                ),
                TextButton.icon(
                  onPressed: () => _editServer(server),
                  icon: const Icon(Icons.edit_outlined),
                  label: const Text('Editar'),
                ),
                TextButton.icon(
                  onPressed: () => _toggleServer(server),
                  icon: Icon(
                    server.active ? Icons.pause : Icons.play_arrow,
                  ),
                  label: Text(server.active ? 'Desativar' : 'Ativar'),
                ),
                if (server.active && !isSelected)
                  TextButton.icon(
                    onPressed: () => _selectServer(server),
                    icon: const Icon(Icons.radio_button_checked),
                    label: const Text('Selecionar'),
                  ),
                TextButton.icon(
                  onPressed: () => _deleteServer(server),
                  icon: const Icon(Icons.delete_outline),
                  label: const Text('Excluir'),
                  style: TextButton.styleFrom(
                    foregroundColor: Theme.of(context).colorScheme.error,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Central de Servidores'),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _working ? null : _addServer,
        icon: const Icon(Icons.add),
        label: const Text('Adicionar servidor'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _working
              ? const Center(child: CircularProgressIndicator())
              : _servers.isEmpty
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.cloud_off_outlined,
                              size: 56,
                            ),
                            const SizedBox(height: 16),
                            const Text(
                              'Nenhum servidor cadastrado.',
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 12),
                            FilledButton.icon(
                              onPressed: _addServer,
                              icon: const Icon(Icons.add),
                              label: const Text('Adicionar servidor'),
                            ),
                          ],
                        ),
                      ),
                    )
                  : ListView(
                      padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
                      children: [
                        Text(
                          'Gerencie os servidores que poderão ser '
                          'utilizados pelo aplicativo.',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                        const SizedBox(height: 16),
                        Card(
                          child: Padding(
                            padding: const EdgeInsets.all(14),
                            child: Row(
                              children: [
                                const Icon(Icons.info_outline),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    'Cada servidor possui seu próprio token, '
                                    'armazenado localmente com proteção.',
                                    style:
                                        Theme.of(context).textTheme.bodySmall,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        ..._servers.map(_buildServerCard),
                        const SizedBox(height: 12),
                        const Text(
                          'O teste verifica a rota /api/provedores. '
                          'Servidores com outras interfaces precisarão '
                          'de um adaptador específico.',
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
    );
  }
}
