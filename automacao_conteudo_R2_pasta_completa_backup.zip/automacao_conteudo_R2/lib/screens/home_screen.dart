
import 'package:flutter/material.dart';

import 'topics_screen.dart';
import 'social_networks_screen.dart';
import 'network_catalog_screen.dart';
import 'api_center_screen.dart';
import 'api_fallback_test_screen.dart';
import 'api_fallback_history_screen.dart';
import 'content_generator_screen.dart';
import 'post_schedule_screen.dart';
import 'post_history_screen.dart';
import 'worker_access_screen.dart';
import 'automation_center_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Automação de Conteúdo'),
        centerTitle: false,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Painel principal',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 8),
              Text(
                'Centralize a criação, organização e automação '
                'dos seus conteúdos.',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 24),

              _buildSectionTitle(context, 'Conteúdo e redes sociais'),
              const SizedBox(height: 12),

              _buildMenuCard(
                context: context,
                title: 'Temas de conteúdo',
                description:
                    'Cadastre e organize os temas para gerar conteúdo.',
                icon: Icons.topic_outlined,
                onTap: () => _navigate(context, const TopicsScreen()),
              ),
              _buildMenuCard(
                context: context,
                title: 'Gerador de Conteúdo',
                description:
                    'Prepare legendas, carrosséis e roteiros para vídeos.',
                icon: Icons.auto_awesome_outlined,
                onTap: () =>
                    _navigate(context, const ContentGeneratorScreen()),
              ),
              _buildMenuCard(
                context: context,
                title: 'Configuração de Postagens',
                description:
                    'Prepare rascunhos e registre agendamentos.',
                icon: Icons.calendar_month_outlined,
                onTap: () => _navigate(context, const PostScheduleScreen()),
              ),
              _buildMenuCard(
                context: context,
                title: 'Histórico de Postagens',
                description:
                    'Consulte os rascunhos e agendamentos salvos.',
                icon: Icons.history_outlined,
                onTap: () => _navigate(context, const PostHistoryScreen()),
              ),
              _buildMenuCard(
                context: context,
                title: 'Redes sociais por tema',
                description:
                    'Gerencie várias contas e páginas associadas aos temas.',
                icon: Icons.share_outlined,
                onTap: () =>
                    _navigate(context, const SocialNetworksScreen()),
              ),
              _buildMenuCard(
                context: context,
                title: 'Central de Redes',
                description:
                    'Consulte e gerencie o catálogo de redes disponíveis.',
                icon: Icons.hub_outlined,
                onTap: () =>
                    _navigate(context, const NetworkCatalogScreen()),
              ),

              const SizedBox(height: 24),
              _buildSectionTitle(context, 'Inteligência artificial'),
              const SizedBox(height: 12),

              _buildMenuCard(
                context: context,
                title: 'Central de APIs',
                description:
                    'Gerencie provedores, contas, capacidades e alternativas.',
                icon: Icons.api_outlined,
                onTap: () => _navigate(context, const ApiCenterScreen()),
              ),
              _buildMenuCard(
                context: context,
                title: 'Acesso ao Servidor',
                description:
                    'Configure o acesso e teste a conexão com o servidor.',
                icon: Icons.cloud_outlined,
                onTap: () => _navigate(context, const WorkerAccessScreen()),
              ),
              _buildMenuCard(
                context: context,
                title: 'Teste de alternativas',
                description:
                    'Simule falhas e confira a seleção de APIs alternativas.',
                icon: Icons.swap_horiz,
                onTap: () => _navigate(context, ApiFallbackTestScreen()),
              ),
              _buildMenuCard(
                context: context,
                title: 'Histórico de falhas de APIs',
                description:
                    'Consulte os resultados registrados das simulações.',
                icon: Icons.history,
                onTap: () =>
                    _navigate(context, const ApiFallbackHistoryScreen()),
              ),

              const SizedBox(height: 24),
              _buildSectionTitle(context, 'Gestão e acompanhamento'),
              const SizedBox(height: 12),

              _buildPlannedCard(
                context,
                title: 'Estatísticas e Desempenho',
                description:
                    'Acompanhe visualizações, alcance, curtidas, '
                    'comentários, compartilhamentos e crescimento.',
                icon: Icons.analytics_outlined,
                details: const [
                  'Lançamento manual de métricas.',
                  'Importação futura por APIs oficiais.',
                  'Comparação entre redes, páginas e temas.',
                  'Histórico por publicação e período.',
                  'Relatórios de campanhas publicitárias.',
                ],
              ),
              _buildPlannedCard(
                context,
                title: 'Publicidade e Campanhas',
                description:
                    'Organize anunciantes, contratos, campanhas e entregas.',
                icon: Icons.campaign_outlined,
                details: const [
                  'Cadastro de anunciantes e contatos.',
                  'Campanhas exclusivas ou compartilhadas.',
                  'Controle de formatos e páginas contratadas.',
                  'Limites de quantidade e período.',
                  'Acompanhamento de aprovação e entrega.',
                ],
              ),
              _buildPlannedCard(
                context,
                title: 'Biblioteca de Materiais',
                description:
                    'Organize imagens, vídeos, logotipos e referências.',
                icon: Icons.perm_media_outlined,
                details: const [
                  'Materiais vinculados a temas e campanhas.',
                  'Organização por tipo e finalidade.',
                  'Referências visuais para geração de conteúdo.',
                  'Preparação para armazenamento local e remoto.',
                ],
              ),

              // Central de Automações: módulo já implementado.
              _buildMenuCard(
                context: context,
                title: 'Central de Automações',
                description:
                    'Consulte a fila, acompanhe tarefas e gerencie '
                    'o processamento automático.',
                icon: Icons.precision_manufacturing_outlined,
                onTap: () =>
                    _navigate(context, const AutomationCenterScreen()),
              ),

              _buildPlannedCard(
                context,
                title: 'Sincronização e Monitoramento',
                description:
                    'Acompanhe os dados locais, servidores e sincronizações.',
                icon: Icons.sync_outlined,
                details: const [
                  'Fila de sincronização local.',
                  'Preparação para Cloudflare D1.',
                  'Registro de operações e erros.',
                  'Recuperação de tarefas pendentes.',
                  'Histórico de sincronização.',
                ],
              ),

              const SizedBox(height: 24),
              _buildSectionTitle(context, 'Informações do projeto'),
              const SizedBox(height: 12),

              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(
                        Icons.info_outline,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Text(
                          'O projeto está em desenvolvimento. '
                          'O cadastro de provedores e as simulações '
                          'não representam, por si só, chamadas reais '
                          'às APIs nem publicações automáticas. '
                          'As integrações serão ativadas conforme '
                          'cada módulo for implementado e testado.',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  void _navigate(BuildContext context, Widget screen) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => screen),
    );
  }

  Widget _buildSectionTitle(BuildContext context, String title) {
    return Text(
      title,
      style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
          ),
    );
  }

  Widget _buildMenuCard({
    required BuildContext context,
    required String title,
    required String description,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      clipBehavior: Clip.antiAlias,
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 10,
        ),
        leading: CircleAvatar(child: Icon(icon)),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text(description),
        ),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }

  Widget _buildPlannedCard(
    BuildContext context, {
    required String title,
    required String description,
    required IconData icon,
    required List<String> details,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      clipBehavior: Clip.antiAlias,
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 10,
        ),
        leading: CircleAvatar(child: Icon(icon)),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text(description),
        ),
        trailing: const Icon(Icons.construction_outlined),
        onTap: () {
          _navigate(
            context,
            PlannedModuleScreen(
              title: title,
              description: description,
              icon: icon,
              details: details,
            ),
          );
        },
      ),
    );
  }
}

class PlannedModuleScreen extends StatelessWidget {
  final String title;
  final String description;
  final IconData icon;
  final List<String> details;

  const PlannedModuleScreen({
    super.key,
    required this.title,
    required this.description,
    required this.icon,
    required this.details,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          CircleAvatar(
            radius: 34,
            child: Icon(icon, size: 34),
          ),
          const SizedBox(height: 20),
          Text(
            title,
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 12),
          Text(
            description,
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          const Text(
            'Planejamento do módulo',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          ...details.map(
            (detail) => ListTile(
              leading: const Icon(Icons.check_circle_outline),
              title: Text(detail),
              contentPadding: EdgeInsets.zero,
            ),
          ),
          const SizedBox(height: 20),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.info_outline),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Este módulo está planejado, mas suas funções '
                      'ainda não estão implementadas. A estrutura '
                      'será desenvolvida e testada antes de sua ativação.',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
