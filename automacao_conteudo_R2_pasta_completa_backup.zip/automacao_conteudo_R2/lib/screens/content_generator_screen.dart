import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/automation_task.dart';
import '../services/automation_task_service.dart';
import '../services/automation_task_executor.dart';
import 'post_history_screen.dart';

class ContentGeneratorScreen extends StatefulWidget {
  const ContentGeneratorScreen({super.key});

  @override
  State<ContentGeneratorScreen> createState() =>
      _ContentGeneratorScreenState();
}

class _ContentGeneratorScreenState
    extends State<ContentGeneratorScreen> {
  static const String _topicsStorageKey = 'content_topics_v2';

  final TextEditingController _audienceController =
      TextEditingController();

  final TextEditingController _objectiveController =
      TextEditingController();

  final TextEditingController _resultController =
      TextEditingController();

  final AutomationTaskService _taskService =
      AutomationTaskService();

  List<Map<String, dynamic>> _topics = [];

  String? _selectedTopicId;

  String _format = 'Legenda';
  String _tone = 'Natural e envolvente';
  String _videoStyle = 'Dinâmico';

  int _quantity = 1;
  String _period = 'Dia';
  String _repetition = 'Uma única vez';
  List<Map<String, dynamic>> _accounts = [];
  final Set<String> _selectedAccountIds = {};

  bool _loading = true;
  bool _addingToQueue = false;

  final List<String> _formats = const [
    'Legenda',
    'Carrossel',
    'Roteiro para vídeo',
    'Publicação completa',
  ];

  final List<String> _tones = const [
    'Natural e envolvente',
    'Profissional',
    'Divertido',
    'Educativo',
    'Inspirador',
    'Persuasivo',
  ];

  final List<String> _videoStyles = const [
    'Dinâmico',
    'Cinematográfico',
    'Documental',
    'Minimalista',
    'Narrativo',
    'Educativo',
  ];

  Map<String, dynamic>? get _selectedTopic {
    for (final topic in _topics) {
      if (topic['id'] == _selectedTopicId) {
        return topic;
      }
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    _loadTopics();
  }

  Future<void> _loadTopics() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final storedData = prefs.getString(_topicsStorageKey);

      if (storedData != null && storedData.isNotEmpty) {
        final decoded = jsonDecode(storedData);

        if (decoded is List) {
          _topics = decoded
              .whereType<Map>()
              .map((item) => Map<String, dynamic>.from(item))
              .where((topic) {
                final id = topic['id'];
                final name = topic['name'];

                return topic['active'] == true &&
                    id is String &&
                    id.trim().isNotEmpty &&
                    name is String &&
                    name.trim().isNotEmpty;
              })
              .toList();
        }
      }
    } catch (_) {
      _topics = [];
    }

    if (!mounted) return;

    setState(() {
      _selectedTopicId =
          _topics.isNotEmpty ? _topics.first['id'] as String : null;
    });
    if (_selectedTopicId != null) {
      await _loadAccountsForTopic(_selectedTopicId!);
    }
    if (!mounted) return;
    setState(() => _loading = false);
  }

  Future<void> _loadAccountsForTopic(String topicId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('social_accounts_topic_id_$topicId');
      final decoded = raw == null ? null : jsonDecode(raw);
      final accounts = decoded is List
          ? decoded.whereType<Map>().map((item) => Map<String, dynamic>.from(item))
              .where((item) => item['active'] == true &&
                  (item['id']?.toString().trim().isNotEmpty ?? false))
              .toList()
          : <Map<String, dynamic>>[];
      if (!mounted) return;
      setState(() {
        _accounts = accounts;
        _selectedAccountIds
          ..clear()
          ..addAll(accounts.map((item) => item['id'].toString()));
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _accounts = [];
        _selectedAccountIds.clear();
      });
    }
  }

  void _prepareDraft() {
    final topic = _selectedTopic;

    if (topic == null) {
      _showMessage(
        'Cadastre e ative um tema antes de continuar.',
      );
      return;
    }

    final name = topic['name'] as String;
    final description =
        (topic['description'] as String? ?? '').trim();

    final audience = _audienceController.text.trim();
    final objective = _objectiveController.text.trim();

    final buffer = StringBuffer()
      ..writeln('TEMA: $name')
      ..writeln('ID DO TEMA: $_selectedTopicId');

    if (description.isNotEmpty) {
      buffer.writeln('DESCRIÇÃO: $description');
    }

    buffer
      ..writeln('FORMATO: $_format')
      ..writeln('QUANTIDADE POR PERÍODO: $_quantity')
      ..writeln('PERÍODO: $_period')
      ..writeln('REPETIÇÃO: $_repetition')
      ..writeln('TOM: $_tone');

    if (_format == 'Roteiro para vídeo' ||
        _format == 'Publicação completa') {
      buffer.writeln('ESTILO DE VÍDEO: $_videoStyle');
    }

    buffer
      ..writeln(
        'PÚBLICO-ALVO: ${audience.isEmpty ? "A definir" : audience}',
      )
      ..writeln(
        'OBJETIVO: ${objective.isEmpty ? "A definir" : objective}',
      )
      ..writeln()
      ..writeln('RASCUNHO DE SOLICITAÇÃO')
      ..writeln(
        'Crie $_quantity conjunto(s) de conteúdo no formato '
        '"$_format" sobre "$name", usando um tom $_tone.',
      );

    if (description.isNotEmpty) {
      buffer.writeln('Considere esta descrição: $description');
    }

    if (audience.isNotEmpty) {
      buffer.writeln('Público-alvo: $audience.');
    }

    if (objective.isNotEmpty) {
      buffer.writeln('Objetivo: $objective.');
    }

    if (_format == 'Roteiro para vídeo' ||
        _format == 'Publicação completa') {
      buffer.writeln('Estilo de edição: $_videoStyle.');
    }

    buffer
      ..writeln()
      ..writeln(
        'Este é um rascunho de solicitação. '
        'Use o botão "Gerar conteúdo agora" para executar a geração.',
      );

    setState(() {
      _resultController.text = buffer.toString();
    });
  }

  String _friendlyErrorMessage(Object error) {
    final message = error.toString().replaceFirst(
          'Exception: ',
          '',
        );

    if (message.trim().isEmpty) {
      return 'Ocorreu uma falha inesperada ao cadastrar a tarefa.';
    }

    return message;
  }

  String _buildPrompt(Map<String, dynamic> topic) {
    final name = topic['name'] as String;
    final description =
        (topic['description'] as String? ?? '').trim();

    final audience = _audienceController.text.trim();
    final objective = _objectiveController.text.trim();

    final buffer = StringBuffer()
      ..writeln('Crie conteúdo de qualidade em português brasileiro.')
      ..writeln()
      ..writeln('Tema: $name')
      ..writeln('ID do tema: $_selectedTopicId')
      ..writeln(
        'Descrição: ${description.isEmpty ? "Não informada" : description}',
      )
      ..writeln('Formato: $_format')
      ..writeln('Quantidade por período: $_quantity')
      ..writeln('Período: $_period')
      ..writeln('Repetição: $_repetition')
      ..writeln('Tom: $_tone')
      ..writeln(
        'Público-alvo: ${audience.isEmpty ? "Não especificado" : audience}',
      )
      ..writeln(
        'Objetivo: ${objective.isEmpty ? "Não especificado" : objective}',
      );

    if (_format == 'Roteiro para vídeo' ||
        _format == 'Publicação completa') {
      buffer.writeln('Estilo de edição: $_videoStyle');
    }

    buffer.writeln();
    buffer.writeln('INSTRUÇÕES GERAIS:');
    buffer.writeln('- Entregue conteúdo final, pronto para revisão.');
    buffer.writeln('- Respeite o formato e o tom selecionados.');
    buffer.writeln('- Não invente fatos ou fontes.');
    buffer.writeln('- Não inclua explicações sobre o processo de geração.');
    buffer.writeln('- Toda legenda deve terminar com o aviso obrigatório.');
    buffer.writeln('- Gere exatamente $_quantity publicações independentes.');
    buffer.writeln('- Inicie cada bloco com PUBLICAÇÃO 1:, PUBLICAÇÃO 2: e assim sucessivamente.');

    switch (_format) {
      case 'Legenda':
        buffer
          ..writeln()
          ..writeln('FORMATO LEGENDA:')
          ..writeln('- Gere $_quantity legenda(s), uma em cada bloco PUBLICAÇÃO N:.')
          ..writeln('- Cada legenda deve ser independente e começar com LEGENDA:.')
          ..writeln('- Inclua o aviso obrigatório ao final de cada uma.');
        break;

      case 'Carrossel':
        buffer
          ..writeln()
          ..writeln('FORMATO CARROSSEL:')
          ..writeln('- Gere $_quantity conjunto(s), um em cada bloco PUBLICAÇÃO N:.')
          ..writeln('- Comece com o bloco LEGENDA: contendo a legenda completa.')
          ..writeln('- Depois apresente exatamente quatro blocos: SLIDE 1:, SLIDE 2:, SLIDE 3: e SLIDE 4:.')
          ..writeln('- Slide 1: introdução e apresentação do assunto.')
          ..writeln('- Slide 2: desenvolvimento.')
          ..writeln('- Slide 3: conclusão.')
          ..writeln('- Slide 4: chamada para ação.')
          ..writeln('- Inclua texto e orientação visual para cada slide.')
          ..writeln('- A narrativa deve ter continuidade.')
          ..writeln('- Inclua o aviso obrigatório na legenda.');
        break;

      case 'Roteiro para vídeo':
        buffer
          ..writeln()
          ..writeln('FORMATO VÍDEO:')
          ..writeln('- Gere $_quantity roteiro(s), um em cada bloco PUBLICAÇÃO N:.')
          ..writeln('- Cada bloco deve conter LEGENDA: e ROTEIRO:.')
          ..writeln('- Divida o roteiro em cenas.')
          ..writeln('- Descreva imagem, ação, narração e áudio.')
          ..writeln('- Considere o estilo de edição selecionado.')
          ..writeln('- Inclua o aviso obrigatório na legenda.');
        break;

      case 'Publicação completa':
        buffer
          ..writeln()
          ..writeln('FORMATO PUBLICAÇÃO COMPLETA:')
          ..writeln('- Gere $_quantity conjunto(s) completo(s), um em cada bloco PUBLICAÇÃO N:.')
          ..writeln('- Cada conjunto deve conter uma seção LEGENDA:.')
          ..writeln('- Cada conjunto deve conter os blocos SLIDE 1: a SLIDE 4:.')
          ..writeln('- Cada conjunto deve conter uma seção ROTEIRO: para o vídeo.')
          ..writeln('- Cada conjunto deve conter um roteiro de vídeo.')
          ..writeln('- Inclua orientações visuais para o carrossel.')
          ..writeln('- Inclua cenas, narração e áudio no vídeo.')
          ..writeln('- Inclua o aviso obrigatório em cada legenda.');
        break;
    }

    return buffer.toString();
  }

  Future<void> _generateContent() async {
    if (_addingToQueue) return;

    final topic = _selectedTopic;
    if (topic == null) {
      _showMessage('Cadastre e ative um tema antes de continuar.');
      return;
    }

    setState(() => _addingToQueue = true);

    try {
      final prompt = _buildPrompt(topic);
      final now = DateTime.now();
      final targetAccounts = _accounts
          .where((account) =>
              _selectedAccountIds.contains(account['id'].toString()))
          .map((account) => Map<String, dynamic>.from(account))
          .toList();

      final task = AutomationTask(
        id: 'task_${now.microsecondsSinceEpoch}',
        type: AutomationTaskType.contentGeneration,
        topicId: _selectedTopicId,
        payload: {
          'prompt': prompt,
          'topicName': topic['name'],
          'topicDescription': topic['description'] ?? '',
          'format': _format,
          'quantity': _quantity,
          'period': _period,
          'repetition': _repetition,
          'tone': _tone,
          'videoStyle': _videoStyle,
          'audience': _audienceController.text.trim(),
          'objective': _objectiveController.text.trim(),
          'targetAccounts': targetAccounts,
          'source': 'content_generator',
        },
        createdAt: now,
        updatedAt: now,
      );

      final added = await _taskService.add(task);
      if (!added) {
        if (mounted) {
          _showMessage('Não foi possível registrar a geração.');
        }
        return;
      }

      final executor = AutomationTaskExecutor(taskService: _taskService);
      try {
        await executor.executeTask(task.id);
      } finally {
        executor.dispose();
      }

      final finishedTask = await _taskService.getById(task.id);
      if (!mounted) return;

      final payload = finishedTask?.payload ?? const <String, dynamic>{};
      final generated = (payload['result'] ?? payload['generatedText'] ?? '')
          .toString();
      if (generated.isNotEmpty) {
        _resultController.text = generated;
      }

      final draftCount = payload['draftCount'] is num
          ? (payload['draftCount'] as num).toInt()
          : 0;
      if (draftCount > 0) {
        _showMessage(
          finishedTask?.status == AutomationTaskStatus.completed
              ? 'Conteúdo gerado e encaminhado para $draftCount postagem(ns). Abrindo Configuração de Postagens.'
              : 'Foram criados $draftCount rascunho(s), mas há materiais pendentes. Abrindo Configuração de Postagens para revisão.',
        );
        await Navigator.push<void>(
          context,
          MaterialPageRoute(builder: (_) => const PostHistoryScreen()),
        );
      } else if (finishedTask?.status == AutomationTaskStatus.completed) {
        _showMessage(
          'Conteúdo gerado, mas nenhuma conta selecionada aceita este formato. Revise as contas e os formatos permitidos.',
        );
      } else {
        _showMessage(
          finishedTask?.lastError ??
              'A geração não foi concluída. Consulte a Central de Automações.',
        );
      }
    } catch (error) {
      if (mounted) {
        _showMessage('Falha na geração: ${_friendlyErrorMessage(error)}');
      }
    } finally {
      if (mounted) setState(() => _addingToQueue = false);
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _copyResult() async {
    final text = _resultController.text.trim();

    if (text.isEmpty) {
      _showMessage(
        'Prepare um rascunho ou gere um conteúdo antes de copiar.',
      );
      return;
    }

    await Clipboard.setData(
      ClipboardData(text: text),
    );

    if (mounted) {
      _showMessage('Texto copiado.');
    }
  }

  @override
  void dispose() {
    _audienceController.dispose();
    _objectiveController.dispose();
    _resultController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final hasTopic = _selectedTopic != null;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Gerador de Conteúdo'),
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                const Text(
                  'Prepare seu conteúdo',
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Configure a quantidade, o período, a repetição e as contas de destino.',
                ),
                const SizedBox(height: 24),

                const Text(
                  'Tema ativo',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 8),

                if (_topics.isEmpty)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(16),
                      child: Text(
                        'Nenhum tema ativo encontrado. '
                        'Volte à tela Temas de conteúdo para '
                        'cadastrar ou ativar um tema.',
                      ),
                    ),
                  )
                else
                  DropdownButtonFormField<String>(
                    initialValue: _selectedTopicId,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.topic_outlined),
                    ),
                    items: _topics.map((topic) {
                      final id = topic['id'] as String;
                      final name = topic['name'] as String;

                      return DropdownMenuItem<String>(
                        value: id,
                        child: Text(
                          name,
                          overflow: TextOverflow.ellipsis,
                        ),
                      );
                    }).toList(),
                    onChanged: (value) async {
                      setState(() {
                        _selectedTopicId = value;
                        _accounts = [];
                        _selectedAccountIds.clear();
                      });
                      if (value != null) await _loadAccountsForTopic(value);
                    },
                  ),

                const SizedBox(height: 20),

                DropdownButtonFormField<String>(
                  initialValue: _format,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Formato do conteúdo',
                    border: OutlineInputBorder(),
                  ),
                  items: _formats.map((format) {
                    return DropdownMenuItem<String>(
                      value: format,
                      child: Text(format),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _format = value;
                      });
                    }
                  },
                ),

                const SizedBox(height: 16),

                DropdownButtonFormField<String>(
                  initialValue: _tone,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Tom do conteúdo',
                    border: OutlineInputBorder(),
                  ),
                  items: _tones.map((tone) {
                    return DropdownMenuItem<String>(
                      value: tone,
                      child: Text(tone),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _tone = value;
                      });
                    }
                  },
                ),

                if (_format == 'Roteiro para vídeo' ||
                    _format == 'Publicação completa') ...[
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    initialValue: _videoStyle,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'Estilo de edição do vídeo',
                      border: OutlineInputBorder(),
                    ),
                    items: _videoStyles.map((style) {
                      return DropdownMenuItem<String>(
                        value: style,
                        child: Text(style),
                      );
                    }).toList(),
                    onChanged: (value) {
                      if (value != null) {
                        setState(() {
                          _videoStyle = value;
                        });
                      }
                    },
                  ),
                ],

                const SizedBox(height: 16),

                DropdownButtonFormField<int>(
                  initialValue: _quantity,
                  decoration: const InputDecoration(
                    labelText: 'Quantidade de publicações',
                    border: OutlineInputBorder(),
                  ),
                  items: List.generate(10, (index) {
                    final value = index + 1;

                    return DropdownMenuItem<int>(
                      value: value,
                      child: Text('$value'),
                    );
                  }),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _quantity = value;
                      });
                    }
                  },
                ),

                const SizedBox(height: 16),

                DropdownButtonFormField<String>(
                  initialValue: _period,
                  decoration: const InputDecoration(
                    labelText: 'Período de produção',
                    border: OutlineInputBorder(),
                  ),
                  items: const ['Dia', 'Semana', 'Quinzena', 'Mês']
                      .map((value) => DropdownMenuItem(
                            value: value,
                            child: Text(value),
                          ))
                      .toList(),
                  onChanged: (value) {
                    if (value != null) setState(() => _period = value);
                  },
                ),

                const SizedBox(height: 16),

                DropdownButtonFormField<String>(
                  initialValue: _repetition,
                  decoration: const InputDecoration(
                    labelText: 'Repetição da programação',
                    border: OutlineInputBorder(),
                  ),
                  items: const ['Uma única vez', 'Continuamente']
                      .map((value) => DropdownMenuItem(
                            value: value,
                            child: Text(value),
                          ))
                      .toList(),
                  onChanged: (value) {
                    if (value != null) setState(() => _repetition = value);
                  },
                ),

                const SizedBox(height: 16),

                if (_accounts.isNotEmpty) ...[
                  const Text('Contas de destino',
                      style: TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  ..._accounts.map((account) {
                    final id = account['id'].toString();
                    final platform = (account['platform'] ??
                            account['networkId'] ?? 'Rede')
                        .toString();
                    final name = (account['name'] ??
                            account['username'] ?? platform)
                        .toString();
                    return CheckboxListTile(
                      contentPadding: EdgeInsets.zero,
                      value: _selectedAccountIds.contains(id),
                      title: Text('$platform · $name'),
                      subtitle: Text((account['username'] ?? '').toString()),
                      onChanged: (checked) {
                        setState(() {
                          if (checked == true) {
                            _selectedAccountIds.add(id);
                          } else {
                            _selectedAccountIds.remove(id);
                          }
                        });
                      },
                    );
                  }),
                ] else
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(12),
                      child: Text(
                        'Nenhuma conta social ativa cadastrada para este tema. '
                        'A geração poderá ser executada, mas não haverá encaminhamento automático.',
                      ),
                    ),
                  ),

                const SizedBox(height: 16),

                TextField(
                  controller: _audienceController,
                  decoration: const InputDecoration(
                    labelText: 'Público-alvo (opcional)',
                    hintText: 'Ex.: pequenos empreendedores',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.people_outline),
                  ),
                ),

                const SizedBox(height: 16),

                TextField(
                  controller: _objectiveController,
                  minLines: 2,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'Objetivo do conteúdo (opcional)',
                    hintText: 'Ex.: ensinar, informar ou divulgar',
                    border: OutlineInputBorder(),
                    alignLabelWithHint: true,
                  ),
                ),

                const SizedBox(height: 20),

                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: hasTopic ? _prepareDraft : null,
                    icon: const Icon(Icons.edit_note),
                    label: const Text('Preparar rascunho'),
                  ),
                ),

                const SizedBox(height: 12),

                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: !hasTopic || _addingToQueue
                        ? null
                        : _generateContent,
                    icon: _addingToQueue
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                            ),
                          )
                        : const Icon(Icons.playlist_add),
                    label: Text(
                      _addingToQueue
                          ? 'Gerando conteúdo...'
                          : 'Gerar conteúdo agora',
                    ),
                  ),
                ),

                const SizedBox(height: 28),

                const Text(
                  'Resultado / rascunho',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 12),

                TextField(
                  controller: _resultController,
                  minLines: 8,
                  maxLines: 18,
                  decoration: const InputDecoration(
                    hintText:
                        'O rascunho ou o resultado da geração aparecerá aqui.',
                    border: OutlineInputBorder(),
                    alignLabelWithHint: true,
                  ),
                ),

                const SizedBox(height: 12),

                OutlinedButton.icon(
                  onPressed: _copyResult,
                  icon: const Icon(Icons.copy),
                  label: const Text('Copiar texto'),
                ),

                const SizedBox(height: 12),

                const Text(
                  'A geração é executada imediatamente usando as APIs '
                  'ativas da Central de APIs. Os conteúdos encaminhados '
                  'ficam pendentes de aprovação. A repetição contínua é '
                  'registrada como configuração; a execução automática '
                  'em segundo plano ainda depende de um agendador.',
                  style: TextStyle(fontSize: 12),
                ),
              ],
            ),
    );
  }
}