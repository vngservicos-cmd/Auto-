
import 'package:flutter/material.dart';

import '../models/post_schedule.dart';
import '../services/post_schedule_service.dart';
import 'post_schedule_screen.dart';

class PostHistoryScreen extends StatefulWidget {
  const PostHistoryScreen({super.key});

  @override
  State<PostHistoryScreen> createState() => _PostHistoryScreenState();
}

class _PostHistoryScreenState extends State<PostHistoryScreen> {
  final PostScheduleService _service = PostScheduleService();

  List<PostSchedule> _schedules = [];
  bool _loading = true;
  bool _deleting = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadSchedules();
  }

  Future<void> _loadSchedules() async {
    if (mounted) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }

    try {
      final schedules = await _service.getAll();
      schedules.sort((a, b) => b.createdAt.compareTo(a.createdAt));

      if (!mounted) return;

      setState(() {
        _schedules = schedules;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;

      setState(() {
        _error = 'Não foi possível carregar o histórico: $error';
        _loading = false;
      });
    }
  }

  Future<void> _editSchedule(PostSchedule schedule) async {
    final updated = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => PostScheduleScreen(
          scheduleToEdit: schedule,
        ),
      ),
    );

    if (!mounted) return;

    if (updated == true) {
      await _loadSchedules();
    }
  }

  Future<void> _deleteSchedule(PostSchedule schedule) async {
    if (_deleting) return;

    final confirm = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Excluir postagem?'),
        content: const Text(
          'Este registro será removido do armazenamento local. '
          'Essa ação não pode ser desfeita.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );

    if (confirm != true || !mounted) return;

    setState(() {
      _deleting = true;
    });

    try {
      final removed = await _service.remove(schedule.id);

      if (!mounted) return;

      if (removed) {
        setState(() {
          _schedules.removeWhere((item) => item.id == schedule.id);
        });

        _showMessage('Postagem excluída.');
      } else {
        _showMessage('Não foi possível excluir a postagem.');
      }
    } catch (error) {
      if (!mounted) return;
      _showMessage('Erro ao excluir: $error');
    } finally {
      if (mounted) {
        setState(() {
          _deleting = false;
        });
      }
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  String _formatDate(DateTime date) {
    final day = date.day.toString().padLeft(2, '0');
    final month = date.month.toString().padLeft(2, '0');
    final year = date.year.toString();
    final hour = date.hour.toString().padLeft(2, '0');
    final minute = date.minute.toString().padLeft(2, '0');

    return '$day/$month/$year às $hour:$minute';
  }

  Color _approvalColor(String status) {
    switch (status.toLowerCase()) {
      case 'aprovado':
      case 'aprovada':
        return Colors.green;
      case 'reprovado':
      case 'reprovada':
        return Colors.red;
      default:
        return Colors.orange;
    }
  }

  Widget _buildInfoChip({
    required String label,
    IconData? icon,
    Color? color,
  }) {
    return Chip(
      avatar: icon != null
          ? Icon(icon, size: 16, color: color)
          : null,
      label: Text(label),
      side: color != null
          ? BorderSide(color: color.withValues(alpha: 0.4))
          : null,
    );
  }

  Widget _buildScheduleCard(PostSchedule schedule) {
    final caption = schedule.caption.trim();
    final videoScript = schedule.videoScript?.trim() ?? '';
    final videoPrompt = schedule.videoPrompt?.trim() ?? '';
    final topicName = schedule.topicName?.trim() ?? '';

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const CircleAvatar(
                  child: Icon(Icons.article_outlined),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    schedule.network,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
                IconButton(
                  tooltip: 'Editar postagem',
                  onPressed: _deleting
                      ? null
                      : () => _editSchedule(schedule),
                  icon: const Icon(Icons.edit_outlined),
                ),
                IconButton(
                  tooltip: 'Excluir postagem',
                  onPressed: _deleting
                      ? null
                      : () => _deleteSchedule(schedule),
                  icon: const Icon(Icons.delete_outline),
                ),
              ],
            ),

            const Divider(),

            if (topicName.isNotEmpty) ...[
              Row(
                children: [
                  const Icon(Icons.folder_outlined, size: 18),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Tema: $topicName',
                      style: const TextStyle(
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
            ],

            Row(
              children: [
                const Icon(Icons.category_outlined, size: 18),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Formato: ${schedule.contentFormat}',
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            Text(
              schedule.content,
              maxLines: 5,
              overflow: TextOverflow.ellipsis,
            ),


            if (schedule.carouselImageUrls.isNotEmpty) ...[
              const SizedBox(height: 10),
              _buildInfoChip(
                label: '${schedule.carouselImageUrls.length} imagem(ns) gerada(s)',
                icon: Icons.image_outlined,
              ),
            ],
            if (schedule.videoUrl != null && schedule.videoUrl!.trim().isNotEmpty) ...[
              const SizedBox(height: 6),
              _buildInfoChip(
                label: 'Vídeo gerado',
                icon: Icons.video_file_outlined,
              ),
            ],
            if (schedule.lastError != null && schedule.lastError!.trim().isNotEmpty) ...[
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.errorContainer,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  'Falha na geração: ${schedule.lastError}',
                  style: TextStyle(color: Theme.of(context).colorScheme.onErrorContainer),
                ),
              ),
            ],

            if (caption.isNotEmpty) ...[
              const SizedBox(height: 12),
              const Text(
                'Legenda',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              Text(
                caption,
                maxLines: 4,
                overflow: TextOverflow.ellipsis,
              ),
            ],

            if (videoScript.isNotEmpty) ...[
              const SizedBox(height: 12),
              const Text(
                'Roteiro do vídeo',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              Text(
                videoScript,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
            ],

            if (videoPrompt.isNotEmpty) ...[
              const SizedBox(height: 8),
              const Text(
                'Orientações para o vídeo',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              Text(
                videoPrompt,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],

            const SizedBox(height: 12),

            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                _buildInfoChip(
                  label: schedule.status,
                  icon: Icons.info_outline,
                ),
                _buildInfoChip(
                  label: schedule.approvalStatus,
                  icon: Icons.verified_outlined,
                  color: _approvalColor(schedule.approvalStatus),
                ),
                _buildInfoChip(
                  label: schedule.automatic
                      ? 'Agendamento ativado'
                      : 'Sem agendamento',
                  icon: Icons.calendar_month_outlined,
                ),
              ],
            ),

            const SizedBox(height: 8),

            Text(
              'Criada em: ${_formatDate(schedule.createdAt)}',
              style: const TextStyle(
                fontSize: 12,
                color: Colors.grey,
              ),
            ),

            if (schedule.scheduledAt != null) ...[
              const SizedBox(height: 4),
              Text(
                'Agendada para: ${_formatDate(schedule.scheduledAt!)}',
                style: const TextStyle(fontSize: 12),
              ),
            ],

            if (schedule.updatedAt != null) ...[
              const SizedBox(height: 4),
              Text(
                'Atualizada em: ${_formatDate(schedule.updatedAt!)}',
                style: const TextStyle(
                  fontSize: 12,
                  color: Colors.grey,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Configuração e Histórico de Postagens'),
        actions: [
          IconButton(
            tooltip: 'Atualizar histórico',
            onPressed: _loading ? null : _loadSchedules,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : _error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          _error!,
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 12),
                        FilledButton(
                          onPressed: _loadSchedules,
                          child: const Text('Tentar novamente'),
                        ),
                      ],
                    ),
                  ),
                )
              : _schedules.isEmpty
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.all(24),
                        child: Text(
                          'Nenhuma postagem salva ainda.',
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
                  : RefreshIndicator(
                      onRefresh: _loadSchedules,
                      child: ListView.builder(
                        padding: const EdgeInsets.all(12),
                        itemCount: _schedules.length,
                        itemBuilder: (context, index) {
                          return _buildScheduleCard(
                            _schedules[index],
                          );
                        },
                      ),
                    ),
    );
  }
}
