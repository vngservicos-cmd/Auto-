import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/automation_task.dart';
import '../services/automation_task_service.dart';
import '../services/automation_task_executor.dart';

class AutomationCenterScreen extends StatefulWidget {
  const AutomationCenterScreen({super.key});

  @override
  State<AutomationCenterScreen> createState() =>
      _AutomationCenterScreenState();
}

class _AutomationCenterScreenState
    extends State<AutomationCenterScreen> {
  static const String _topicsStorageKey = 'content_topics_v2';

  late final AutomationTaskService _taskService;
  late final AutomationTaskExecutor _executor;

  List<AutomationTask> _tasks = [];

  bool _isLoading = true;
  bool _isProcessing = false;
  bool _isCreatingTask = false;

  String _selectedFilter = 'all';

  String? _errorMessage;
  String? _successMessage;

  @override
  void initState() {
    super.initState();

    _taskService = AutomationTaskService();

    _executor = AutomationTaskExecutor(
      taskService: _taskService,
    );

    _loadTasks();
  }

  @override
  void dispose() {
    _executor.dispose();
    super.dispose();
  }

  Future<void> _loadTasks() async {
    if (mounted) {
      setState(() {
        _isLoading = true;
        _errorMessage = null;
      });
    }

    try {
      final tasks = await _taskService.getAll();

      tasks.sort((a, b) {
        final priorityComparison =
            b.priority.compareTo(a.priority);

        if (priorityComparison != 0) {
          return priorityComparison;
        }

        return b.createdAt.compareTo(a.createdAt);
      });

      if (!mounted) return;

      setState(() {
        _tasks = tasks;
        _isLoading = false;
      });
    } catch (error) {
      if (!mounted) return;

      setState(() {
        _isLoading = false;
        _errorMessage =
            'Não foi possível carregar a fila: $error';
      });
    }
  }

  Future<List<Map<String, dynamic>>> _loadActiveTopics() async {
    final preferences = await SharedPreferences.getInstance();
    final savedData = preferences.getString(_topicsStorageKey);

    if (savedData == null || savedData.isEmpty) {
      return [];
    }

    final decoded = jsonDecode(savedData);

    if (decoded is! List) {
      throw const FormatException(
        'O formato dos temas cadastrados é inválido.',
      );
    }

    final topics = <Map<String, dynamic>>[];

    for (final item in decoded) {
      if (item is! Map) continue;

      final topic = Map<String, dynamic>.from(item);

      final id = topic['id'];
      final name = topic['name'];

      if (id is! String ||
          id.trim().isEmpty ||
          name is! String ||
          name.trim().isEmpty ||
          topic['active'] != true) {
        continue;
      }

      topics.add(topic);
    }

    return topics;
  }

  Future<void> _createTask() async {
    if (_isCreatingTask) return;

    setState(() {
      _isCreatingTask = true;
      _errorMessage = null;
      _successMessage = null;
    });

    try {
      final topics = await _loadActiveTopics();

      if (!mounted) return;

      if (topics.isEmpty) {
        setState(() {
          _errorMessage =
              'Cadastre e ative pelo menos um tema antes de criar uma tarefa.';
        });
        return;
      }

      final promptController = TextEditingController();
      String? selectedTopicId = topics.first['id'] as String;
      int selectedPriority = 0;
      DateTime? scheduledAt;
      String? dialogError;

      final createdTask = await showDialog<AutomationTask>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) {
          return StatefulBuilder(
            builder: (context, setDialogState) {
              final selectedTopic = topics.firstWhere(
                (topic) => topic['id'] == selectedTopicId,
                orElse: () => topics.first,
              );

              Future<void> chooseSchedule() async {
                final now = DateTime.now();

                final initialDate = scheduledAt ?? now;

                final selectedDate = await showDatePicker(
                  context: context,
                  initialDate: initialDate.isBefore(now)
                      ? now
                      : initialDate,
                  firstDate: DateTime(
                    now.year,
                    now.month,
                    now.day,
                  ),
                  lastDate: DateTime(now.year + 5),
                );

                if (selectedDate == null || !context.mounted) {
                  return;
                }

                final selectedTime = await showTimePicker(
                  context: context,
                  initialTime: scheduledAt != null
                      ? TimeOfDay.fromDateTime(scheduledAt!)
                      : TimeOfDay.fromDateTime(now),
                );

                if (selectedTime == null || !context.mounted) {
                  return;
                }

                final newSchedule = DateTime(
                  selectedDate.year,
                  selectedDate.month,
                  selectedDate.day,
                  selectedTime.hour,
                  selectedTime.minute,
                );

                setDialogState(() {
                  scheduledAt = newSchedule;
                  dialogError = null;
                });
              }

              return AlertDialog(
                title: const Text('Nova tarefa'),
                content: SizedBox(
                  width: 480,
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Tema de conteúdo',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 8),
                        DropdownButtonFormField<String>(
                          initialValue: selectedTopicId,
                          isExpanded: true,
                          decoration: const InputDecoration(
                            border: OutlineInputBorder(),
                            prefixIcon: Icon(Icons.topic_outlined),
                          ),
                          items: topics.map((topic) {
                            return DropdownMenuItem<String>(
                              value: topic['id'] as String,
                              child: Text(
                                topic['name'] as String,
                                overflow: TextOverflow.ellipsis,
                              ),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setDialogState(() {
                              selectedTopicId = value;
                              dialogError = null;
                            });
                          },
                        ),
                        if ((selectedTopic['description'] as String?)
                                ?.trim()
                                .isNotEmpty ==
                            true) ...[
                          const SizedBox(height: 8),
                          Text(
                            selectedTopic['description'] as String,
                            style: Theme.of(context)
                                .textTheme
                                .bodySmall,
                          ),
                        ],
                        const SizedBox(height: 20),
                        const Text(
                          'Instruções para a geração',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 8),
                        TextField(
                          controller: promptController,
                          minLines: 4,
                          maxLines: 8,
                          maxLength: 12000,
                          textCapitalization:
                              TextCapitalization.sentences,
                          decoration: const InputDecoration(
                            hintText:
                                'Descreva o conteúdo que deseja gerar...',
                            border: OutlineInputBorder(),
                            alignLabelWithHint: true,
                          ),
                        ),
                        const SizedBox(height: 12),
                        const Text(
                          'Prioridade',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 8),
                        DropdownButtonFormField<int>(
                          initialValue: selectedPriority,
                          decoration: const InputDecoration(
                            border: OutlineInputBorder(),
                            prefixIcon: Icon(Icons.flag_outlined),
                          ),
                          items: const [
                            DropdownMenuItem(
                              value: 0,
                              child: Text('Normal'),
                            ),
                            DropdownMenuItem(
                              value: 1,
                              child: Text('Alta'),
                            ),
                            DropdownMenuItem(
                              value: 2,
                              child: Text('Urgente'),
                            ),
                          ],
                          onChanged: (value) {
                            if (value == null) return;

                            setDialogState(() {
                              selectedPriority = value;
                            });
                          },
                        ),
                        const SizedBox(height: 20),
                        const Text(
                          'Agendamento',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 8),
                        OutlinedButton.icon(
                          onPressed: chooseSchedule,
                          icon: const Icon(Icons.calendar_month),
                          label: Text(
                            scheduledAt == null
                                ? 'Executar imediatamente'
                                : 'Agendada: ${_formatDate(scheduledAt)}',
                          ),
                        ),
                        if (scheduledAt != null) ...[
                          const SizedBox(height: 6),
                          TextButton.icon(
                            onPressed: () {
                              setDialogState(() {
                                scheduledAt = null;
                              });
                            },
                            icon: const Icon(Icons.clear),
                            label: const Text(
                              'Remover agendamento',
                            ),
                          ),
                        ],
                        if (dialogError != null) ...[
                          const SizedBox(height: 12),
                          Text(
                            dialogError!,
                            style: TextStyle(
                              color: Theme.of(context)
                                  .colorScheme
                                  .error,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.of(dialogContext).pop();
                    },
                    child: const Text('Voltar'),
                  ),
                  FilledButton.icon(
                    onPressed: () {
                      final prompt =
                          promptController.text.trim();

                      if (prompt.isEmpty) {
                        setDialogState(() {
                          dialogError =
                              'Digite as instruções para a geração.';
                        });
                        return;
                      }

                      if (prompt.length > 12000) {
                        setDialogState(() {
                          dialogError =
                              'O texto ultrapassa o limite permitido.';
                        });
                        return;
                      }

                      if (scheduledAt != null &&
                          !scheduledAt!.isAfter(DateTime.now())) {
                        setDialogState(() {
                          dialogError =
                              'Escolha uma data e horário futuros.';
                        });
                        return;
                      }

                      final now = DateTime.now();

                      final topicName =
                          selectedTopic['name'] as String;

                      final topicDescription =
                          selectedTopic['description'] as String? ?? '';

                      final task = AutomationTask(
                        id: 'task_${now.microsecondsSinceEpoch}',
                        type: AutomationTaskType.contentGeneration,
                        status: AutomationTaskStatus.pending,
                        priority: selectedPriority,
                        topicId: selectedTopicId,
                        payload: {
                          'prompt': prompt,
                          'topicName': topicName,
                          'topicDescription': topicDescription,
                          'source': 'automation_center',
                        },
                        createdAt: now,
                        updatedAt: now,
                        scheduledAt: scheduledAt,
                      );

                      Navigator.of(dialogContext).pop(task);
                    },
                    icon: const Icon(Icons.add_task),
                    label: const Text('Adicionar à fila'),
                  ),
                ],
              );
            },
          );
        },
      );

      promptController.dispose();

      if (!mounted || createdTask == null) return;

      final saved = await _taskService.add(createdTask);

      if (!mounted) return;

      if (!saved) {
        setState(() {
          _errorMessage =
              'Não foi possível salvar a tarefa. Verifique se o identificador já existe.';
        });
        return;
      }

      setState(() {
        _successMessage = createdTask.scheduledAt == null
            ? 'Tarefa adicionada à fila.'
            : 'Tarefa agendada e adicionada à fila.';
      });

      await _loadTasks();
    } catch (error) {
      if (!mounted) return;

      setState(() {
        _errorMessage =
            'Não foi possível criar a tarefa: $error';
      });
    } finally {
      if (mounted) {
        setState(() {
          _isCreatingTask = false;
        });
      }
    }
  }

  Future<void> _processQueue() async {
    if (_isProcessing) return;

    setState(() {
      _isProcessing = true;
      _errorMessage = null;
      _successMessage = null;
    });

    try {
      final executedCount = await _executor.runBatch(
        limit: 5,
      );

      await _loadTasks();

      if (!mounted) return;

      setState(() {
        _successMessage = executedCount == 0
            ? 'Nenhuma tarefa compatível disponível para execução.'
            : '$executedCount tarefa(s) processada(s).';
      });
    } catch (error) {
      if (!mounted) return;

      setState(() {
        _errorMessage =
            'Erro durante o processamento: $error';
      });
    } finally {
      if (mounted) {
        setState(() {
          _isProcessing = false;
        });
      }
    }
  }

  Future<void> _retryTask(AutomationTask task) async {
    try {
      final success = await _taskService.retry(task.id);

      if (!mounted) return;

      if (success) {
        setState(() {
          _successMessage = 'Tarefa reenviada para a fila.';
          _errorMessage = null;
        });
      } else {
        setState(() {
          _errorMessage =
              'Não foi possível reenviar a tarefa.';
        });
      }

      await _loadTasks();
    } catch (error) {
      if (!mounted) return;

      setState(() {
        _errorMessage = error.toString();
      });
    }
  }

  Future<void> _cancelTask(AutomationTask task) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Cancelar tarefa?'),
          content: const Text(
            'Esta tarefa será marcada como cancelada. '
            'O registro continuará no histórico.',
          ),
          actions: [
            TextButton(
              onPressed: () =>
                  Navigator.pop(context, false),
              child: const Text('Voltar'),
            ),
            FilledButton(
              onPressed: () =>
                  Navigator.pop(context, true),
              child: const Text('Cancelar tarefa'),
            ),
          ],
        );
      },
    );

    if (confirmed != true) return;

    try {
      final success = await _taskService.cancel(task.id);

      if (!mounted) return;

      if (success) {
        setState(() {
          _successMessage = 'Tarefa cancelada.';
          _errorMessage = null;
        });
      } else {
        setState(() {
          _errorMessage =
              'Não foi possível cancelar a tarefa.';
        });
      }

      await _loadTasks();
    } catch (error) {
      if (!mounted) return;

      setState(() {
        _errorMessage = error.toString();
      });
    }
  }

  int _countByStatus(AutomationTaskStatus status) {
    return _tasks
        .where((task) => task.status == status)
        .length;
  }

  List<AutomationTask> get _filteredTasks {
    switch (_selectedFilter) {
      case 'pending':
        return _tasks
            .where((task) =>
                task.status == AutomationTaskStatus.pending)
            .toList();

      case 'running':
        return _tasks
            .where((task) =>
                task.status == AutomationTaskStatus.running)
            .toList();

      case 'completed':
        return _tasks
            .where((task) =>
                task.status == AutomationTaskStatus.completed)
            .toList();

      case 'failed':
        return _tasks
            .where((task) =>
                task.status == AutomationTaskStatus.failed)
            .toList();

      case 'cancelled':
        return _tasks
            .where((task) =>
                task.status == AutomationTaskStatus.cancelled)
            .toList();

      default:
        return _tasks;
    }
  }

  String _statusLabel(AutomationTaskStatus status) {
    switch (status) {
      case AutomationTaskStatus.pending:
        return 'Pendente';
      case AutomationTaskStatus.running:
        return 'Em execução';
      case AutomationTaskStatus.completed:
        return 'Concluída';
      case AutomationTaskStatus.failed:
        return 'Com falha';
      case AutomationTaskStatus.cancelled:
        return 'Cancelada';
    }
  }

  Color _statusColor(AutomationTaskStatus status) {
    switch (status) {
      case AutomationTaskStatus.pending:
        return Colors.orange;
      case AutomationTaskStatus.running:
        return Colors.blue;
      case AutomationTaskStatus.completed:
        return Colors.green;
      case AutomationTaskStatus.failed:
        return Colors.red;
      case AutomationTaskStatus.cancelled:
        return Colors.grey;
    }
  }

  IconData _statusIcon(AutomationTaskStatus status) {
    switch (status) {
      case AutomationTaskStatus.pending:
        return Icons.schedule;
      case AutomationTaskStatus.running:
        return Icons.sync;
      case AutomationTaskStatus.completed:
        return Icons.check_circle_outline;
      case AutomationTaskStatus.failed:
        return Icons.error_outline;
      case AutomationTaskStatus.cancelled:
        return Icons.cancel_outlined;
    }
  }

  String _typeLabel(AutomationTaskType type) {
    switch (type) {
      case AutomationTaskType.contentGeneration:
        return 'Geração de conteúdo';
      case AutomationTaskType.review:
        return 'Revisão';
      case AutomationTaskType.synchronization:
        return 'Sincronização';
      case AutomationTaskType.publication:
        return 'Publicação';
      case AutomationTaskType.metricsCollection:
        return 'Coleta de métricas';
    }
  }

  String _formatDate(DateTime? date) {
    if (date == null) return 'Não informado';

    final local = date.toLocal();

    final day = local.day.toString().padLeft(2, '0');
    final month = local.month.toString().padLeft(2, '0');
    final year = local.year.toString();

    final hour = local.hour.toString().padLeft(2, '0');
    final minute = local.minute.toString().padLeft(2, '0');

    return '$day/$month/$year às $hour:$minute';
  }

  Future<void> _showTaskDetails(AutomationTask task) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) {
        final result = task.payload['result']?.toString();

        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Detalhes da tarefa',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 16),
                  _detailRow('Identificador', task.id),
                  _detailRow('Tipo', _typeLabel(task.type)),
                  _detailRow('Situação', _statusLabel(task.status)),
                  _detailRow('Prioridade', '${task.priority}'),
                  _detailRow(
                    'Tema',
                    task.payload['topicName']?.toString() ??
                        task.topicId ??
                        'Não informado',
                  ),
                  _detailRow(
                    'Tentativas',
                    '${task.attemptCount} de ${task.maxAttempts}',
                  ),
                  _detailRow(
                    'Criada em',
                    _formatDate(task.createdAt),
                  ),
                  _detailRow(
                    'Agendada para',
                    _formatDate(task.scheduledAt),
                  ),
                  _detailRow(
                    'Iniciada em',
                    _formatDate(task.startedAt),
                  ),
                  _detailRow(
                    'Concluída em',
                    _formatDate(task.completedAt),
                  ),
                  _detailRow(
                    'Próxima tentativa',
                    _formatDate(task.nextAttemptAt),
                  ),
                  if (task.lastError != null &&
                      task.lastError!.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    const Text(
                      'Último erro',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 6),
                    SelectableText(task.lastError!),
                  ],
                  if (result != null && result.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    const Text(
                      'Resultado gerado',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 6),
                    SelectableText(result),
                  ],
                  if (task.payload['prompt'] != null) ...[
                    const SizedBox(height: 16),
                    const Text(
                      'Prompt',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 6),
                    SelectableText(
                      task.payload['prompt'].toString(),
                    ),
                  ],
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _detailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 145,
            child: Text(
              label,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Expanded(
            child: SelectableText(value),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryCard(
    String title,
    int count,
    Color color,
    IconData icon,
  ) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color, size: 25),
            const SizedBox(height: 10),
            Text(
              '$count',
              style: Theme.of(context)
                  .textTheme
                  .headlineMedium
                  ?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
            ),
            const SizedBox(height: 4),
            Text(
              title,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummary() {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      childAspectRatio: 1.7,
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      children: [
        _buildSummaryCard(
          'Pendentes',
          _countByStatus(AutomationTaskStatus.pending),
          Colors.orange,
          Icons.schedule,
        ),
        _buildSummaryCard(
          'Em execução',
          _countByStatus(AutomationTaskStatus.running),
          Colors.blue,
          Icons.sync,
        ),
        _buildSummaryCard(
          'Concluídas',
          _countByStatus(AutomationTaskStatus.completed),
          Colors.green,
          Icons.check_circle_outline,
        ),
        _buildSummaryCard(
          'Com falha',
          _countByStatus(AutomationTaskStatus.failed),
          Colors.red,
          Icons.error_outline,
        ),
      ],
    );
  }

  Widget _buildFilters() {
    final filters = <String, String>{
      'all': 'Todas',
      'pending': 'Pendentes',
      'running': 'Em execução',
      'completed': 'Concluídas',
      'failed': 'Falhas',
      'cancelled': 'Canceladas',
    };

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: filters.entries.map((entry) {
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: ChoiceChip(
              label: Text(entry.value),
              selected: _selectedFilter == entry.key,
              onSelected: (_) {
                setState(() {
                  _selectedFilter = entry.key;
                });
              },
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildTaskCard(AutomationTask task) {
    final color = _statusColor(task.status);

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => _showTaskDetails(task),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(
                    _statusIcon(task.status),
                    color: color,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _typeLabel(task.type),
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 9,
                      vertical: 5,
                    ),
                    decoration: BoxDecoration(
                      color: color.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      _statusLabel(task.status),
                      style: TextStyle(
                        color: color,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              if (task.payload['topicName'] != null) ...[
                Text(
                  'Tema: ${task.payload['topicName']}',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 5),
              ],
              Text(
                'Criada em ${_formatDate(task.createdAt)}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              if (task.scheduledAt != null) ...[
                const SizedBox(height: 5),
                Text(
                  'Agendada para ${_formatDate(task.scheduledAt)}',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
              const SizedBox(height: 5),
              Text(
                'Tentativas: ${task.attemptCount}/${task.maxAttempts}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              if (task.lastError != null &&
                  task.lastError!.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(
                  task.lastError!,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.error,
                    fontSize: 12,
                  ),
                ),
              ],
              const SizedBox(height: 8),
              Row(
                children: [
                  TextButton.icon(
                    onPressed: () => _showTaskDetails(task),
                    icon: const Icon(Icons.visibility_outlined),
                    label: const Text('Detalhes'),
                  ),
                  const Spacer(),
                  if (task.status == AutomationTaskStatus.failed &&
                      task.canRetry)
                    IconButton(
                      tooltip: 'Tentar novamente',
                      onPressed: () => _retryTask(task),
                      icon: const Icon(Icons.refresh),
                    ),
                  if (!task.isTerminal)
                    IconButton(
                      tooltip: 'Cancelar tarefa',
                      onPressed: () => _cancelTask(task),
                      icon: const Icon(Icons.cancel_outlined),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTaskList() {
    final tasks = _filteredTasks;

    if (tasks.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 35),
        child: Center(
          child: Column(
            children: [
              Icon(
                Icons.inbox_outlined,
                size: 45,
                color: Colors.grey,
              ),
              SizedBox(height: 10),
              Text('Nenhuma tarefa encontrada.'),
            ],
          ),
        ),
      );
    }

    return Column(
      children: tasks.map(_buildTaskCard).toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Central de Automações'),
        actions: [
          IconButton(
            tooltip: 'Atualizar fila',
            onPressed: _isLoading ? null : _loadTasks,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadTasks,
        child: _isLoading
            ? ListView(
                children: const [
                  SizedBox(height: 250),
                  Center(
                    child: CircularProgressIndicator(),
                  ),
                ],
              )
            : ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Text(
                    'Acompanhamento da fila',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Consulte tarefas, acompanhe resultados e '
                    'gerencie novas tentativas.',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 18),
                  _buildSummary(),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: _isCreatingTask
                          ? null
                          : _createTask,
                      icon: _isCreatingTask
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                              ),
                            )
                          : const Icon(Icons.add_task),
                      label: Text(
                        _isCreatingTask
                            ? 'Preparando formulário...'
                            : 'Nova tarefa',
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed:
                          _isProcessing ? null : _processQueue,
                      icon: _isProcessing
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                              ),
                            )
                          : const Icon(Icons.play_arrow),
                      label: Text(
                        _isProcessing
                            ? 'Processando fila...'
                            : 'Processar até 5 tarefas',
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'O executor atual processa tarefas de geração '
                    'de conteúdo. Outros tipos aguardam seus '
                    'respectivos processadores.',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  if (_successMessage != null) ...[
                    const SizedBox(height: 12),
                    Text(
                      _successMessage!,
                      style: TextStyle(
                        color: Colors.green.shade700,
                      ),
                    ),
                  ],
                  if (_errorMessage != null) ...[
                    const SizedBox(height: 12),
                    Text(
                      _errorMessage!,
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.error,
                      ),
                    ),
                  ],
                  const SizedBox(height: 24),
                  Text(
                    'Tarefas',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 12),
                  _buildFilters(),
                  const SizedBox(height: 12),
                  _buildTaskList(),
                ],
              ),
      ),
    );
  }
}