
import 'dart:convert';

import 'package:http/http.dart' as http;

class ApiProviderConnectionTest {
  ApiProviderConnectionTest({http.Client? client})
      : _client = client ?? http.Client();

  final http.Client _client;

  Future<String?> testGemini(String apiKey) async {
    final key = apiKey.trim();

    if (key.isEmpty) {
      return 'Informe a chave da API.';
    }

    try {
      final uri = Uri.parse(
        'https://generativelanguage.googleapis.com/v1beta/models/'
        'gemini-3.1-flash-lite:generateContent',
      );

      final response = await _client.post(
        uri,
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': key,
        },
        body: jsonEncode({
          'contents': [
            {
              'parts': [
                {
                  'text': 'Responda apenas: conexão funcionando.'
                }
              ]
            }
          ],
          'generationConfig': {
            'maxOutputTokens': 30,
          },
        }),
      );

      if (response.statusCode == 200) {
        return null;
      }

      if (response.statusCode == 400 ||
          response.statusCode == 401 ||
          response.statusCode == 403) {
        return 'A chave foi recusada. Confira a credencial e as permissões.';
      }

      if (response.statusCode == 404) {
        return 'Modelo não encontrado ou indisponível para esta API.';
      }

      if (response.statusCode == 429) {
        return 'Limite de requisições atingido. Tente novamente mais tarde.';
      }

      return 'Falha no teste. Código HTTP: ${response.statusCode}.';
    } catch (_) {
      return 'Não foi possível conectar. Verifique sua internet.';
    }
  }

  void dispose() {
    _client.close();
  }
}
