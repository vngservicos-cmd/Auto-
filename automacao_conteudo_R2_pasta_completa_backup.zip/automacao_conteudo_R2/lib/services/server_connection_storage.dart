
import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:automacao_conteudo/models/server_connection.dart';

class ServerConnectionStorage {
  ServerConnectionStorage({
    FlutterSecureStorage? secureStorage,
  }) : _secureStorage = secureStorage ?? const FlutterSecureStorage();

  static const String _serversKey = 'server_connections_v1';
  static const String _activeServerKey = 'active_server_connection_v1';
  static const String _tokenPrefix = 'server_access_token_';

  final FlutterSecureStorage _secureStorage;

  Future<List<ServerConnection>> getAll() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_serversKey);

    if (raw == null || raw.isEmpty) {
      return [];
    }

    try {
      final decoded = jsonDecode(raw);

      if (decoded is! List) {
        throw const FormatException('Formato inválido dos servidores.');
      }

      final servers = decoded
          .map(
            (item) => ServerConnection.fromJson(
              Map<String, dynamic>.from(item as Map),
            ),
          )
          .toList();

      servers.sort((a, b) => a.createdAt.compareTo(b.createdAt));

      return servers;
    } catch (_) {
      throw Exception(
        'Não foi possível ler os servidores salvos. '
        'Os dados foram preservados para análise.',
      );
    }
  }

  Future<ServerConnection?> getById(String id) async {
    final servers = await getAll();

    for (final server in servers) {
      if (server.id == id) return server;
    }

    return null;
  }

  Future<ServerConnection?> getActive() async {
    final prefs = await SharedPreferences.getInstance();
    final activeId = prefs.getString(_activeServerKey);

    if (activeId == null) return null;

    final server = await getById(activeId);

    if (server == null || !server.active) return null;

    return server;
  }

  Future<void> add(ServerConnection server, String token) async {
    final normalizedToken = token.trim();

    if (normalizedToken.isEmpty) {
      throw ArgumentError('O token do servidor não pode estar vazio.');
    }

    final servers = await getAll();

    if (servers.any((item) => item.id == server.id)) {
      throw ArgumentError('Já existe um servidor com esse identificador.');
    }

    final prefs = await SharedPreferences.getInstance();

    final updatedServers = [...servers, server]
      ..sort((a, b) => a.createdAt.compareTo(b.createdAt));

    await _secureStorage.write(
      key: '$_tokenPrefix${server.id}',
      value: normalizedToken,
    );

    try {
      await _saveServers(prefs, updatedServers);

      if (server.active) {
        await prefs.setString(_activeServerKey, server.id);
      }
    } catch (_) {
      await _secureStorage.delete(key: '$_tokenPrefix${server.id}');
      rethrow;
    }
  }

  Future<void> update(ServerConnection updatedServer) async {
    final servers = await getAll();
    final index = servers.indexWhere(
      (item) => item.id == updatedServer.id,
    );

    if (index == -1) {
      throw ArgumentError('Servidor não encontrado.');
    }

    final prefs = await SharedPreferences.getInstance();
    final updatedServers = [...servers];

    updatedServers[index] = updatedServer;

    await _saveServers(prefs, updatedServers);

    if (!updatedServer.active) {
      final activeId = prefs.getString(_activeServerKey);

      if (activeId == updatedServer.id) {
        await prefs.remove(_activeServerKey);
      }
    }
  }

  Future<void> saveToken(String serverId, String token) async {
    final normalizedToken = token.trim();

    if (normalizedToken.isEmpty) {
      throw ArgumentError('O token não pode estar vazio.');
    }

    final server = await getById(serverId);

    if (server == null) {
      throw ArgumentError('Servidor não encontrado.');
    }

    await _secureStorage.write(
      key: '$_tokenPrefix$serverId',
      value: normalizedToken,
    );
  }

  Future<String?> readToken(String serverId) async {
    return _secureStorage.read(key: '$_tokenPrefix$serverId');
  }

  Future<bool> hasToken(String serverId) async {
    final token = await readToken(serverId);
    return token != null && token.isNotEmpty;
  }

  Future<void> deleteToken(String serverId) async {
    await _secureStorage.delete(key: '$_tokenPrefix$serverId');
  }

  Future<void> setActive(String serverId) async {
    final server = await getById(serverId);

    if (server == null) {
      throw ArgumentError('Servidor não encontrado.');
    }

    if (!server.active) {
      throw StateError(
        'Não é possível selecionar um servidor desativado.',
      );
    }

    final prefs = await SharedPreferences.getInstance();

    await prefs.setString(_activeServerKey, serverId);
  }

  Future<void> remove(String serverId) async {
    final servers = await getAll();

    final updatedServers = servers
        .where((server) => server.id != serverId)
        .toList();

    if (updatedServers.length == servers.length) {
      throw ArgumentError('Servidor não encontrado.');
    }

    final prefs = await SharedPreferences.getInstance();

    await _saveServers(prefs, updatedServers);

    final activeId = prefs.getString(_activeServerKey);

    if (activeId == serverId) {
      await prefs.remove(_activeServerKey);
    }

    await deleteToken(serverId);
  }

  Future<void> _saveServers(
    SharedPreferences prefs,
    List<ServerConnection> servers,
  ) async {
    final encoded = jsonEncode(
      servers.map((server) => server.toJson()).toList(),
    );

    final saved = await prefs.setString(_serversKey, encoded);

    if (!saved) {
      throw Exception('Não foi possível salvar os servidores.');
    }
  }
}
