
import '../models/api_provider.dart';
import 'api_provider_registry.dart';
import 'api_provider_remote_service.dart';
import 'api_provider_sync_queue.dart';

class ApiProviderSyncService {
  ApiProviderSyncService({
    ApiProviderRegistry? registry,
    ApiProviderRemoteService? remoteService,
    ApiProviderSyncQueue? syncQueue,
  })  : _registry = registry ?? ApiProviderRegistry(),
        _remoteService = remoteService ?? ApiProviderRemoteService(),
        _syncQueue = syncQueue ?? ApiProviderSyncQueue();

  final ApiProviderRegistry _registry;
  final ApiProviderRemoteService _remoteService;
  final ApiProviderSyncQueue _syncQueue;

  bool _isSyncing = false;

  Future<int> synchronize() async {
    if (_isSyncing) {
      return 0;
    }

    _isSyncing = true;
    var synchronizedCount = 0;

    try {
      final pendingItems = await _syncQueue.getAll();
      final localProviders = await _registry.getAll();

      for (final item in pendingItems) {
        try {
          switch (item.operation) {
            case SyncOperation.create:
              final provider = _findProvider(localProviders, item.id);

              if (provider == null) {
                throw Exception(
                  'Cadastro ${item.id} não encontrado localmente.',
                );
              }

              await _remoteService.add(provider);
              break;

            case SyncOperation.update:
              final provider = _findProvider(localProviders, item.id);

              if (provider == null) {
                throw Exception(
                  'Cadastro ${item.id} não encontrado localmente.',
                );
              }

              await _remoteService.update(provider);
              break;

            case SyncOperation.delete:
              await _remoteService.remove(item.id);
              break;
          }

          final removed = await _syncQueue.remove(item.id);

          if (!removed) {
            throw Exception(
              'Não foi possível confirmar a remoção da fila.',
            );
          }

          synchronizedCount++;
        } catch (_) {
          // Mantém a operação pendente para uma próxima tentativa.
          // Interrompe para preservar a ordem das operações.
          break;
        }
      }

      return synchronizedCount;
    } finally {
      _isSyncing = false;
    }
  }

  ApiProvider? _findProvider(
    List<ApiProvider> providers,
    String id,
  ) {
    for (final provider in providers) {
      if (provider.id == id) {
        return provider;
      }
    }

    return null;
  }

  void dispose() {
    _remoteService.dispose();
  }
}
