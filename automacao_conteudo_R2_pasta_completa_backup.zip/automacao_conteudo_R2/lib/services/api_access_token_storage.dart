import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Armazenamento seguro do token legado do Worker Cloudflare.
/// Tokens de servidores cadastrados individualmente ficam em
/// ServerConnectionStorage; esta classe mantém somente compatibilidade.
class ApiAccessTokenStorage {
  ApiAccessTokenStorage({FlutterSecureStorage? secureStorage})
      : _secureStorage = secureStorage ?? const FlutterSecureStorage();

  static const String _legacyTokenKey = 'api_access_token';

  final FlutterSecureStorage _secureStorage;

  Future<void> saveToken(String token) async {
    final value = token.trim();
    if (value.isEmpty) {
      throw ArgumentError.value(token, 'token', 'Não pode ser vazio.');
    }
    await _secureStorage.write(key: _legacyTokenKey, value: value);
  }

  Future<String?> readToken() {
    return _secureStorage.read(key: _legacyTokenKey);
  }

  Future<void> deleteToken() {
    return _secureStorage.delete(key: _legacyTokenKey);
  }
}
