
import 'dart:async';
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/post_schedule.dart';

class PostScheduleService {
  static const String _storageKey = 'post_schedules_v1';

  // Serializa operações para evitar que gravações simultâneas
  // sobrescrevam alterações umas das outras.
  Future<void> _operationQueue = Future<void>.value();

  Future<T> _runExclusive<T>(Future<T> Function() operation) async {
    final previousOperation = _operationQueue;
    final completer = Completer<void>();

    _operationQueue = completer.future;

    try {
      await previousOperation;
      return await operation();
    } finally {
      completer.complete();
    }
  }

  Future<List<PostSchedule>> getAll() {
    return _runExclusive(_getAllInternal);
  }

  Future<List<PostSchedule>> _getAllInternal() async {
    final prefs = await SharedPreferences.getInstance();
    final storedData = prefs.getString(_storageKey);

    if (storedData == null || storedData.isEmpty) {
      return [];
    }

    final dynamic decoded;

    try {
      decoded = jsonDecode(storedData);
    } catch (_) {
      throw const FormatException(
        'Não foi possível interpretar os dados das postagens. '
        'Os registros originais foram preservados.',
      );
    }

    if (decoded is! List) {
      throw const FormatException(
        'O formato dos dados de postagens é inválido. '
        'Os registros originais foram preservados.',
      );
    }

    final schedules = <PostSchedule>[];
    final ids = <String>{};

    for (final item in decoded) {
      if (item is! Map) {
        throw const FormatException(
          'Foi encontrado um registro de postagem inválido. '
          'Os dados originais foram preservados.',
        );
      }

      try {
        final map = Map<String, dynamic>.from(item);
        final schedule = PostSchedule.fromJson(map);

        _validateSchedule(schedule);

        if (!ids.add(schedule.id)) {
          throw const FormatException(
            'Foram encontrados identificadores duplicados '
            'nas postagens. Os dados originais foram preservados.',
          );
        }

        schedules.add(schedule);
      } on FormatException {
        rethrow;
      } catch (_) {
        throw const FormatException(
          'Não foi possível recuperar um registro de postagem. '
          'Os dados originais foram preservados.',
        );
      }
    }

    return schedules;
  }

  Future<bool> saveAll(List<PostSchedule> schedules) {
    return _runExclusive(() => _saveAllInternal(schedules));
  }

  Future<bool> _saveAllInternal(List<PostSchedule> schedules) async {
    _validateCollection(schedules);

    final prefs = await SharedPreferences.getInstance();

    final encoded = jsonEncode(
      schedules.map((schedule) => schedule.toJson()).toList(),
    );

    return prefs.setString(_storageKey, encoded);
  }

  Future<bool> add(PostSchedule schedule) {
    return _runExclusive(() async {
      _validateSchedule(schedule);

      final schedules = await _getAllInternal();

      if (schedules.any((item) => item.id == schedule.id)) {
        return false;
      }

      schedules.add(schedule);

      return _saveAllInternal(schedules);
    });
  }

  Future<int> addMany(List<PostSchedule> newSchedules) {
    return _runExclusive(() async {
      _validateCollection(newSchedules);

      final schedules = await _getAllInternal();
      final existingIds = schedules.map((item) => item.id).toSet();

      for (final schedule in newSchedules) {
        if (!existingIds.add(schedule.id)) {
          throw const FormatException(
            'Uma ou mais postagens já possuem identificadores '
            'cadastrados. Nenhum registro foi alterado.',
          );
        }
      }

      schedules.addAll(newSchedules);

      final saved = await _saveAllInternal(schedules);
      return saved ? newSchedules.length : 0;
    });
  }

  Future<bool> update(PostSchedule schedule) {
    return _runExclusive(() async {
      _validateSchedule(schedule);

      final schedules = await _getAllInternal();

      final index = schedules.indexWhere(
        (item) => item.id == schedule.id,
      );

      if (index == -1) {
        return false;
      }

      schedules[index] = schedule;

      return _saveAllInternal(schedules);
    });
  }

  Future<bool> upsert(PostSchedule schedule) {
    return _runExclusive(() async {
      _validateSchedule(schedule);

      final schedules = await _getAllInternal();

      final index = schedules.indexWhere(
        (item) => item.id == schedule.id,
      );

      if (index == -1) {
        schedules.add(schedule);
      } else {
        schedules[index] = schedule;
      }

      return _saveAllInternal(schedules);
    });
  }

  Future<bool> remove(String id) {
    return _runExclusive(() async {
      if (id.trim().isEmpty) {
        return false;
      }

      final schedules = await _getAllInternal();
      final originalLength = schedules.length;

      schedules.removeWhere((item) => item.id == id);

      if (schedules.length == originalLength) {
        return false;
      }

      return _saveAllInternal(schedules);
    });
  }

  Future<int> removeMany(List<String> ids) {
    return _runExclusive(() async {
      final validIds = ids.where((id) => id.trim().isNotEmpty).toSet();

      if (validIds.isEmpty) {
        return 0;
      }

      final schedules = await _getAllInternal();
      final originalLength = schedules.length;

      schedules.removeWhere((item) => validIds.contains(item.id));

      final removedCount = originalLength - schedules.length;

      if (removedCount == 0) {
        return 0;
      }

      final saved = await _saveAllInternal(schedules);
      return saved ? removedCount : 0;
    });
  }

  Future<PostSchedule?> getById(String id) async {
    if (id.trim().isEmpty) {
      return null;
    }

    final schedules = await getAll();

    for (final schedule in schedules) {
      if (schedule.id == id) {
        return schedule;
      }
    }

    return null;
  }

  Future<List<PostSchedule>> getByTopic(String topicId) {
    return _filter((item) => item.topicId == topicId);
  }

  Future<List<PostSchedule>> getByAccount(String accountId) {
    return _filter((item) => item.accountId == accountId);
  }

  Future<List<PostSchedule>> getByCampaign(String campaignId) {
    return _filter((item) => item.campaignId == campaignId);
  }

  Future<List<PostSchedule>> getByNetwork(String network) {
    return _filter(
      (item) => item.network.toLowerCase() == network.toLowerCase(),
    );
  }

  Future<List<PostSchedule>> getByStatus(String status) {
    return _filter(
      (item) => item.status.toLowerCase() == status.toLowerCase(),
    );
  }

  Future<List<PostSchedule>> getPendingApproval() {
    return _filter(
      (item) => item.approvalStatus.toLowerCase() == 'pendente',
    );
  }

  Future<List<PostSchedule>> getScheduled() {
    return _filter(
      (item) =>
          item.scheduledAt != null &&
          item.scheduleStatus.toLowerCase() == 'agendado',
    );
  }

  Future<List<PostSchedule>> getPublished() {
    return _filter(
      (item) =>
          item.publishedAt != null ||
          item.scheduleStatus.toLowerCase() == 'publicado',
    );
  }

  Future<List<PostSchedule>> _filter(
    bool Function(PostSchedule item) predicate,
  ) async {
    final schedules = await getAll();
    return schedules.where(predicate).toList();
  }

  Future<bool> recordAttempt({
    required String id,
    String? error,
  }) {
    return _runExclusive(() async {
      final schedules = await _getAllInternal();

      final index = schedules.indexWhere((item) => item.id == id);

      if (index == -1) {
        return false;
      }

      final current = schedules[index];

      schedules[index] = current.copyWith(
        lastAttemptAt: DateTime.now(),
        attemptCount: current.attemptCount + 1,
        lastError: error,
      );

      return _saveAllInternal(schedules);
    });
  }

  Future<bool> clearAttemptError(String id) {
    return _runExclusive(() async {
      final schedules = await _getAllInternal();

      final index = schedules.indexWhere((item) => item.id == id);

      if (index == -1) {
        return false;
      }

      schedules[index] = schedules[index].copyWith(
        lastError: null,
      );

      return _saveAllInternal(schedules);
    });
  }

  Future<int> count() async {
    final schedules = await getAll();
    return schedules.length;
  }

  Future<bool> exists(String id) async {
    return await getById(id) != null;
  }

  void _validateSchedule(PostSchedule schedule) {
    if (schedule.id.trim().isEmpty) {
      throw const FormatException(
        'A postagem precisa ter um identificador permanente.',
      );
    }

    if (schedule.network.trim().isEmpty) {
      throw const FormatException(
        'A postagem precisa informar a rede social de destino.',
      );
    }

    if (schedule.attemptCount < 0) {
      throw const FormatException(
        'A quantidade de tentativas não pode ser negativa.',
      );
    }

    if (schedule.version < 1) {
      throw const FormatException(
        'A versão do registro precisa ser maior que zero.',
      );
    }
  }

  void _validateCollection(List<PostSchedule> schedules) {
    final ids = <String>{};

    for (final schedule in schedules) {
      _validateSchedule(schedule);

      if (!ids.add(schedule.id)) {
        throw const FormatException(
          'A lista contém identificadores de postagem duplicados.',
        );
      }
    }
  }
}
