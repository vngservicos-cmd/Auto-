
import 'dart:convert';

import '../models/api_provider.dart';
import 'api_provider_registry.dart';
import 'api_provider_remote_service.dart';
import 'api_provider_sync_queue.dart';

class ApiProviderSyncService {
  ApiProviderSyncService({
    ApiProviderRegistry? registry,
    ApiProviderRemoteService? remoteService,
    ApiProviderSyncQueue? syncQueue,
  })  : _registry = registry ?? ApiProviderRegistry(),
        _remoteService = remoteService ?? ApiProviderRemoteService(),
        _syncQueue = syncQueue ?? ApiProviderSyncQueue();

  final ApiProviderRegistry _registry;
  final ApiProviderRemoteService _remoteService;
  final ApiProviderSyncQueue _syncQueue;

  bool _isSyncing = false;

  Future<int> synchronize() async {
    if (_isSyncing) {
      return 0;
    }

    _isSyncing = true;
    var synchronizedCount = 0;

    try {
      final pendingItems = await _syncQueue.getAll();
      final localProviders = await _registry.getAll();
      var remoteProviders = await _remoteService.getAll();

      for (final item in pendingItems) {
        try {
          final localProvider = _findProvider(
            localProviders,
            item.id,
          );

          var completed = false;

          switch (item.operation) {
            case SyncOperation.create:
              if (localProvider == null) {
                throw Exception(
                  'Cadastro ${item.id} não encontrado localmente.',
                );
              }

              final remoteProvider = _findProvider(
                remoteProviders,
                item.id,
              );

              if (remoteProvider != null) {
                if (!_sameProviderData(
                  localProvider,
                  remoteProvider,
                )) {
                  throw Exception(
                    'Conflito: o cadastro remoto possui dados diferentes.',
                  );
                }

                completed = true;
              } else {
                try {
                  await _remoteService.add(localProvider);
                  completed = true;
                } on ApiProviderRemoteException catch (error) {
                  if (error.statusCode != 409) {
                    rethrow;
                  }

                  remoteProviders = await _remoteService.getAll();

                  final confirmedProvider = _findProvider(
                    remoteProviders,
                    item.id,
                  );

                  if (confirmedProvider == null ||
                      !_sameProviderData(
                        localProvider,
                        confirmedProvider,
                      )) {
                    rethrow;
                  }

                  completed = true;
                }
              }
              break;

            case SyncOperation.update:
              if (localProvider == null) {
                throw Exception(
                  'Cadastro ${item.id} não encontrado localmente.',
                );
              }

              var remoteProvider = _findProvider(
                remoteProviders,
                item.id,
              );

              if (remoteProvider == null) {
                try {
                  await _remoteService.add(localProvider);
                  completed = true;
                } on ApiProviderRemoteException catch (error) {
                  if (error.statusCode != 409) {
                    rethrow;
                  }

                  remoteProviders = await _remoteService.getAll();

                  remoteProvider = _findProvider(
                    remoteProviders,
                    item.id,
                  );

                  if (remoteProvider == null) {
                    rethrow;
                  }

                  if (_sameProviderData(
                    localProvider,
                    remoteProvider,
                  )) {
                    completed = true;
                  } else {
                    await _remoteService.update(localProvider);
                    completed = true;
                  }
                }
              } else if (_sameProviderData(
                localProvider,
                remoteProvider,
              )) {
                completed = true;
              } else {
                await _remoteService.update(localProvider);
                completed = true;
              }
              break;

            case SyncOperation.delete:
              final remoteProvider = _findProvider(
                remoteProviders,
                item.id,
              );

              if (remoteProvider == null) {
                completed = true;
              } else {
                try {
                  await _remoteService.remove(item.id);
                  completed = true;
                } on ApiProviderRemoteException catch (error) {
                  if (error.statusCode != 404) {
                    rethrow;
                  }

                  remoteProviders = await _remoteService.getAll();

                  completed = _findProvider(
                        remoteProviders,
                        item.id,
                      ) ==
                      null;
                }
              }
              break;
          }

          if (!completed) {
            break;
          }

          final removed = await _syncQueue.remove(item.id);

          if (!removed) {
            throw Exception(
              'Não foi possível confirmar a remoção da fila.',
            );
          }

          synchronizedCount++;

          remoteProviders = await _remoteService.getAll();
        } catch (_) {
          // Mantém a operação pendente.
          // Interrompe para preservar a ordem da fila.
          break;
        }
      }

      return synchronizedCount;
    } finally {
      _isSyncing = false;
    }
  }

  ApiProvider? _findProvider(
    List<ApiProvider> providers,
    String id,
  ) {
    for (final provider in providers) {
      if (provider.id == id) {
        return provider;
      }
    }

    return null;
  }

  // Compara somente os campos sincronizados com o servidor.
  // modelId permanece local e não participa da comparação.
  bool _sameProviderData(
    ApiProvider first,
    ApiProvider second,
  ) {
    final firstData = _remoteComparableData(first);
    final secondData = _remoteComparableData(second);

    return jsonEncode(firstData) == jsonEncode(secondData);
  }

  Map<String, dynamic> _remoteComparableData(
    ApiProvider provider,
  ) {
    return {
      'id': provider.id,
      'name': provider.name,
      'provider': provider.provider,
      'capability': provider.capability,
      'connectionType': provider.connectionType,
      'active': provider.active,
      'isFree': provider.isFree,
      'hasFreeTrial': provider.hasFreeTrial,
      'priority': provider.priority,
      'trialDays': provider.trialDays,
      'trialEndsAt': provider.trialEndsAt?.toIso8601String(),
      'quotaRenewsAt': provider.quotaRenewsAt?.toIso8601String(),
      'websiteUrl': provider.websiteUrl,
      'notes': provider.notes,
      'createdAt': provider.createdAt.toIso8601String(),
    };
  }

  void dispose() {
    _remoteService.dispose();
  }
}
