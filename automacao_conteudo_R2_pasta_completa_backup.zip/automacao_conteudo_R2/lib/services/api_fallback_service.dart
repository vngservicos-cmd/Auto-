
import '../models/api_provider.dart';

enum ApiFallbackAction {
  useFreeAlternative,
  requestPaidAuthorization,
  noAlternativeAvailable,
}

class ApiFallbackDecision {
  final ApiFallbackAction action;
  final ApiProvider? provider;
  final String message;

  const ApiFallbackDecision({
    required this.action,
    required this.message,
    this.provider,
  });
}

class ApiFallbackService {
  /// Prioridade 1 é a mais alta.
  ///
  /// Só considera serviços ativos e do mesmo tipo.
  /// A API que falhou não pode ser escolhida novamente.
  ApiFallbackDecision chooseAlternative({
    required List<ApiProvider> providers,
    required ApiProvider failedProvider,
  }) {
    final alternatives = providers
        .where(
          (provider) =>
              provider.id != failedProvider.id &&
              provider.active &&
              provider.capability == failedProvider.capability,
        )
        .toList()
      ..sort((a, b) {
        final priorityComparison =
            a.priority.compareTo(b.priority);

        if (priorityComparison != 0) {
          return priorityComparison;
        }

        return a.name.toLowerCase().compareTo(
              b.name.toLowerCase(),
            );
      });

    if (alternatives.isEmpty) {
      return const ApiFallbackDecision(
        action: ApiFallbackAction.noAlternativeAvailable,
        message:
            'Não há outra API ativa cadastrada para este tipo de serviço.',
      );
    }

    // Primeiro, procura uma alternativa gratuita.
    final freeAlternatives = alternatives
        .where((provider) => provider.isFree)
        .toList();

    if (freeAlternatives.isNotEmpty) {
      return ApiFallbackDecision(
        action: ApiFallbackAction.useFreeAlternative,
        provider: freeAlternatives.first,
        message:
            'Alternativa gratuita encontrada. '
            'Ela está selecionada, mas ainda não foi chamada.',
      );
    }

    // Se não houver alternativa gratuita, pede autorização
    // para a alternativa paga de maior prioridade.
    return ApiFallbackDecision(
      action: ApiFallbackAction.requestPaidAuthorization,
      provider: alternatives.first,
      message:
          'A alternativa disponível é paga. '
          'É necessária autorização antes de usá-la.',
    );
  }
}
