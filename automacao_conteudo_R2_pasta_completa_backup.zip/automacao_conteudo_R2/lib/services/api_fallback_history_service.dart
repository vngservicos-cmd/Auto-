
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/api_fallback_event.dart';

class ApiFallbackHistoryService {
  static const String _storageKey = 'api_fallback_history_v1';

  Future<List<ApiFallbackEvent>> getAll() async {
    final prefs = await SharedPreferences.getInstance();
    final storedData = prefs.getString(_storageKey);

    if (storedData == null || storedData.isEmpty) {
      return [];
    }

    try {
      final decoded = jsonDecode(storedData);

      if (decoded is! List) {
        return [];
      }

      final events = decoded
          .whereType<Map>()
          .map(
            (item) => ApiFallbackEvent.fromJson(
              Map<String, dynamic>.from(item),
            ),
          )
          .toList();

      events.sort(
        (a, b) => b.occurredAt.compareTo(a.occurredAt),
      );

      return events;
    } catch (_) {
      return [];
    }
  }

  Future<bool> add(ApiFallbackEvent event) async {
    final events = await getAll();

    events.insert(0, event);

    // Limita o histórico aos 500 registros mais recentes.
    if (events.length > 500) {
      events.removeRange(500, events.length);
    }

    return saveAll(events);
  }

  Future<bool> saveAll(List<ApiFallbackEvent> events) async {
    final prefs = await SharedPreferences.getInstance();

    final encoded = jsonEncode(
      events.map((event) => event.toJson()).toList(),
    );

    return prefs.setString(_storageKey, encoded);
  }

  Future<bool> clear() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.remove(_storageKey);
  }
}
