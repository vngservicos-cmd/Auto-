import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

enum SyncOperation {
  create,
  update,
  delete,
}

class SyncQueueItem {
  final String id;
  final SyncOperation operation;
  final DateTime createdAt;

  const SyncQueueItem({
    required this.id,
    required this.operation,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'operation': operation.name,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory SyncQueueItem.fromJson(Map<String, dynamic> json) {
    return SyncQueueItem(
      id: json['id'] as String,
      operation: SyncOperation.values.firstWhere(
        (value) => value.name == json['operation'],
      ),
      createdAt: DateTime.parse(json['createdAt'] as String),
    );
  }
}

class ApiProviderSyncQueue {
  static const String _storageKey = 'api_provider_sync_queue_v1';

  Future<List<SyncQueueItem>> getAll() async {
    final prefs = await SharedPreferences.getInstance();
    final storedData = prefs.getString(_storageKey);

    if (storedData == null || storedData.isEmpty) {
      return [];
    }

    try {
      final decoded = jsonDecode(storedData);

      if (decoded is! List) {
        return [];
      }

      return decoded
          .whereType<Map>()
          .map(
            (item) => SyncQueueItem.fromJson(
              Map<String, dynamic>.from(item),
            ),
          )
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<bool> saveAll(List<SyncQueueItem> items) async {
    final prefs = await SharedPreferences.getInstance();

    final encoded = jsonEncode(
      items.map((item) => item.toJson()).toList(),
    );

    return prefs.setString(_storageKey, encoded);
  }

  Future<bool> recordCreate(String id) async {
    final items = await getAll();

    items.removeWhere((item) => item.id == id);

    items.add(
      SyncQueueItem(
        id: id,
        operation: SyncOperation.create,
        createdAt: DateTime.now().toUtc(),
      ),
    );

    return saveAll(items);
  }

  Future<bool> recordUpdate(String id) async {
    final items = await getAll();

    final existingIndex = items.indexWhere(
      (item) => item.id == id,
    );

    if (existingIndex != -1 &&
        items[existingIndex].operation == SyncOperation.create) {
      return true;
    }

    items.removeWhere((item) => item.id == id);

    items.add(
      SyncQueueItem(
        id: id,
        operation: SyncOperation.update,
        createdAt: DateTime.now().toUtc(),
      ),
    );

    return saveAll(items);
  }

  Future<bool> recordDelete(String id) async {
    final items = await getAll();

    final existing = items.where((item) => item.id == id).firstOrNull;

    items.removeWhere((item) => item.id == id);

    // Se foi criado localmente e ainda não enviado,
    // não há necessidade de enviar uma exclusão ao servidor.
    if (existing?.operation == SyncOperation.create) {
      return saveAll(items);
    }

    items.add(
      SyncQueueItem(
        id: id,
        operation: SyncOperation.delete,
        createdAt: DateTime.now().toUtc(),
      ),
    );

    return saveAll(items);
  }

  Future<bool> remove(String id) async {
    final items = await getAll();
    final originalLength = items.length;

    items.removeWhere((item) => item.id == id);

    if (items.length == originalLength) {
      return false;
    }

    return saveAll(items);
  }

  Future<bool> clear() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.remove(_storageKey);
  }
}