import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Guarda credenciais por conta da Central de APIs.
/// Os segredos permanecem no armazenamento seguro do dispositivo/navegador
/// e nunca são incluídos no registro sincronizado do provedor.
class ApiProviderCredentialsStorage {
  ApiProviderCredentialsStorage()
      : _storage = const FlutterSecureStorage();

  // Prefixo histórico preservado para não invalidar as credenciais já salvas.
  static const String _keyPrefix = 'api_credential_account_';

  final FlutterSecureStorage _storage;

  String _keyFor(String accountId) {
    final normalized = accountId.trim();
    if (normalized.isEmpty) {
      throw ArgumentError.value(accountId, 'accountId', 'Não pode ser vazio.');
    }
    return '$_keyPrefix$normalized';
  }

  Future<void> saveCredential({
    required String accountId,
    required String apiKey,
  }) async {
    final value = apiKey.trim();
    if (value.isEmpty) {
      throw ArgumentError.value(apiKey, 'apiKey', 'Não pode ser vazia.');
    }
    await _storage.write(key: _keyFor(accountId), value: value);
  }

  Future<String?> readCredential(String accountId) {
    return _storage.read(key: _keyFor(accountId));
  }

  Future<void> deleteCredential(String accountId) {
    return _storage.delete(key: _keyFor(accountId));
  }
}
