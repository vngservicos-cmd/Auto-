
import 'dart:async';
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/automation_task.dart';

class AutomationTaskService {
  static const String _storageKey = 'automation_tasks_v1';

  // Compartilha a fila de operações entre todas as instâncias
  // deste serviço dentro do mesmo isolate.
  static Future<void> _operationQueue = Future<void>.value();

  Future<T> _runExclusive<T>(
    Future<T> Function() operation,
  ) async {
    final previous = _operationQueue;
    final completer = Completer<void>();

    _operationQueue = completer.future;

    try {
      await previous;
      return await operation();
    } finally {
      completer.complete();
    }
  }

  Future<List<AutomationTask>> getAll() {
    return _runExclusive(_getAllInternal);
  }

  Future<List<AutomationTask>> _getAllInternal() async {
    final prefs = await SharedPreferences.getInstance();
    final storedData = prefs.getString(_storageKey);

    if (storedData == null || storedData.isEmpty) {
      return [];
    }

    final dynamic decoded;

    try {
      decoded = jsonDecode(storedData);
    } catch (_) {
      throw const FormatException(
        'Não foi possível interpretar a fila de tarefas. '
        'Os dados originais foram preservados.',
      );
    }

    if (decoded is! List) {
      throw const FormatException(
        'O formato da fila de tarefas é inválido. '
        'Os dados originais foram preservados.',
      );
    }

    final tasks = <AutomationTask>[];
    final ids = <String>{};

    for (final item in decoded) {
      if (item is! Map) {
        throw const FormatException(
          'Foi encontrado um registro de tarefa inválido. '
          'Os dados originais foram preservados.',
        );
      }

      try {
        final task = AutomationTask.fromJson(
          Map<String, dynamic>.from(item),
        );

        if (!ids.add(task.id)) {
          throw const FormatException(
            'A fila contém identificadores de tarefa duplicados.',
          );
        }

        tasks.add(task);
      } on FormatException {
        rethrow;
      } catch (_) {
        throw const FormatException(
          'Não foi possível recuperar uma tarefa. '
          'Os dados originais foram preservados.',
        );
      }
    }

    return tasks;
  }

  Future<bool> _saveAllInternal(
    List<AutomationTask> tasks,
  ) async {
    _validateCollection(tasks);

    final prefs = await SharedPreferences.getInstance();

    final encoded = jsonEncode(
      tasks.map((task) => task.toJson()).toList(),
    );

    return prefs.setString(_storageKey, encoded);
  }

  Future<bool> saveAll(List<AutomationTask> tasks) {
    return _runExclusive(() => _saveAllInternal(tasks));
  }

  Future<bool> add(AutomationTask task) {
    return _runExclusive(() async {
      task.validate();

      final tasks = await _getAllInternal();

      if (tasks.any((item) => item.id == task.id)) {
        return false;
      }

      tasks.add(task);

      return _saveAllInternal(tasks);
    });
  }

  Future<int> addMany(List<AutomationTask> newTasks) {
    return _runExclusive(() async {
      _validateCollection(newTasks);

      final tasks = await _getAllInternal();
      final ids = tasks.map((task) => task.id).toSet();

      for (final task in newTasks) {
        if (!ids.add(task.id)) {
          throw const FormatException(
            'Uma tarefa possui ID já cadastrado. '
            'Nenhum registro foi alterado.',
          );
        }
      }

      tasks.addAll(newTasks);

      final saved = await _saveAllInternal(tasks);
      return saved ? newTasks.length : 0;
    });
  }

  Future<bool> update(AutomationTask task) {
    return _runExclusive(() async {
      task.validate();

      final tasks = await _getAllInternal();

      final index = tasks.indexWhere(
        (item) => item.id == task.id,
      );

      if (index == -1) {
        return false;
      }

      tasks[index] = task;

      return _saveAllInternal(tasks);
    });
  }

  Future<bool> remove(String id) {
    return _runExclusive(() async {
      if (id.trim().isEmpty) {
        return false;
      }

      final tasks = await _getAllInternal();
      final originalLength = tasks.length;

      tasks.removeWhere((task) => task.id == id);

      if (tasks.length == originalLength) {
        return false;
      }

      return _saveAllInternal(tasks);
    });
  }

  Future<AutomationTask?> getById(String id) async {
    if (id.trim().isEmpty) {
      return null;
    }

    final tasks = await getAll();

    for (final task in tasks) {
      if (task.id == id) {
        return task;
      }
    }

    return null;
  }

  Future<List<AutomationTask>> getPending() {
    return _filter(
      (task) => task.status == AutomationTaskStatus.pending,
    );
  }

  Future<List<AutomationTask>> getRunning() {
    return _filter(
      (task) => task.status == AutomationTaskStatus.running,
    );
  }

  Future<List<AutomationTask>> getFailed() {
    return _filter(
      (task) => task.status == AutomationTaskStatus.failed,
    );
  }

  Future<List<AutomationTask>> getCompleted() {
    return _filter(
      (task) => task.status == AutomationTaskStatus.completed,
    );
  }

  Future<List<AutomationTask>> getReadyTasks({
    int limit = 10,
  }) async {
    if (limit <= 0) {
      return [];
    }

    final tasks = await getAll();
    final ready = tasks.where((task) => task.isReady).toList();

    ready.sort((a, b) {
      final priorityComparison =
          b.priority.compareTo(a.priority);

      if (priorityComparison != 0) {
        return priorityComparison;
      }

      return a.createdAt.compareTo(b.createdAt);
    });

    return ready.take(limit).toList();
  }

  // Aquisição protegida: relê a tarefa e verifica sua disponibilidade
  // dentro da mesma operação exclusiva que altera seu estado.
  Future<bool> markRunning(String id) {
    return _runExclusive(() async {
      if (id.trim().isEmpty) {
        return false;
      }

      final tasks = await _getAllInternal();

      final index = tasks.indexWhere(
        (task) => task.id == id,
      );

      if (index == -1) {
        return false;
      }

      final task = tasks[index];

      // Outra execução pode ter adquirido a tarefa antes desta chamada.
      if (!task.isReady) {
        return false;
      }

      final now = DateTime.now();

      final updatedTask = task.copyWith(
        status: AutomationTaskStatus.running,
        startedAt: now,
        updatedAt: now,
        lastError: null,
        nextAttemptAt: null,
      );

      updatedTask.validate();
      tasks[index] = updatedTask;

      return _saveAllInternal(tasks);
    });
  }

  Future<bool> markCompleted(String id) {
    return _changeTask(
      id,
      (task) {
        if (!task.isRunning) {
          throw StateError(
            'Somente tarefas em execução podem ser concluídas.',
          );
        }

        final now = DateTime.now();

        return task.copyWith(
          status: AutomationTaskStatus.completed,
          completedAt: now,
          updatedAt: now,
          lastError: null,
          nextAttemptAt: null,
        );
      },
    );
  }

  Future<bool> markFailed(
    String id, {
    required String error,
    Duration? retryDelay,
  }) {
    return _changeTask(
      id,
      (task) {
        if (!task.isRunning) {
          throw StateError(
            'Somente tarefas em execução podem receber falha.',
          );
        }

        final now = DateTime.now();
        final newAttemptCount = task.attemptCount + 1;

        final canRetry =
            newAttemptCount < task.maxAttempts;

        final nextAttempt = canRetry
            ? now.add(
                retryDelay ??
                    _calculateRetryDelay(task.attemptCount),
              )
            : null;

        return task.copyWith(
          status: AutomationTaskStatus.failed,
          attemptCount: newAttemptCount,
          updatedAt: now,
          lastError: error.trim().isEmpty
              ? 'Falha não especificada.'
              : error.trim(),
          nextAttemptAt: nextAttempt,
        );
      },
    );
  }

  Future<bool> cancel(String id) {
    return _changeTask(
      id,
      (task) {
        if (task.isTerminal) {
          throw StateError(
            'Esta tarefa já está em estado final.',
          );
        }

        final now = DateTime.now();

        return task.copyWith(
          status: AutomationTaskStatus.cancelled,
          updatedAt: now,
          nextAttemptAt: null,
        );
      },
    );
  }

  Future<bool> retry(String id) {
    return _changeTask(
      id,
      (task) {
        if (task.status != AutomationTaskStatus.failed) {
          throw StateError(
            'Somente tarefas com falha podem ser reenviadas.',
          );
        }

        if (!task.canRetry) {
          throw StateError(
            'A tarefa atingiu o limite de tentativas.',
          );
        }

        return task.copyWith(
          status: AutomationTaskStatus.pending,
          updatedAt: DateTime.now(),
          nextAttemptAt: null,
          lastError: null,
        );
      },
    );
  }

  // Recupera tarefas interrompidas sem apagar o histórico
  // de tentativas ou outros dados da tarefa.
  Future<int> recoverInterruptedTasks() {
    return _runExclusive(() async {
      final tasks = await _getAllInternal();
      var recovered = 0;
      final now = DateTime.now();

      for (var i = 0; i < tasks.length; i++) {
        final task = tasks[i];

        if (!task.isRunning) {
          continue;
        }

        tasks[i] = task.copyWith(
          status: AutomationTaskStatus.pending,
          updatedAt: now,
          startedAt: null,
          completedAt: null,
          nextAttemptAt: null,
        );

        recovered++;
      }

      if (recovered == 0) {
        return 0;
      }

      final saved = await _saveAllInternal(tasks);
      return saved ? recovered : 0;
    });
  }

  Future<int> count() async {
    final tasks = await getAll();
    return tasks.length;
  }

  Future<int> countByStatus(
    AutomationTaskStatus status,
  ) async {
    final tasks = await getAll();

    return tasks.where((task) => task.status == status).length;
  }

  Future<List<AutomationTask>> _filter(
    bool Function(AutomationTask task) predicate,
  ) async {
    final tasks = await getAll();
    return tasks.where(predicate).toList();
  }

  Future<bool> _changeTask(
    String id,
    AutomationTask Function(AutomationTask task) transform,
  ) {
    return _runExclusive(() async {
      final tasks = await _getAllInternal();

      final index = tasks.indexWhere(
        (task) => task.id == id,
      );

      if (index == -1) {
        return false;
      }

      final updatedTask = transform(tasks[index]);
      updatedTask.validate();

      tasks[index] = updatedTask;

      return _saveAllInternal(tasks);
    });
  }

  Duration _calculateRetryDelay(int attemptCount) {
    // Intervalos progressivos: 1, 2, 4, 8... minutos.
    final exponent = attemptCount.clamp(0, 10);
    final minutes = 1 << exponent;

    return Duration(minutes: minutes);
  }

  void _validateCollection(List<AutomationTask> tasks) {
    final ids = <String>{};

    for (final task in tasks) {
      task.validate();

      if (!ids.add(task.id)) {
        throw const FormatException(
          'A lista contém identificadores de tarefa duplicados.',
        );
      }
    }
  }
}
