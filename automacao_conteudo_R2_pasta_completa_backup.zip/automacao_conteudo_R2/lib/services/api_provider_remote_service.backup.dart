import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/api_provider.dart';
import 'api_access_token_storage.dart';

class ApiProviderRemoteService {
  ApiProviderRemoteService({
    http.Client? client,
    ApiAccessTokenStorage? tokenStorage,
  })  : _client = client ?? http.Client(),
        _tokenStorage = tokenStorage ?? ApiAccessTokenStorage();

  final http.Client _client;
  final ApiAccessTokenStorage _tokenStorage;

  static const String _baseUrl =
      'https://automacao-conteudo-backend.vngservicos.workers.dev';

  Future<Map<String, String>> _headers() async {
    final token = await _tokenStorage.readToken();

    if (token == null || token.isEmpty) {
      throw Exception(
        'Token de acesso não configurado. Configure o acesso ao servidor.',
      );
    }

    return {
      'Content-Type': 'application/json; charset=utf-8',
      'Authorization': 'Bearer $token',
    };
  }

  dynamic _decodeResponse(http.Response response) {
    final body = utf8.decode(response.bodyBytes);

    if (body.isEmpty) {
      return null;
    }

    return jsonDecode(body);
  }

  void _checkResponse(http.Response response, dynamic data) {
    if (response.statusCode >= 200 && response.statusCode < 300) {
      return;
    }

    final message = data is Map
        ? data['mensagem'] ?? data['erro']
        : null;

    throw Exception(
      message?.toString() ??
          'Erro de comunicação com o servidor (${response.statusCode}).',
    );
  }

  Future<List<ApiProvider>> getAll() async {
    final response = await _client.get(
      Uri.parse('$_baseUrl/api/provedores'),
      headers: await _headers(),
    );

    final data = _decodeResponse(response);
    _checkResponse(response, data);

    if (data is! Map || data['provedores'] is! List) {
      throw Exception('Resposta inválida ao consultar os provedores.');
    }

    return (data['provedores'] as List)
        .map(
          (item) => ApiProvider.fromJson(
            Map<String, dynamic>.from(item as Map),
          ),
        )
        .toList();
  }

  Future<void> add(ApiProvider provider) async {
    final response = await _client.post(
      Uri.parse('$_baseUrl/api/provedores'),
      headers: await _headers(),
      body: jsonEncode(provider.toJson()),
    );

    final data = _decodeResponse(response);
    _checkResponse(response, data);
  }

  Future<void> update(ApiProvider provider) async {
    final response = await _client.put(
      Uri.parse('$_baseUrl/api/provedores'),
      headers: await _headers(),
      body: jsonEncode(provider.toJson()),
    );

    final data = _decodeResponse(response);
    _checkResponse(response, data);
  }

  Future<void> remove(String id) async {
    final uri = Uri.parse('$_baseUrl/api/provedores').replace(
      queryParameters: {'id': id},
    );

    final response = await _client.delete(
      uri,
      headers: await _headers(),
    );

    final data = _decodeResponse(response);
    _checkResponse(response, data);
  }

  void dispose() {
    _client.close();
  }
}