import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import 'api_model_catalog.dart';
import 'api_custom_model_storage.dart';

class ApiConnectionResult {
  final bool success;
  final String message;
  final int? statusCode;

  const ApiConnectionResult({
    required this.success,
    required this.message,
    this.statusCode,
  });
}

class ApiProviderException implements Exception {
  final String message;
  final int? statusCode;
  final bool retryable;

  const ApiProviderException({
    required this.message,
    this.statusCode,
    this.retryable = false,
  });

  bool get shouldTryNextAccount {
    if (retryable) return true;

    final code = statusCode;

    if (code == null) return false;

    if (code == 400 || code == 422) return false;

    return code == 401 ||
        code == 403 ||
        code == 404 ||
        code == 408 ||
        code == 429 ||
        code >= 500;
  }

  @override
  String toString() => message;
}

abstract class ApiProviderAdapter {
  String get providerId;

  Future<ApiConnectionResult> testConnection({
    required String apiKey,
    required String modelId,
    String? endpointUrl,
  });

  Future<String> generateContent({
    required String apiKey,
    required String modelId,
    required String prompt,
    String? endpointUrl,
  });
}

class GoogleGeminiAdapter implements ApiProviderAdapter {
  GoogleGeminiAdapter({
    http.Client? client,
    ApiCustomModelStorage? customModelStorage,
  })  : _client = client ?? http.Client(),
        _ownsClient = client == null,
        _customModelStorage =
            customModelStorage ?? ApiCustomModelStorage();

  final http.Client _client;
  final bool _ownsClient;
  final ApiCustomModelStorage _customModelStorage;

  bool _disposed = false;

  @override
  String get providerId => 'google';

  String _normalizeProvider(String provider) {
    final value = provider.trim().toLowerCase();

    if (value.contains('google') || value.contains('gemini')) {
      return 'google';
    }
    if (value.contains('openai') || value == 'gpt' || value.contains('openrouter') || value.contains('groq') || value.contains('mistral') || value.contains('together') || value.contains('fireworks') || value.contains('deepseek')) return 'openai';

    return value;
  }

  Future<ApiModel> _findAvailableModel(String modelId) async {
    final normalizedId = modelId.trim();

    if (normalizedId.isEmpty) {
      throw const ApiProviderException(
        message: 'Selecione um modelo.',
      );
    }

    ApiModel? model = ApiModelCatalog.findById(normalizedId);

    if (model == null) {
      final customModels =
          await _customModelStorage.getByProvider('Google');

      for (final customModel in customModels) {
        if (customModel.id.trim().toLowerCase() ==
            normalizedId.toLowerCase()) {
          model = customModel;
          break;
        }
      }
    }

    if (model == null ||
        _normalizeProvider(model.provider) != 'google' ||
        !model.active) {
      throw const ApiProviderException(
        message: 'Modelo não cadastrado ou indisponível.',
      );
    }

    if (model.capability.trim().toLowerCase() != 'text') {
      throw const ApiProviderException(
        message: 'O modelo selecionado não oferece geração de texto.',
        statusCode: 400,
      );
    }

    return model;
  }

  void _checkNotDisposed() {
    if (_disposed) {
      throw const ApiProviderException(
        message: 'O adaptador Gemini já foi encerrado.',
      );
    }
  }

  Uri _generateUri(String modelId) {
    return Uri.https(
      'generativelanguage.googleapis.com',
      '/v1beta/models/${Uri.encodeComponent(modelId)}:generateContent',
    );
  }

  Map<String, String> _headers(String apiKey) {
    return {
      'Content-Type': 'application/json',
      'x-goog-api-key': apiKey,
    };
  }

  Map<String, dynamic> _requestBody(
    String prompt, {
    int maxOutputTokens = 2048,
  }) {
    return {
      'contents': [
        {
          'parts': [
            {'text': prompt}
          ]
        }
      ],
      'generationConfig': {
        'maxOutputTokens': maxOutputTokens,
      },
    };
  }

  String _extractGeneratedText(String responseBody) {
    dynamic decoded;

    try {
      decoded = jsonDecode(responseBody);
    } on FormatException {
      throw const ApiProviderException(
        message: 'O Gemini retornou uma resposta inválida.',
      );
    }

    if (decoded is! Map) {
      throw const ApiProviderException(
        message: 'Formato de resposta inesperado do Gemini.',
      );
    }

    final candidates = decoded['candidates'];

    if (candidates is List && candidates.isNotEmpty) {
      final firstCandidate = candidates.first;

      if (firstCandidate is Map) {
        final content = firstCandidate['content'];

        if (content is Map) {
          final parts = content['parts'];

          if (parts is List) {
            final texts = parts
                .whereType<Map>()
                .map((part) => part['text'])
                .whereType<String>()
                .where((text) => text.trim().isNotEmpty)
                .toList();

            if (texts.isNotEmpty) {
              return texts.join('\n').trim();
            }
          }
        }
      }
    }

    final promptFeedback = decoded['promptFeedback'];

    if (promptFeedback is Map) {
      final blockReason = promptFeedback['blockReason'];

      if (blockReason != null) {
        throw ApiProviderException(
          message: 'O Gemini bloqueou o pedido: $blockReason.',
          statusCode: 400,
        );
      }
    }

    throw const ApiProviderException(
      message: 'O Gemini não retornou texto válido.',
    );
  }

  ApiProviderException _httpException(int statusCode) {
    switch (statusCode) {
      case 400:
        return const ApiProviderException(
          message: 'Solicitação inválida. Verifique o pedido enviado.',
          statusCode: 400,
        );

      case 401:
        return const ApiProviderException(
          message: 'A chave da API foi recusada.',
          statusCode: 401,
        );

      case 403:
        return const ApiProviderException(
          message: 'A conta não possui permissão para usar este serviço.',
          statusCode: 403,
        );

      case 404:
        return const ApiProviderException(
          message: 'Modelo não encontrado ou indisponível.',
          statusCode: 404,
        );

      case 408:
        return const ApiProviderException(
          message: 'Tempo limite de comunicação atingido.',
          statusCode: 408,
        );

      case 429:
        return const ApiProviderException(
          message: 'Limite de requisições ou cota atingido.',
          statusCode: 429,
        );

      case 422:
        return const ApiProviderException(
          message: 'A solicitação enviada não pôde ser processada.',
          statusCode: 422,
        );

      default:
        if (statusCode >= 500) {
          return ApiProviderException(
            message:
                'Serviço Gemini temporariamente indisponível. HTTP $statusCode.',
            statusCode: statusCode,
          );
        }

        return ApiProviderException(
          message: 'Falha na API Gemini. Código HTTP: $statusCode.',
          statusCode: statusCode,
        );
    }
  }

  @override
  Future<ApiConnectionResult> testConnection({
    required String apiKey,
    required String modelId,
    String? endpointUrl,
  }) async {
    final key = apiKey.trim();

    if (key.isEmpty) {
      return const ApiConnectionResult(
        success: false,
        message: 'Informe a chave da API.',
      );
    }

    try {
      _checkNotDisposed();
      await _findAvailableModel(modelId);

      final response = await _client
          .post(
            _generateUri(modelId.trim()),
            headers: _headers(key),
            body: jsonEncode(
              _requestBody(
                'Responda apenas: conexão funcionando.',
                maxOutputTokens: 30,
              ),
            ),
          )
          .timeout(const Duration(seconds: 90));

      if (response.statusCode == 200) {
        return const ApiConnectionResult(
          success: true,
          message: 'Conexão funcionando.',
          statusCode: 200,
        );
      }

      final error = _httpException(response.statusCode);

      return ApiConnectionResult(
        success: false,
        message: error.message,
        statusCode: error.statusCode,
      );
    } on ApiProviderException catch (error) {
      return ApiConnectionResult(
        success: false,
        message: error.message,
        statusCode: error.statusCode,
      );
    } on TimeoutException {
      return const ApiConnectionResult(
        success: false,
        message: 'O teste de conexão excedeu o tempo limite.',
      );
    } on http.ClientException {
      return const ApiConnectionResult(
        success: false,
        message: 'Não foi possível conectar. Verifique sua internet.',
      );
    } catch (_) {
      return const ApiConnectionResult(
        success: false,
        message: 'Falha inesperada ao testar a conexão.',
      );
    }
  }

  @override
  Future<String> generateContent({
    required String apiKey,
    required String modelId,
    required String prompt,
    String? endpointUrl,
  }) async {
    final key = apiKey.trim();
    final normalizedPrompt = prompt.trim();

    _checkNotDisposed();

    if (key.isEmpty) {
      throw const ApiProviderException(
        message: 'A chave da API não foi informada.',
      );
    }

    if (normalizedPrompt.isEmpty) {
      throw const ApiProviderException(
        message: 'O pedido de geração está vazio.',
        statusCode: 400,
      );
    }

    if (normalizedPrompt.length > 12000) {
      throw const ApiProviderException(
        message: 'O pedido ultrapassa 12.000 caracteres.',
        statusCode: 400,
      );
    }

    await _findAvailableModel(modelId);

    try {
      final response = await _client
          .post(
            _generateUri(modelId.trim()),
            headers: _headers(key),
            body: jsonEncode(_requestBody(normalizedPrompt)),
          )
          .timeout(const Duration(seconds: 90));

      if (response.statusCode != 200) {
        throw _httpException(response.statusCode);
      }

      return _extractGeneratedText(response.body);
    } on ApiProviderException {
      rethrow;
    } on TimeoutException {
      throw const ApiProviderException(
        message: 'O Gemini excedeu o tempo limite de resposta.',
        retryable: true,
      );
    } on http.ClientException {
      throw const ApiProviderException(
        message: 'Falha de comunicação com o Gemini. Verifique sua internet.',
        retryable: true,
      );
    } catch (_) {
      throw const ApiProviderException(
        message: 'Ocorreu uma falha inesperada durante a geração.',
      );
    }
  }

  void dispose() {
    if (_disposed) return;

    _disposed = true;

    if (_ownsClient) {
      _client.close();
    }
  }
}


/// Adaptador para APIs OpenAI Chat Completions. Também atende provedores
/// que expõem compatibilidade OpenAI quando o endpoint oficial é usado.
class OpenAiCompatibleTextAdapter implements ApiProviderAdapter {
  OpenAiCompatibleTextAdapter({http.Client? client})
      : _client = client ?? http.Client(), _ownsClient = client == null;
  final http.Client _client;
  final bool _ownsClient;
  bool _disposed = false;

  @override
  String get providerId => 'openai';

  Uri get _endpoint => Uri.parse('https://api.openai.com/v1/chat/completions');

  Uri _resolveEndpoint(String? value) {
    final raw = value?.trim() ?? '';
    if (raw.isEmpty) return _endpoint;
    final uri = Uri.tryParse(raw);
    if (uri == null || !uri.hasScheme || (uri.scheme != 'https' && uri.scheme != 'http')) {
      throw const ApiProviderException(message: 'Endpoint de texto inválido. Informe uma URL HTTP/HTTPS completa.');
    }
    return uri;
  }

  @override
  Future<ApiConnectionResult> testConnection({required String apiKey, required String modelId, String? endpointUrl}) async {
    try {
      final response = await _client.post(_resolveEndpoint(endpointUrl),
        headers: {'Authorization': 'Bearer ${apiKey.trim()}', 'Content-Type': 'application/json'},
        body: jsonEncode({'model': modelId, 'messages': [{'role': 'user', 'content': 'Responda apenas: conexão funcionando.'}], 'max_tokens': 12}),
      ).timeout(const Duration(seconds: 35));
      if (response.statusCode >= 200 && response.statusCode < 300) {
        return const ApiConnectionResult(success: true, message: 'Conexão OpenAI compatível funcionando.', statusCode: 200);
      }
      return ApiConnectionResult(success: false, message: _message(response.body, response.statusCode), statusCode: response.statusCode);
    } catch (error) {
      return ApiConnectionResult(success: false, message: 'Falha de conexão: $error');
    }
  }

  @override
  Future<String> generateContent({required String apiKey, required String modelId, required String prompt, String? endpointUrl}) async {
    if (_disposed) throw const ApiProviderException(message: 'Adaptador encerrado.');
    final response = await _client.post(_resolveEndpoint(endpointUrl),
      headers: {'Authorization': 'Bearer ${apiKey.trim()}', 'Content-Type': 'application/json'},
      body: jsonEncode({'model': modelId, 'messages': [{'role': 'user', 'content': prompt}], 'temperature': 0.7}),
    ).timeout(const Duration(minutes: 2));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw ApiProviderException(message: _message(response.body, response.statusCode), statusCode: response.statusCode);
    }
    try {
      final decoded = jsonDecode(response.body) as Map<String, dynamic>;
      final choices = decoded['choices'] as List?;
      final message = choices?.isNotEmpty == true ? choices!.first['message'] : null;
      final content = message is Map ? message['content'] : null;
      if (content is String && content.trim().isNotEmpty) return content.trim();
      throw const ApiProviderException(message: 'A API retornou resposta sem texto.');
    } on ApiProviderException { rethrow; } catch (_) {
      throw const ApiProviderException(message: 'Resposta OpenAI incompatível ou JSON inválido.');
    }
  }

  String _message(String body, int code) {
    try {
      final data = jsonDecode(body);
      if (data is Map && data['error'] is Map) {
        final message = (data['error'] as Map)['message'];
        if (message != null) return 'HTTP $code: $message';
      }
    } catch (_) {}
    return 'Falha HTTP $code: ${body.length > 300 ? body.substring(0, 300) : body}';
  }

  void dispose() { if (_disposed) return; _disposed = true; if (_ownsClient) _client.close(); }
}

class ApiProviderAdapterRegistry {
  ApiProviderAdapterRegistry({
    List<ApiProviderAdapter>? adapters,
  }) : _adapters = adapters ?? [
          GoogleGeminiAdapter(),
          OpenAiCompatibleTextAdapter(),
        ];

  final List<ApiProviderAdapter> _adapters;

  bool _disposed = false;

  String _normalizeProviderId(String providerId) {
    final value = providerId.trim().toLowerCase();

    if (value.contains('google') || value.contains('gemini')) {
      return 'google';
    }
    if (value.contains('openai') || value == 'gpt' || value.contains('openrouter') || value.contains('groq') || value.contains('mistral') || value.contains('together') || value.contains('fireworks') || value.contains('deepseek')) return 'openai';

    return value;
  }

  ApiProviderAdapter? find(String providerId) {
    if (_disposed) {
      return null;
    }

    final normalizedId = _normalizeProviderId(providerId);

    for (final adapter in _adapters) {
      if (_normalizeProviderId(adapter.providerId) == normalizedId) {
        return adapter;
      }
    }

    return null;
  }

  void dispose() {
    if (_disposed) return;

    _disposed = true;

    for (final adapter in _adapters) {
      if (adapter is GoogleGeminiAdapter) {
        adapter.dispose();
      } else if (adapter is OpenAiCompatibleTextAdapter) {
        adapter.dispose();
      }
    }
  }
}
