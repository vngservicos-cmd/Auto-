
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/api_provider.dart';

class ApiProviderRegistry {
  static const String _storageKey = 'api_provider_registry_v1';

  Future<List<ApiProvider>> getAll() async {
    final prefs = await SharedPreferences.getInstance();
    final storedData = prefs.getString(_storageKey);

    if (storedData == null || storedData.isEmpty) {
      return [];
    }

    try {
      final decoded = jsonDecode(storedData);

      if (decoded is! List) {
        return [];
      }

      var needsMigration = false;

      final providers = <ApiProvider>[];

      for (var index = 0; index < decoded.length; index++) {
        final item = decoded[index];

        if (item is! Map) {
          continue;
        }

        final json = Map<String, dynamic>.from(item);

        final createdAtValue = json['createdAt'];

        if (createdAtValue == null ||
            createdAtValue.toString().isEmpty) {
          // Mantém a ordem dos registros antigos durante a migração.
          // São datas técnicas de referência, não datas históricas reais.
          json['createdAt'] = DateTime.fromMillisecondsSinceEpoch(
            index,
            isUtc: true,
          ).toIso8601String();

          needsMigration = true;
        }

        providers.add(ApiProvider.fromJson(json));
      }

      providers.sort((a, b) {
        final dateComparison = a.createdAt.compareTo(b.createdAt);

        if (dateComparison != 0) {
          return dateComparison;
        }

        return a.id.compareTo(b.id);
      });

      if (needsMigration) {
        await saveAll(providers);
      }

      return providers;
    } catch (_) {
      return [];
    }
  }

  Future<bool> saveAll(List<ApiProvider> providers) async {
    final prefs = await SharedPreferences.getInstance();

    final encoded = jsonEncode(
      providers.map((provider) => provider.toJson()).toList(),
    );

    return prefs.setString(_storageKey, encoded);
  }

  Future<bool> add(ApiProvider provider) async {
    final providers = await getAll();

    final alreadyExists = providers.any(
      (item) => item.id == provider.id,
    );

    if (alreadyExists) {
      return false;
    }

    providers.add(provider);

    providers.sort((a, b) {
      final dateComparison = a.createdAt.compareTo(b.createdAt);

      if (dateComparison != 0) {
        return dateComparison;
      }

      return a.id.compareTo(b.id);
    });

    return saveAll(providers);
  }

  Future<bool> update(ApiProvider updatedProvider) async {
    final providers = await getAll();

    final index = providers.indexWhere(
      (item) => item.id == updatedProvider.id,
    );

    if (index == -1) {
      return false;
    }

    // Preserva a data original de cadastro ao editar.
    final currentProvider = providers[index];

    providers[index] = ApiProvider(
      id: updatedProvider.id,
      name: updatedProvider.name,
      provider: updatedProvider.provider,
      capability: updatedProvider.capability,
      connectionType: updatedProvider.connectionType,
      active: updatedProvider.active,
      isFree: updatedProvider.isFree,
      hasFreeTrial: updatedProvider.hasFreeTrial,
      priority: updatedProvider.priority,
      trialDays: updatedProvider.trialDays,
      trialEndsAt: updatedProvider.trialEndsAt,
      quotaRenewsAt: updatedProvider.quotaRenewsAt,
      websiteUrl: updatedProvider.websiteUrl,
      notes: updatedProvider.notes,
      createdAt: currentProvider.createdAt,
    );

    providers.sort((a, b) {
      final dateComparison = a.createdAt.compareTo(b.createdAt);

      if (dateComparison != 0) {
        return dateComparison;
      }

      return a.id.compareTo(b.id);
    });

    return saveAll(providers);
  }

  Future<bool> remove(String id) async {
    final providers = await getAll();
    final originalLength = providers.length;

    providers.removeWhere((provider) => provider.id == id);

    if (providers.length == originalLength) {
      return false;
    }

    return saveAll(providers);
  }
}
