
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/social_network.dart';

class SocialNetworkRegistry {
  static const String _storageKey = 'social_network_registry_v1';

  Future<List<SocialNetwork>> getAll() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(_storageKey);

    if (saved == null || saved.isEmpty) {
      return [];
    }

    try {
      final decoded = jsonDecode(saved) as List<dynamic>;

      return decoded
          .map(
            (item) => SocialNetwork.fromJson(
              Map<String, dynamic>.from(item as Map),
            ),
          )
          .toList();
    } catch (_) {
      throw const FormatException(
        'Não foi possível ler o cadastro de redes sociais.',
      );
    }
  }

  Future<void> saveAll(List<SocialNetwork> networks) async {
    final prefs = await SharedPreferences.getInstance();

    final json = jsonEncode(
      networks.map((network) => network.toJson()).toList(),
    );

    final success = await prefs.setString(_storageKey, json);

    if (!success) {
      throw Exception('Não foi possível salvar as redes sociais.');
    }
  }

  Future<void> add(SocialNetwork network) async {
    final networks = await getAll();

    final duplicate = networks.any(
      (item) => item.id == network.id,
    );

    if (duplicate) {
      throw ArgumentError('Já existe uma rede com esse identificador.');
    }

    networks.add(network);
    await saveAll(networks);
  }

  Future<void> update(SocialNetwork updatedNetwork) async {
    final networks = await getAll();
    final index = networks.indexWhere(
      (item) => item.id == updatedNetwork.id,
    );

    if (index == -1) {
      throw ArgumentError('A rede informada não foi encontrada.');
    }

    networks[index] = updatedNetwork;
    await saveAll(networks);
  }

  Future<void> remove(String id) async {
    final networks = await getAll();
    networks.removeWhere((item) => item.id == id);
    await saveAll(networks);
  }
}
