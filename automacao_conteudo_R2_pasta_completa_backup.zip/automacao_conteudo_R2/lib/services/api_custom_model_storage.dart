import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'api_model_catalog.dart';

class ApiCustomModelStorage {
  static const String _storageKey = 'api_custom_models_v1';

  String _normalizeProvider(String provider) {
    final normalized = provider.trim().toLowerCase();

    if (normalized.contains('google') ||
        normalized.contains('gemini')) {
      return 'google';
    }

    return normalized;
  }

  String _normalizeModelId(String modelId) {
    return modelId.trim().toLowerCase();
  }

  Future<List<ApiModel>> getAll() async {
    final prefs = await SharedPreferences.getInstance();
    final storedData = prefs.getString(_storageKey);

    if (storedData == null || storedData.isEmpty) {
      return [];
    }

    try {
      final decoded = jsonDecode(storedData);

      if (decoded is! List) {
        return [];
      }

      return decoded
          .whereType<Map>()
          .map(
            (item) => ApiModel.fromJson(
              Map<String, dynamic>.from(item),
            ),
          )
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<List<ApiModel>> getByProvider(String provider) async {
    final models = await getAll();
    final normalizedProvider = _normalizeProvider(provider);

    return models.where((model) {
      return _normalizeProvider(model.provider) ==
              normalizedProvider &&
          model.active;
    }).toList();
  }

  Future<bool> add(ApiModel model) async {
    final models = await getAll();

    final normalizedProvider =
        _normalizeProvider(model.provider);

    final normalizedId = _normalizeModelId(model.id);

    final alreadyExists = ApiModelCatalog.models.any((item) {
      return _normalizeProvider(item.provider) ==
              normalizedProvider &&
          _normalizeModelId(item.id) == normalizedId;
    }) ||
        models.any((item) {
          return _normalizeProvider(item.provider) ==
                  normalizedProvider &&
              _normalizeModelId(item.id) == normalizedId;
        });

    if (alreadyExists) {
      return false;
    }

    models.add(model);

    return _save(models);
  }

  Future<bool> update(ApiModel updatedModel) async {
    final models = await getAll();

    final normalizedProvider =
        _normalizeProvider(updatedModel.provider);

    final normalizedId = _normalizeModelId(updatedModel.id);

    final index = models.indexWhere((model) {
      return _normalizeProvider(model.provider) ==
              normalizedProvider &&
          _normalizeModelId(model.id) == normalizedId;
    });

    if (index == -1) {
      return false;
    }

    models[index] = updatedModel;

    return _save(models);
  }

  Future<bool> remove({
    required String provider,
    required String modelId,
  }) async {
    final models = await getAll();
    final originalLength = models.length;

    final normalizedProvider = _normalizeProvider(provider);
    final normalizedId = _normalizeModelId(modelId);

    models.removeWhere((model) {
      return _normalizeProvider(model.provider) ==
              normalizedProvider &&
          _normalizeModelId(model.id) == normalizedId;
    });

    if (models.length == originalLength) {
      return false;
    }

    return _save(models);
  }

  Future<bool> _save(List<ApiModel> models) async {
    final prefs = await SharedPreferences.getInstance();

    final encoded = jsonEncode(
      models.map((model) => model.toJson()).toList(),
    );

    return prefs.setString(_storageKey, encoded);
  }
}
