import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/api_provider.dart';
import 'api_access_token_storage.dart';
import 'server_connection_storage.dart';

class ApiProviderRemoteException implements Exception {
  final int statusCode;
  final String message;

  const ApiProviderRemoteException({
    required this.statusCode,
    required this.message,
  });

  @override
  String toString() => message;
}

class ApiProviderRemoteService {
  ApiProviderRemoteService({
    http.Client? client,
    ApiAccessTokenStorage? tokenStorage,
    ServerConnectionStorage? serverStorage,
  })  : _client = client ?? http.Client(),
        _tokenStorage = tokenStorage ?? ApiAccessTokenStorage(),
        _serverStorage = serverStorage ?? ServerConnectionStorage();

  final http.Client _client;
  final ApiAccessTokenStorage _tokenStorage;
  final ServerConnectionStorage _serverStorage;

  static const String _legacyBaseUrl =
      'https://automacao-conteudo-backend.vngservicos.workers.dev';

  Future<_ServerAccess> _resolveServerAccess() async {
    final server = await _serverStorage.getActive();

    if (server != null) {
      final token = await _serverStorage.readToken(server.id);

      if (token == null || token.trim().isEmpty) {
        throw Exception(
          'O servidor selecionado não possui token configurado. '
          'Edite o servidor e informe o token de acesso.',
        );
      }

      final baseUrl = server.baseUrl.trim().replaceFirst(
        RegExp(r'/+$'),
        '',
      );

      if (baseUrl.isEmpty) {
        throw Exception(
          'A URL do servidor selecionado está vazia.',
        );
      }

      return _ServerAccess(
        baseUrl: baseUrl,
        token: token.trim(),
      );
    }

    // Compatibilidade com a configuração antiga da Cloudflare.
    final legacyToken = await _tokenStorage.readToken();

    if (legacyToken == null || legacyToken.trim().isEmpty) {
      throw Exception(
        'Nenhum servidor está selecionado e o token antigo '
        'não está configurado. Configure um servidor na Central.',
      );
    }

    return _ServerAccess(
      baseUrl: _legacyBaseUrl,
      token: legacyToken.trim(),
    );
  }

  Future<Map<String, String>> _headers() async {
    final access = await _resolveServerAccess();

    return {
      'Content-Type': 'application/json; charset=utf-8',
      'Authorization': 'Bearer ${access.token}',
    };
  }

  Future<Uri> _endpoint() async {
    final access = await _resolveServerAccess();

    return Uri.parse('${access.baseUrl}/api/provedores');
  }

  dynamic _decodeResponse(http.Response response) {
    final body = utf8.decode(response.bodyBytes);

    if (body.isEmpty) {
      return null;
    }

    try {
      return jsonDecode(body);
    } on FormatException {
      throw Exception(
        'O servidor retornou uma resposta que não é um JSON válido.',
      );
    }
  }

  void _checkResponse(http.Response response, dynamic data) {
    if (response.statusCode >= 200 &&
        response.statusCode < 300) {
      return;
    }

    final message = data is Map
        ? data['mensagem'] ?? data['erro']
        : null;

    throw ApiProviderRemoteException(
      statusCode: response.statusCode,
      message: message?.toString() ??
          'Erro de comunicação com o servidor '
              '(${response.statusCode}).',
    );
  }

  // Payload exclusivo para sincronização de metadados.
  // modelId e credenciais individuais nunca são enviados.
  Map<String, dynamic> _toRemoteJson(ApiProvider provider) {
    return {
      'id': provider.id,
      'name': provider.name,
      'provider': provider.provider,
      'capability': provider.capability,
      'connectionType': provider.connectionType,
      'active': provider.active,
      'isFree': provider.isFree,
      'hasFreeTrial': provider.hasFreeTrial,
      'priority': provider.priority,
      'trialDays': provider.trialDays,
      'trialEndsAt': provider.trialEndsAt?.toIso8601String(),
      'quotaRenewsAt': provider.quotaRenewsAt?.toIso8601String(),
      'websiteUrl': provider.websiteUrl,
      'notes': provider.notes,
      'createdAt': provider.createdAt.toIso8601String(),
    };
  }

  Future<List<ApiProvider>> getAll() async {
    final uri = await _endpoint();
    final headers = await _headers();

    final response = await _client.get(
      uri,
      headers: headers,
    );

    final data = _decodeResponse(response);
    _checkResponse(response, data);

    if (data is! Map || data['provedores'] is! List) {
      throw Exception(
        'Resposta inválida ao consultar os provedores.',
      );
    }

    return (data['provedores'] as List)
        .map(
          (item) => ApiProvider.fromJson(
            Map<String, dynamic>.from(item as Map),
          ),
        )
        .toList();
  }

  Future<void> add(ApiProvider provider) async {
    final uri = await _endpoint();
    final headers = await _headers();

    final response = await _client.post(
      uri,
      headers: headers,
      body: jsonEncode(_toRemoteJson(provider)),
    );

    final data = _decodeResponse(response);
    _checkResponse(response, data);
  }

  Future<void> update(ApiProvider provider) async {
    final uri = await _endpoint();
    final headers = await _headers();

    final response = await _client.put(
      uri,
      headers: headers,
      body: jsonEncode(_toRemoteJson(provider)),
    );

    final data = _decodeResponse(response);
    _checkResponse(response, data);
  }

  Future<void> remove(String id) async {
    final baseUri = await _endpoint();

    final uri = baseUri.replace(
      queryParameters: {'id': id},
    );

    final headers = await _headers();

    final response = await _client.delete(
      uri,
      headers: headers,
    );

    final data = _decodeResponse(response);
    _checkResponse(response, data);
  }

  void dispose() {
    _client.close();
  }
}

class _ServerAccess {
  final String baseUrl;
  final String token;

  const _ServerAccess({
    required this.baseUrl,
    required this.token,
  });
}
