# Contexto de continuidade

Aplicativo Flutter Android/Web de automação de conteúdo. Manter arquitetura local-first, credenciais no FlutterSecureStorage, APIs de texto/imagem/vídeo independentes, rascunhos pendentes de aprovação e histórico de erros. Trabalhar sempre sobre a versão incremental mais recente. Não modificar Cloudflare Worker nem publicar nas redes sem fonte, credenciais e autorização. A entrega atual R2 prepara os testes de APIs, mas ainda precisa de análise/execução Flutter e homologação externa.
