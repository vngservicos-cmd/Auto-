# Pendências e limites conhecidos — R2

## Pronto no código para iniciar testes de APIs
- Geração de texto com Gemini e OpenAI Chat Completions (incluindo endpoint configurável OpenAI-compatible).
- Geração de imagens por endpoint OpenAI Images e Gemini Image Generation; outros serviços REST podem funcionar se adotarem o contrato documentado.
- Geração de vídeo por endpoint REST com URL direta ou job assíncrono que exponha URL de consulta/resultado.
- Seleção de contas ativas por capacidade e prioridade, uso de credenciais no armazenamento seguro, registro de erros e bloqueio de conteúdo incompleto.
- Encaminhamento dos materiais para configuração de postagens e prévias visuais.

## Dependências externas que o usuário precisa configurar
- Chaves válidas, saldo/cota, modelos habilitados e endpoint correto de cada provedor.
- Alguns provedores exigem cabeçalhos, corpos, autenticação, polling ou download próprios. Contratos incompatíveis precisarão de adaptador específico após o primeiro erro real observado.
- URLs temporárias de mídia podem expirar conforme a política do fornecedor; nesta versão os endereços retornados são preservados no registro.
- Testar endpoint de mídia pode gerar consumo/cobrança no fornecedor, pois o teste envia uma solicitação real.

## Ainda não homologado / não declarar pronto
- Compilação Flutter, análise estática e execução dos testes: ambiente desta edição não dispõe de Flutter/Dart. Deve ser executado no computador do projeto após `flutter pub get`.
- Publicação efetiva Instagram/Facebook/TikTok: requer OAuth, permissões de publicação, IDs de páginas/contas, revisão de app e implementação/homologação dos fluxos específicos. Não há credenciais nem autorização para alterar Worker nesta etapa.
- Sincronização completa e homologada com Cloudflare D1/Worker: requer código-fonte e contrato atual do Worker. Não foi alterado.
- Agendamento em segundo plano confiável no Android quando o app está fechado: precisa de implementação/homologação com WorkManager e restrições de bateria.
- Armazenamento permanente local de arquivos grandes: URLs/base64 recebidos são persistidos no registro local; recomenda-se evolução para diretório de mídia dedicado com política de limpeza e sincronização.
- APIs de vídeo com autenticação/protocolo proprietário sem `status_url`/`polling_url` precisam de adaptador específico.

## Segurança
Não registrar chaves nos logs. Não sincronizar credenciais para o Worker. Não marcar como publicado sem resposta confirmada da plataforma social.
