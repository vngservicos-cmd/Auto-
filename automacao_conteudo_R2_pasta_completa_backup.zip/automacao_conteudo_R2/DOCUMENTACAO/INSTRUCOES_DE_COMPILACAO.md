# Instruções de preparação e teste (sem APK nesta entrega)

Na pasta raiz do projeto, no Windows:

```powershell
flutter --version
flutter pub get
 dart format lib test
flutter analyze
flutter test
flutter run -d chrome
```

Para testar no Galaxy Tab S8 Ultra por USB:

```powershell
flutter devices
flutter run -d <ID_DO_TABLET>
```

Não é necessário gerar APK para esta entrega. `flutter run` instala e executa a versão de depuração no dispositivo. Antes dos testes, confirme que o tablet tem internet e que a Central de APIs mostra os provedores cadastrados.

## Roteiro mínimo de validação
1. Cadastrar uma conta de texto Google Gemini ou OpenAI-compatible; informar modelo, endpoint quando aplicável e chave; testar conexão.
2. Cadastrar uma conta de imagem com capacidade `image`, endpoint completo e modelo; testar a chamada real (pode consumir cota).
3. Cadastrar uma conta de vídeo com capacidade `video`, endpoint completo e modelo; testar a chamada real (pode consumir cota).
4. Criar um tema e vincular uma conta social com formato compatível.
5. Gerar primeiro uma legenda; confirmar que o texto aparece na Configuração de Postagens.
6. Gerar carrossel; confirmar quatro slides, quatro imagens e prévia horizontal.
7. Gerar roteiro/vídeo; confirmar URL e player de vídeo.
8. Desconectar uma API ou informar chave inválida; confirmar que a tarefa registra o erro e não é aprovada.
9. Executar `flutter analyze` e `flutter test` e guardar a saída completa para corrigir incompatibilidades do ambiente.

## Observação
O campo Endpoint deve conter a URL completa de geração, não somente o site institucional. Para provedores OpenAI-compatible de texto, use o endpoint completo de Chat Completions. Para imagem e vídeo, use o endpoint específico do serviço.
