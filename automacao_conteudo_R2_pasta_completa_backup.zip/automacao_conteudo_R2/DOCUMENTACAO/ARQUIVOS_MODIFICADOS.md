# Arquivos modificados e criados — R2

## Base
A R2 parte do ZIP incremental R1 aplicado sobre o ZIP completo original enviado em 01/11/2026. Os dados e a estrutura preexistentes foram preservados.

## Alterações R2
- `lib/services/media_generation_service.dart` (novo): seleção de contas de imagem/vídeo por capacidade, prioridade e credencial segura; chamadas REST; suporte a OpenAI Images, Gemini image generation e contratos de vídeo síncronos/assíncronos com `status_url`, `polling_url` ou cabeçalho `Location`; mensagens de erro explícitas.
- `lib/services/api_provider_adapter.dart`: adaptador de texto OpenAI Chat Completions, endpoint configurável e aliases para provedores OpenAI-compatíveis.
- `lib/services/content_generation_service.dart`: encaminha o endpoint configurado para o adaptador de texto.
- `lib/services/automation_task_executor.dart`: geração real de imagens e vídeos depois do texto; exige quatro slides antes das imagens; bloqueia conclusão/aprovação quando mídia necessária falha; encaminha mídia e erros aos rascunhos.
- `lib/models/post_schedule.dart`: persiste URLs de quatro imagens e URL de vídeo, mantendo compatibilidade com registros antigos.
- `lib/screens/post_schedule_screen.dart`: prévia das imagens, player de vídeo e bloqueio de aprovação condicionado à existência dos arquivos necessários.
- `lib/screens/content_generator_screen.dart`: após geração, abre automaticamente a lista de configuração/revisão das postagens criadas.
- `lib/screens/post_history_screen.dart`: mostra quantidade de mídia gerada e erros de geração no cartão da postagem.
- `lib/screens/api_center_screen.dart`: endpoint configurável e teste de chamada real para endpoints de imagem/vídeo; teste de texto Google/OpenAI-compatível.
- `lib/services/api_model_catalog.dart`: modelos OpenAI iniciais.
- `pubspec.yaml`: dependência `video_player` para prévia de vídeo Android/Web.
- `test/post_schedule_media_test.dart` (novo): testes de serialização de mídia e compatibilidade retroativa.
- `test/api_provider_adapter_test.dart` (novo): testes do adaptador de texto OpenAI-compatible e erros HTTP.

## Arquivos incorporados da R1
A R1 também adicionou armazenamento seguro de credenciais, execução imediata do gerador, encaminhamento para configuração de postagens e documentação inicial. Consulte o histórico da R1 nos demais documentos.
