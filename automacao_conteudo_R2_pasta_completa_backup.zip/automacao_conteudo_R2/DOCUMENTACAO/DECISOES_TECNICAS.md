# Decisões técnicas

1. **Local-first:** SharedPreferences permanece como armazenamento local para cadastros, tarefas e postagens. O aplicativo não deve depender da rede para abrir e consultar dados locais.
2. **Segredos:** chaves das APIs de geração permanecem no FlutterSecureStorage, associadas ao ID da conta. Não devem ser incluídas em JSON de provedor, logs, D1 ou Worker.
3. **Capacidades independentes:** texto, imagem, vídeo e áudio são tipos distintos. A seleção de uma conta é filtrada por capacidade e ordenada por prioridade; uma API de imagem não substitui uma API de texto.
4. **Endpoint customizado:** o campo Endpoint da Central de APIs guarda URL não secreta do endpoint. Para texto OpenAI-compatible é usado `/chat/completions` completo; para imagens/vídeos informe o endpoint de geração completo.
5. **Contratos suportados:** texto Gemini `generateContent`; texto OpenAI Chat Completions; imagem OpenAI Images; imagem Gemini com `responseModalities`; vídeo REST com URL imediata ou trabalho assíncrono que informe URL de consulta e resultado.
6. **Falha real, sem simulação:** HTTP não 2xx, JSON inválido, ausência de arquivo ou job sem URL não são tratados como sucesso. O erro fica associado à tarefa e o material fica pendente.
7. **Aprovação:** carrossel exige quatro imagens; formatos com vídeo exigem URL de vídeo. O seletor de aprovação não pode contornar essa regra.
8. **Prévia:** imagens usam `Image` com suporte a URL e data URI; vídeo usa `video_player`. Falhas de carregamento da prévia são mostradas separadamente da geração.
9. **Vídeo assíncrono:** o conector consulta `status_url`, `polling_url`, `statusUrl` ou `Location`, com intervalo de cinco segundos e limite de oito minutos. APIs com protocolo diferente precisam de adaptador específico.
10. **Publicação social:** não realizar publicação fictícia. A publicação real depende de OAuth/tokens, permissões, IDs de conta e requisitos de cada plataforma. O Worker não foi alterado sem seu código-fonte e autorização específica.
