# Guia de cadastro de APIs para os primeiros testes

## Texto
- **Gemini:** provedor com nome contendo `Google` ou `Gemini`; capacidade `text`; selecione/adicone o ID exato do modelo Gemini; endpoint pode ficar vazio para usar `generateContent` oficial.
- **OpenAI e compatíveis:** provedores `OpenAI`, `OpenRouter`, `Groq`, `Mistral`, `Together`, `Fireworks` ou `DeepSeek` usam Chat Completions. Informe o modelo e, para serviços diferentes da OpenAI, o endpoint completo compatível (ex.: `/v1/chat/completions`).
- O adaptador espera `choices[0].message.content` como texto.

## Imagem
- Capacidade deve ser `image`, em conta separada da conta de texto.
- **OpenAI Images:** endpoint padrão automático para provedores OpenAI/DALL-E quando o campo Endpoint fica vazio. O corpo usa `model`, `prompt`, `n: 1` e `size`; a resposta pode trazer `data[].url` ou `data[].b64_json`.
- **Gemini Image:** usa `generateContent` com `responseModalities: [IMAGE, TEXT]`; a resposta precisa conter `candidates[].content.parts[].inlineData`.
- **Outros provedores:** informe o endpoint completo e use contrato semelhante a OpenAI Images, com resposta contendo `data`, `output`, `images` ou `results` com `url`/`uri`/`b64_json`.
- Para carrossel, o aplicativo faz quatro chamadas individuais para compatibilidade com provedores que limitam `n=1`.

## Vídeo
- Capacidade `video`, conta independente e endpoint completo quando o fornecedor não for Gemini Veo.
- Contrato síncrono: POST com `{model, prompt}` e resposta com `url`, `video_url`, `output[].url` ou estrutura equivalente.
- **Gemini Veo:** com provedor Google/Gemini e endpoint vazio, o conector usa `predictLongRunning`, consulta a operação `name` e procura `response.generateVideoResponse.generatedSamples[].video.uri`.
- Contrato assíncrono: resposta inicial deve conter `id`/`job_id`/`task_id` e `status_url`/`polling_url`/`statusUrl` ou cabeçalho `Location`. O aplicativo consulta o trabalho até oito minutos; status final deve trazer URL do vídeo ou `response/result/output` com URL.
- A resposta precisa ser uma URL acessível ao player. Se a API retornar somente ID sem endereço de consulta, a tarefa permanece com erro e não é aprovada.

## Importante
O botão Testar conexão de imagem/vídeo envia uma solicitação real e pode consumir cota/créditos. O teste de conexão confirma HTTP 2xx, não garante que o resultado final tenha formato reproduzível. A geração pelo Gerador valida a resposta e registra os erros completos. Não cole segredos em Observações ou no Endpoint; use o campo de chave/credencial, que é guardado no armazenamento seguro.
