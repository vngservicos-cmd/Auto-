# Versões e estado de validação

| Versão | Estado | Observação |
|---|---|---|
| ZIP original | Base recebida | Projeto completo fornecido pelo usuário |
| R1 | Base incremental mais recente anterior | Mantida e incorporada |
| R2 (1.1.0+2) | Preparada para teste de integração | Não homologada; aguarda `flutter pub get`, análise, testes e execução no tablet |

Nenhuma versão R2 deve ser marcada como aprovada/homologada até o usuário executar os testes no Galaxy Tab e confirmar os resultados.
