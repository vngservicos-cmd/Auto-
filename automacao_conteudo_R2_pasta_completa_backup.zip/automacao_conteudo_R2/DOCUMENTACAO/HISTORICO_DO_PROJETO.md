# Histórico do projeto

## R1 — 01/11/2026
- Integração das alterações incrementais sobre a base original.
- Execução direta de tarefa de geração pelo Gerador.
- Armazenamento seguro de credenciais por conta e token legado do Worker.
- Roteamento de rascunhos para configuração de postagens.

## R2 — 01/11/2026
- Conectores reais de geração de imagem e vídeo com respostas verificáveis.
- Suporte adicional a texto OpenAI Chat Completions e endpoint customizado.
- Persistência de URLs de mídia e compatibilidade com registros antigos.
- Prévia de imagens e player de vídeo na configuração de postagens.
- Bloqueio de aprovação quando a mídia exigida não foi gerada.
- Navegação automática para a lista de configuração/revisão após criar rascunhos.
- Exibição dos erros de mídia nos cartões de postagem.
- Testes de serialização de mídia adicionados.

Esta R2 é uma versão de preparação para testes de integração com chaves reais. Não está homologada em dispositivo e não representa publicação social ou sincronização D1 homologadas.
