package com.example.automacao_conteudo

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
