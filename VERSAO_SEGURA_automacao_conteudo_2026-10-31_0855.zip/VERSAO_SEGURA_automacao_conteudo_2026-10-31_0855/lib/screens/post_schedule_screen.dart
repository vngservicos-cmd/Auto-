
import 'package:flutter/material.dart';

import '../models/post_schedule.dart';
import '../services/post_schedule_service.dart';

class PostScheduleScreen extends StatefulWidget {
  final PostSchedule? scheduleToEdit;

  const PostScheduleScreen({
    super.key,
    this.scheduleToEdit,
  });

  @override
  State<PostScheduleScreen> createState() =>
      _PostScheduleScreenState();
}

class _PostScheduleScreenState extends State<PostScheduleScreen> {
  final _formKey = GlobalKey<FormState>();
  final _contentController = TextEditingController();
  final PostScheduleService _service = PostScheduleService();

  final List<String> _networks = [
    'Instagram',
    'Facebook',
    'TikTok',
    'YouTube',
    'LinkedIn',
    'X',
  ];

  String? _selectedNetwork = 'Instagram';
  bool _automatic = false;
  bool _saving = false;
  DateTime? _scheduledAt;

  bool get _isEditing => widget.scheduleToEdit != null;

  @override
  void initState() {
    super.initState();

    final schedule = widget.scheduleToEdit;

    if (schedule != null) {
      _contentController.text = schedule.content;
      _selectedNetwork = schedule.network;
      _automatic = schedule.automatic;
      _scheduledAt = schedule.scheduledAt;

      if (!_networks.contains(_selectedNetwork)) {
        _networks.add(_selectedNetwork!);
      }
    }
  }

  Future<void> _selectDateTime() async {
    final now = DateTime.now();

    final date = await showDatePicker(
      context: context,
      initialDate: _scheduledAt ?? now,
      firstDate: DateTime(now.year, now.month, now.day),
      lastDate: DateTime(now.year + 5),
    );

    if (date == null || !mounted) return;

    final time = await showTimePicker(
      context: context,
      initialTime: _scheduledAt != null
          ? TimeOfDay.fromDateTime(_scheduledAt!)
          : TimeOfDay.fromDateTime(now),
    );

    if (time == null || !mounted) return;

    setState(() {
      _scheduledAt = DateTime(
        date.year,
        date.month,
        date.day,
        time.hour,
        time.minute,
      );
    });
  }

  String _formatDateTime(DateTime date) {
    final day = date.day.toString().padLeft(2, '0');
    final month = date.month.toString().padLeft(2, '0');
    final hour = date.hour.toString().padLeft(2, '0');
    final minute = date.minute.toString().padLeft(2, '0');

    return '$day/$month/${date.year} às $hour:$minute';
  }

  Future<void> _saveSchedule() async {
    if (_saving) return;
    if (!_formKey.currentState!.validate()) return;

    if (_selectedNetwork == null) return;

    if (_automatic &&
        (_scheduledAt == null ||
            !_scheduledAt!.isAfter(DateTime.now()))) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Escolha uma data e um horário futuros.',
          ),
        ),
      );
      return;
    }

    setState(() {
      _saving = true;
    });

    try {
      final now = DateTime.now();
      final original = widget.scheduleToEdit;

      final schedule = PostSchedule(
        id: original?.id ??
            now.microsecondsSinceEpoch.toString(),
        network: _selectedNetwork!,
        content: _contentController.text.trim(),
        scheduledAt: _automatic ? _scheduledAt : null,
        automatic: _automatic,
        status: _automatic ? 'Agendada' : 'Rascunho',
        createdAt: original?.createdAt ?? now,
      );

      final saved = _isEditing
          ? await _service.update(schedule)
          : await _service.add(schedule);

      if (!mounted) return;

      if (saved) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              _isEditing
                  ? 'Postagem atualizada com sucesso!'
                  : 'Postagem salva com sucesso!',
            ),
          ),
        );

        if (_isEditing) {
          Navigator.pop(context, true);
        } else {
          _formKey.currentState!.reset();
          _contentController.clear();

          setState(() {
            _selectedNetwork = 'Instagram';
            _automatic = false;
            _scheduledAt = null;
          });
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              _isEditing
                  ? 'Não foi possível atualizar. O registro pode não existir mais.'
                  : 'Não foi possível salvar a postagem.',
            ),
          ),
        );
      }
    } catch (error) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Erro ao salvar: $error'),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _saving = false;
        });
      }
    }
  }

  @override
  void dispose() {
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          _isEditing
              ? 'Editar Postagem'
              : 'Configuração de Postagens',
        ),
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 700),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    _isEditing
                        ? 'Editar postagem'
                        : 'Nova postagem',
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _isEditing
                        ? 'Altere o conteúdo ou o agendamento salvo.'
                        : 'Prepare um rascunho ou registre um agendamento.',
                  ),
                  const SizedBox(height: 24),

                  DropdownButtonFormField<String>(
                    initialValue: _selectedNetwork,
                    decoration: const InputDecoration(
                      labelText: 'Rede social',
                      border: OutlineInputBorder(),
                    ),
                    items: _networks.map((network) {
                      return DropdownMenuItem<String>(
                        value: network,
                        child: Text(network),
                      );
                    }).toList(),
                    onChanged: _saving
                        ? null
                        : (value) {
                            setState(() {
                              _selectedNetwork = value;
                            });
                          },
                    validator: (value) {
                      if (value == null) {
                        return 'Escolha uma rede social.';
                      }
                      return null;
                    },
                  ),

                  const SizedBox(height: 16),

                  TextFormField(
                    controller: _contentController,
                    minLines: 5,
                    maxLines: 10,
                    maxLength: 5000,
                    enabled: !_saving,
                    decoration: const InputDecoration(
                      labelText: 'Conteúdo da postagem',
                      hintText: 'Escreva ou cole seu conteúdo aqui...',
                      border: OutlineInputBorder(),
                      alignLabelWithHint: true,
                    ),
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return 'Digite o conteúdo da postagem.';
                      }
                      return null;
                    },
                  ),

                  const SizedBox(height: 12),

                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Agendar postagem'),
                    subtitle: const Text(
                      'Registra uma data e horário futuros.',
                    ),
                    value: _automatic,
                    onChanged: _saving
                        ? null
                        : (value) {
                            setState(() {
                              _automatic = value;
                              if (!value) {
                                _scheduledAt = null;
                              }
                            });
                          },
                  ),

                  if (_automatic) ...[
                    const SizedBox(height: 8),
                    OutlinedButton.icon(
                      onPressed: _saving ? null : _selectDateTime,
                      icon: const Icon(Icons.calendar_month),
                      label: Text(
                        _scheduledAt == null
                            ? 'Escolher data e horário'
                            : _formatDateTime(_scheduledAt!),
                      ),
                    ),
                  ],

                  const SizedBox(height: 24),

                  FilledButton.icon(
                    onPressed: _saving ? null : _saveSchedule,
                    icon: _saving
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                            ),
                          )
                        : Icon(
                            _isEditing ? Icons.save_as : Icons.save,
                          ),
                    label: Text(
                      _saving
                          ? 'Salvando...'
                          : _isEditing
                              ? 'Salvar alterações'
                              : 'Salvar configuração',
                    ),
                  ),

                  const SizedBox(height: 12),

                  const Text(
                    'Os dados são salvos localmente. '
                    'A publicação automática real ainda não está '
                    'conectada às redes sociais.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
