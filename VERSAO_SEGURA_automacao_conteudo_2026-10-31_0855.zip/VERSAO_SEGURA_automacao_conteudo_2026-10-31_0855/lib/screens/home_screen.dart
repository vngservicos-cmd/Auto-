import 'package:flutter/material.dart';

import 'topics_screen.dart';
import 'social_networks_screen.dart';
import 'network_catalog_screen.dart';
import 'api_center_screen.dart';
import 'api_fallback_test_screen.dart';
import 'api_fallback_history_screen.dart';
import 'content_generator_screen.dart';
import 'post_schedule_screen.dart';
import 'post_history_screen.dart';
import 'worker_access_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Automação de Conteúdo'),
        centerTitle: false,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Painel principal',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 8),
              Text(
                'Gerencie seus temas, redes sociais e provedores de IA.',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 24),

              _buildSectionTitle(context, 'Conteúdo e redes sociais'),
              const SizedBox(height: 12),

              _buildMenuCard(
                context: context,
                title: 'Temas de conteúdo',
                description:
                    'Cadastre e organize os temas para gerar conteúdo.',
                icon: Icons.topic_outlined,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const TopicsScreen(),
                    ),
                  );
                },
              ),

              _buildMenuCard(
                context: context,
                title: 'Gerador de Conteúdo',
                description:
                    'Prepare legendas, publicações, roteiros e ideias.',
                icon: Icons.auto_awesome_outlined,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const ContentGeneratorScreen(),
                    ),
                  );
                },
              ),

              _buildMenuCard(
                context: context,
                title: 'Configuração de Postagens',
                description:
                    'Prepare rascunhos e registre agendamentos de publicações.',
                icon: Icons.calendar_month_outlined,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const PostScheduleScreen(),
                    ),
                  );
                },
              ),

              _buildMenuCard(
                context: context,
                title: 'Histórico de Postagens',
                description:
                    'Consulte os rascunhos e agendamentos salvos.',
                icon: Icons.history_outlined,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const PostHistoryScreen(),
                    ),
                  );
                },
              ),

              _buildMenuCard(
                context: context,
                title: 'Redes sociais',
                description:
                    'Gerencie as redes sociais associadas aos temas.',
                icon: Icons.share_outlined,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const SocialNetworksScreen(),
                    ),
                  );
                },
              ),

              _buildMenuCard(
                context: context,
                title: 'Central de Redes',
                description:
                    'Consulte e gerencie o catálogo de redes disponíveis.',
                icon: Icons.hub_outlined,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const NetworkCatalogScreen(),
                    ),
                  );
                },
              ),

              const SizedBox(height: 24),
              _buildSectionTitle(context, 'Inteligência artificial'),
              const SizedBox(height: 12),

              _buildMenuCard(
                context: context,
                title: 'Central de APIs',
                description:
                    'Cadastre provedores e configure suas capacidades.',
                icon: Icons.api_outlined,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const ApiCenterScreen(),
                    ),
                  );
                },
              ),

              _buildMenuCard(
                context: context,
                title: 'Acesso ao Servidor',
                description:
                    'Configure o token e teste a conexão com o servidor.',
                icon: Icons.cloud_outlined,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const WorkerAccessScreen(),
                    ),
                  );
                },
              ),

              _buildMenuCard(
                context: context,
                title: 'Teste de alternativas',
                description:
                    'Simule falhas e confira a seleção de APIs alternativas.',
                icon: Icons.swap_horiz,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ApiFallbackTestScreen(),
                    ),
                  );
                },
              ),

              _buildMenuCard(
                context: context,
                title: 'Histórico de falhas de APIs',
                description:
                    'Consulte os resultados registrados das simulações.',
                icon: Icons.history,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const ApiFallbackHistoryScreen(),
                    ),
                  );
                },
              ),

              const SizedBox(height: 24),
              _buildSectionTitle(context, 'Acompanhamento'),
              const SizedBox(height: 12),

              _buildInfoCard(
                context: context,
                title: 'Histórico de publicações',
                description:
                    'O registro de publicações efetivamente realizadas '
                    'será integrado quando a publicação real estiver '
                    'implementada.',
                icon: Icons.history_edu_outlined,
              ),

              const SizedBox(height: 16),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(
                        Icons.info_outline,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Text(
                          'O projeto está em desenvolvimento. '
                          'O cadastro de provedores e as simulações '
                          'ainda não representam chamadas reais às APIs '
                          'nem publicações automáticas.',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionTitle(BuildContext context, String title) {
    return Text(
      title,
      style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
          ),
    );
  }

  Widget _buildMenuCard({
    required BuildContext context,
    required String title,
    required String description,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      clipBehavior: Clip.antiAlias,
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 10,
        ),
        leading: CircleAvatar(
          child: Icon(icon),
        ),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text(description),
        ),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }

  Widget _buildInfoCard({
    required BuildContext context,
    required String title,
    required String description,
    required IconData icon,
  }) {
    return Card(
      margin: EdgeInsets.zero,
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        leading: CircleAvatar(
          child: Icon(icon),
        ),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Text(description),
        ),
      ),
    );
  }
}
