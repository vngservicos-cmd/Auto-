
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class TopicsScreen extends StatefulWidget {
  const TopicsScreen({super.key});

  @override
  State<TopicsScreen> createState() => _TopicsScreenState();
}

class _TopicsScreenState extends State<TopicsScreen> {
  static const String _storageKey = 'content_topics_v2';
  static const String _legacyStorageKey = 'content_topics';

  final TextEditingController _topicController =
      TextEditingController();
  final TextEditingController _descriptionController =
      TextEditingController();

  final List<Map<String, dynamic>> _topics = [];

  bool _isLoading = true;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _loadTopics();
  }

  Future<void> _loadTopics() async {
    try {
      final preferences = await SharedPreferences.getInstance();
      final savedData = preferences.getString(_storageKey);

      if (savedData != null) {
        final decoded = jsonDecode(savedData) as List<dynamic>;

        _topics.addAll(
          decoded.map(
            (item) => Map<String, dynamic>.from(item as Map),
          ),
        );
      } else {
        final oldTopics =
            preferences.getStringList(_legacyStorageKey) ?? [];

        for (final topic in oldTopics) {
          _topics.add({
            'name': topic,
            'description': '',
            'active': true,
          });
        }

        if (oldTopics.isNotEmpty) {
          await _saveTopics();
        }
      }

      if (!mounted) return;

      setState(() {
        _isLoading = false;
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _isLoading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Não foi possível carregar os temas.'),
        ),
      );
    }
  }

  Future<bool> _saveTopics() async {
    if (mounted) {
      setState(() {
        _isSaving = true;
      });
    }

    bool saved = false;

    try {
      final preferences = await SharedPreferences.getInstance();

      saved = await preferences.setString(
        _storageKey,
        jsonEncode(_topics),
      );
    } catch (_) {
      saved = false;
    }

    if (mounted) {
      setState(() {
        _isSaving = false;
      });

      if (!saved) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Não foi possível salvar os temas.'),
          ),
        );
      }
    }

    return saved;
  }

  bool _nameAlreadyExists(String name, {int? exceptIndex}) {
    return _topics.asMap().entries.any((entry) {
      if (entry.key == exceptIndex) return false;

      final existingName =
          (entry.value['name'] as String? ?? '').trim();

      return existingName.toLowerCase() == name.toLowerCase();
    });
  }

  Future<void> _addTopic() async {
    if (_isSaving) return;

    final name = _topicController.text.trim();
    final description = _descriptionController.text.trim();

    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Digite o nome do tema.'),
        ),
      );
      return;
    }

    if (_nameAlreadyExists(name)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Esse tema já foi cadastrado.'),
        ),
      );
      return;
    }

    setState(() {
      _topics.add({
        'name': name,
        'description': description,
        'active': true,
      });

      _topicController.clear();
      _descriptionController.clear();
    });

    await _saveTopics();
  }

  Future<void> _editTopic(int index) async {
    if (_isSaving || index < 0 || index >= _topics.length) {
      return;
    }

    final formKey = GlobalKey<FormState>();

    String editedName = _topics[index]['name'] as String? ?? '';
    String editedDescription =
        _topics[index]['description'] as String? ?? '';

    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Editar tema'),
          content: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    initialValue: editedName,
                    autofocus: true,
                    textCapitalization: TextCapitalization.sentences,
                    decoration: const InputDecoration(
                      labelText: 'Nome do tema',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      final name = value?.trim() ?? '';

                      if (name.isEmpty) {
                        return 'Digite o nome do tema.';
                      }

                      if (_nameAlreadyExists(
                        name,
                        exceptIndex: index,
                      )) {
                        return 'Esse nome já está cadastrado.';
                      }

                      return null;
                    },
                    onSaved: (value) {
                      editedName = value?.trim() ?? '';
                    },
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    initialValue: editedDescription,
                    textCapitalization: TextCapitalization.sentences,
                    minLines: 2,
                    maxLines: 4,
                    decoration: const InputDecoration(
                      labelText: 'Descrição (opcional)',
                      alignLabelWithHint: true,
                      border: OutlineInputBorder(),
                    ),
                    onSaved: (value) {
                      editedDescription = value?.trim() ?? '';
                    },
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(dialogContext).pop(false);
              },
              child: const Text('Cancelar'),
            ),
            FilledButton.icon(
              onPressed: () {
                final form = formKey.currentState;

                if (form != null && form.validate()) {
                  form.save();
                  Navigator.of(dialogContext).pop(true);
                }
              },
              icon: const Icon(Icons.save_outlined),
              label: const Text('Salvar'),
            ),
          ],
        );
      },
    );

    if (!mounted || result != true) return;

    if (index >= _topics.length) return;

    final previousTopic =
        Map<String, dynamic>.from(_topics[index]);

    setState(() {
      _topics[index]['name'] = editedName;
      _topics[index]['description'] = editedDescription;
    });

    final saved = await _saveTopics();

    if (!mounted) return;

    if (saved) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Tema atualizado.'),
        ),
      );
    } else {
      setState(() {
        _topics[index] = previousTopic;
      });
    }
  }

  Future<void> _toggleTopic(int index, bool active) async {
    if (_isSaving) return;

    final previousValue = _topics[index]['active'];

    setState(() {
      _topics[index]['active'] = active;
    });

    final saved = await _saveTopics();

    if (!mounted) return;

    if (!saved) {
      setState(() {
        _topics[index]['active'] = previousValue;
      });
    }
  }

  Future<void> _removeTopic(int index) async {
    if (_isSaving) return;

    final removedTopic = _topics[index]['name'] as String;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Excluir tema?'),
          content: Text(
            'Deseja realmente excluir "$removedTopic"?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(dialogContext).pop(false);
              },
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () {
                Navigator.of(dialogContext).pop(true);
              },
              child: const Text('Excluir'),
            ),
          ],
        );
      },
    );

    if (confirmed != true || !mounted) return;

    final removedIndex = index;
    final removedData =
        Map<String, dynamic>.from(_topics[removedIndex]);

    setState(() {
      _topics.removeAt(removedIndex);
    });

    final saved = await _saveTopics();

    if (!mounted) return;

    if (saved) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Tema "$removedTopic" removido.'),
        ),
      );
    } else {
      setState(() {
        _topics.insert(
          removedIndex.clamp(0, _topics.length),
          removedData,
        );
      });
    }
  }

  @override
  void dispose() {
    _topicController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final activeCount =
        _topics.where((topic) => topic['active'] == true).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Temas de conteúdo'),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                const Text(
                  'Seus temas',
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Organize os assuntos que servirão de base '
                  'para suas publicações.',
                ),
                const SizedBox(height: 24),
                TextField(
                  controller: _topicController,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: const InputDecoration(
                    labelText: 'Nome do tema',
                    hintText:
                        'Ex.: Tecnologia e inteligência artificial',
                    prefixIcon: Icon(Icons.topic_outlined),
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _descriptionController,
                  textCapitalization: TextCapitalization.sentences,
                  minLines: 2,
                  maxLines: 4,
                  decoration: const InputDecoration(
                    labelText: 'Descrição do tema (opcional)',
                    hintText:
                        'Que tipo de conteúdo deseja publicar?',
                    prefixIcon: Icon(Icons.description_outlined),
                    border: OutlineInputBorder(),
                    alignLabelWithHint: true,
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: _isSaving ? null : _addTopic,
                    icon: const Icon(Icons.add),
                    label: const Text('Adicionar tema'),
                  ),
                ),
                if (_isSaving) ...[
                  const SizedBox(height: 12),
                  const LinearProgressIndicator(),
                  const SizedBox(height: 4),
                  const Text(
                    'Salvando alterações...',
                    textAlign: TextAlign.center,
                  ),
                ],
                const SizedBox(height: 28),
                Text(
                  'Temas cadastrados: ${_topics.length}',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text('Temas ativos: $activeCount'),
                const SizedBox(height: 12),
                if (_topics.isEmpty)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(20),
                      child: Column(
                        children: [
                          Icon(Icons.topic_outlined, size: 40),
                          SizedBox(height: 12),
                          Text('Nenhum tema cadastrado ainda.'),
                          SizedBox(height: 4),
                          Text(
                            'Adicione seu primeiro tema acima.',
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  )
                else
                  ..._topics.asMap().entries.map((entry) {
                    final index = entry.key;
                    final topic = entry.value;
                    final name = topic['name'] as String;
                    final description =
                        topic['description'] as String? ?? '';
                    final active = topic['active'] == true;

                    return Card(
                      child: ListTile(
                        leading: Icon(
                          active
                              ? Icons.label_outline
                              : Icons.label_off_outlined,
                        ),
                        title: Text(name),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (description.isNotEmpty) ...[
                              const SizedBox(height: 4),
                              Text(description),
                            ],
                            const SizedBox(height: 6),
                            Text(
                              active ? 'Ativo' : 'Inativo',
                              style: TextStyle(
                                color: active
                                    ? Colors.green
                                    : Colors.grey,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                        isThreeLine: description.isNotEmpty,
                        trailing: PopupMenuButton<String>(
                          tooltip: 'Opções do tema',
                          onSelected: (value) {
                            if (value == 'edit') {
                              _editTopic(index);
                            } else if (value == 'toggle') {
                              _toggleTopic(index, !active);
                            } else if (value == 'delete') {
                              _removeTopic(index);
                            }
                          },
                          itemBuilder: (context) => [
                            const PopupMenuItem(
                              value: 'edit',
                              child: Row(
                                children: [
                                  Icon(Icons.edit_outlined),
                                  SizedBox(width: 8),
                                  Text('Editar tema'),
                                ],
                              ),
                            ),
                            PopupMenuItem(
                              value: 'toggle',
                              child: Row(
                                children: [
                                  Icon(
                                    active
                                        ? Icons.visibility_off_outlined
                                        : Icons.visibility_outlined,
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    active
                                        ? 'Desativar tema'
                                        : 'Ativar tema',
                                  ),
                                ],
                              ),
                            ),
                            const PopupMenuItem(
                              value: 'delete',
                              child: Row(
                                children: [
                                  Icon(Icons.delete_outline),
                                  SizedBox(width: 8),
                                  Text('Excluir tema'),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }),
              ],
            ),
    );
  }
}
