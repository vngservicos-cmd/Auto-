import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/content_generation_service.dart';
import '../services/api_provider_adapter.dart';

class ContentGeneratorScreen extends StatefulWidget {
  const ContentGeneratorScreen({super.key});

  @override
  State<ContentGeneratorScreen> createState() =>
      _ContentGeneratorScreenState();
}

class _ContentGeneratorScreenState
    extends State<ContentGeneratorScreen> {
  static const String _topicsStorageKey = 'content_topics_v2';

  final TextEditingController _audienceController =
      TextEditingController();

  final TextEditingController _objectiveController =
      TextEditingController();

  final TextEditingController _resultController =
      TextEditingController();

  final ContentGenerationService _generationService =
      ContentGenerationService();

  List<Map<String, dynamic>> _topics = [];
  String? _selectedTopicName;

  String _format = 'Legenda para rede social';
  String _tone = 'Natural e envolvente';

  bool _loading = true;
  bool _generating = false;

  final List<String> _formats = const [
    'Legenda para rede social',
    'Publicação completa',
    'Roteiro para vídeo',
    'Lista de ideias',
  ];

  final List<String> _tones = const [
    'Natural e envolvente',
    'Profissional',
    'Divertido',
    'Educativo',
    'Inspirador',
    'Persuasivo',
  ];

  @override
  void initState() {
    super.initState();
    _loadTopics();
  }

  Future<void> _loadTopics() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final storedData = prefs.getString(_topicsStorageKey);

      if (storedData != null && storedData.isNotEmpty) {
        final decoded = jsonDecode(storedData);

        if (decoded is List) {
          _topics = decoded
              .whereType<Map>()
              .map(
                (item) => Map<String, dynamic>.from(item),
              )
              .where((topic) {
                final name = topic['name'];
                return topic['active'] == true &&
                    name is String &&
                    name.trim().isNotEmpty;
              })
              .toList();
        }
      }
    } catch (_) {
      _topics = [];
    }

    if (!mounted) return;

    setState(() {
      _selectedTopicName = _topics.isNotEmpty
          ? _topics.first['name'] as String
          : null;

      _loading = false;
    });
  }

  void _prepareDraft() {
    if (_selectedTopicName == null) {
      _showMessage(
        'Cadastre e ative um tema antes de continuar.',
      );
      return;
    }

    final topic = _topics.firstWhere(
      (item) => item['name'] == _selectedTopicName,
    );

    final description =
        (topic['description'] as String? ?? '').trim();

    final audience = _audienceController.text.trim();
    final objective = _objectiveController.text.trim();

    final buffer = StringBuffer()
      ..writeln('TEMA: $_selectedTopicName');

    if (description.isNotEmpty) {
      buffer.writeln('DESCRIÇÃO: $description');
    }

    buffer
      ..writeln('FORMATO: $_format')
      ..writeln('TOM: $_tone')
      ..writeln(
        'PÚBLICO-ALVO: ${audience.isEmpty ? "A definir" : audience}',
      )
      ..writeln(
        'OBJETIVO: ${objective.isEmpty ? "A definir" : objective}',
      )
      ..writeln()
      ..writeln('RASCUNHO DE SOLICITAÇÃO')
      ..writeln(
        'Crie um conteúdo no formato "$_format" sobre '
        '"$_selectedTopicName", usando um tom $_tone.',
      );

    if (description.isNotEmpty) {
      buffer.writeln('Considere esta descrição: $description');
    }

    if (audience.isNotEmpty) {
      buffer.writeln('Público-alvo: $audience.');
    }

    if (objective.isNotEmpty) {
      buffer.writeln('Objetivo: $objective.');
    }

    buffer
      ..writeln()
      ..writeln(
        'Este é um rascunho de solicitação. '
        'Use o botão "Gerar com IA" para solicitar o conteúdo final.',
      );

    setState(() {
      _resultController.text = buffer.toString();
    });
  }

  String _friendlyErrorMessage(Object error) {
    if (error is ApiProviderException) {
      return error.message;
    }

    final message = error.toString().replaceFirst(
          'Exception: ',
          '',
        );

    if (message.trim().isEmpty) {
      return 'Ocorreu uma falha inesperada durante a geração.';
    }

    return message;
  }

  Future<void> _generateContent() async {
    if (_generating) return;

    if (_selectedTopicName == null) {
      _showMessage(
        'Cadastre e ative um tema antes de continuar.',
      );
      return;
    }

    final topic = _topics.firstWhere(
      (item) => item['name'] == _selectedTopicName,
    );

    final description =
        (topic['description'] as String? ?? '').trim();

    final audience = _audienceController.text.trim();
    final objective = _objectiveController.text.trim();

    final prompt = '''
Crie um conteúdo de qualidade em português brasileiro.

Tema: $_selectedTopicName

Descrição do tema: ${description.isEmpty ? 'Não informada' : description}

Formato: $_format

Tom: $_tone

Público-alvo: ${audience.isEmpty ? 'Não especificado' : audience}

Objetivo: ${objective.isEmpty ? 'Não especificado' : objective}

Instruções:

- Entregue o conteúdo final, pronto para revisão e uso.
- Respeite o formato e o tom selecionados.
- Considere o público-alvo e o objetivo informados.
- Não inclua explicações sobre o processo de geração.
''';

    setState(() {
      _generating = true;
    });

    try {
      final texto = await _generationService.generate(prompt);

      if (!mounted) return;

      setState(() {
        _resultController.text = texto;
      });

      _showMessage('Conteúdo gerado com sucesso!');
    } catch (error) {
      if (!mounted) return;

      final mensagem = _friendlyErrorMessage(error);

      _showMessage(
        'Não foi possível gerar o conteúdo: $mensagem',
      );
    } finally {
      if (mounted) {
        setState(() {
          _generating = false;
        });
      }
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _copyResult() async {
    final text = _resultController.text.trim();

    if (text.isEmpty) {
      _showMessage(
        'Prepare um rascunho ou gere um conteúdo antes de copiar.',
      );
      return;
    }

    await Clipboard.setData(
      ClipboardData(text: text),
    );

    if (mounted) {
      _showMessage('Texto copiado.');
    }
  }

  @override
  void dispose() {
    _audienceController.dispose();
    _objectiveController.dispose();
    _resultController.dispose();
    _generationService.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gerador de Conteúdo'),
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                const Text(
                  'Prepare seu conteúdo',
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Configure os detalhes para preparar sua '
                  'solicitação de criação de conteúdo.',
                ),
                const SizedBox(height: 24),

                const Text(
                  'Tema ativo',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 8),

                if (_topics.isEmpty)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(16),
                      child: Text(
                        'Nenhum tema ativo encontrado. '
                        'Volte à tela Temas de conteúdo para '
                        'cadastrar ou ativar um tema.',
                      ),
                    ),
                  )
                else
                  DropdownButtonFormField<String>(
                    initialValue: _selectedTopicName,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.topic_outlined),
                    ),
                    items: _topics.map((topic) {
                      final name = topic['name'] as String? ?? '';

                      return DropdownMenuItem<String>(
                        value: name,
                        child: Text(
                          name,
                          overflow: TextOverflow.ellipsis,
                        ),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedTopicName = value;
                      });
                    },
                  ),

                const SizedBox(height: 20),

                DropdownButtonFormField<String>(
                  initialValue: _format,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Formato do conteúdo',
                    border: OutlineInputBorder(),
                  ),
                  items: _formats.map((format) {
                    return DropdownMenuItem<String>(
                      value: format,
                      child: Text(format),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _format = value;
                      });
                    }
                  },
                ),

                const SizedBox(height: 16),

                DropdownButtonFormField<String>(
                  initialValue: _tone,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Tom do conteúdo',
                    border: OutlineInputBorder(),
                  ),
                  items: _tones.map((tone) {
                    return DropdownMenuItem<String>(
                      value: tone,
                      child: Text(tone),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _tone = value;
                      });
                    }
                  },
                ),

                const SizedBox(height: 16),

                TextField(
                  controller: _audienceController,
                  decoration: const InputDecoration(
                    labelText: 'Público-alvo (opcional)',
                    hintText: 'Ex.: pequenos empreendedores',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.people_outline),
                  ),
                ),

                const SizedBox(height: 16),

                TextField(
                  controller: _objectiveController,
                  minLines: 2,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'Objetivo do conteúdo (opcional)',
                    hintText: 'Ex.: ensinar, informar ou divulgar',
                    border: OutlineInputBorder(),
                    alignLabelWithHint: true,
                  ),
                ),

                const SizedBox(height: 20),

                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: _topics.isEmpty
                        ? null
                        : _prepareDraft,
                    icon: const Icon(Icons.edit_note),
                    label: const Text('Preparar rascunho'),
                  ),
                ),

                const SizedBox(height: 12),

                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: _topics.isEmpty || _generating
                        ? null
                        : _generateContent,
                    icon: _generating
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                            ),
                          )
                        : const Icon(Icons.auto_awesome),
                    label: Text(
                      _generating
                          ? 'Gerando conteúdo...'
                          : 'Gerar com IA',
                    ),
                  ),
                ),

                const SizedBox(height: 28),

                const Text(
                  'Resultado / rascunho',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 12),

                TextField(
                  controller: _resultController,
                  minLines: 8,
                  maxLines: 18,
                  decoration: const InputDecoration(
                    hintText:
                        'O conteúdo gerado ou o rascunho aparecerá aqui. '
                        'Você poderá editá-lo.',
                    border: OutlineInputBorder(),
                    alignLabelWithHint: true,
                  ),
                ),

                const SizedBox(height: 12),

                OutlinedButton.icon(
                  onPressed: _copyResult,
                  icon: const Icon(Icons.copy),
                  label: const Text('Copiar texto'),
                ),

                const SizedBox(height: 12),

                const Text(
                  'A geração utiliza as contas e credenciais cadastradas '
                  'na Central de APIs. O conteúdo produzido por inteligência '
                  'artificial deve ser revisado antes da publicação.',
                  style: TextStyle(fontSize: 12),
                ),
              ],
            ),
    );
  }
}
