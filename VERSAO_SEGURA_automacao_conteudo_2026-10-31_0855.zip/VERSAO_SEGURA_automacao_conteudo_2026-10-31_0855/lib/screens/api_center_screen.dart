import 'package:flutter/material.dart';

import '../models/api_provider.dart';
import '../services/api_provider_registry.dart';
import '../services/api_provider_credentials_storage.dart';
import '../services/api_model_catalog.dart';
import '../services/api_custom_model_storage.dart';
import '../services/api_provider_adapter.dart';
import '../services/api_provider_sync_service.dart';
import '../services/api_provider_sync_queue.dart';

class ApiCenterScreen extends StatefulWidget {
  const ApiCenterScreen({super.key});

  @override
  State<ApiCenterScreen> createState() => _ApiCenterScreenState();
}

class _ApiCenterScreenState extends State<ApiCenterScreen> {
  final ApiProviderRegistry _registry = ApiProviderRegistry();
  final ApiProviderCredentialsStorage _credentials =
      ApiProviderCredentialsStorage();
  final ApiProviderSyncQueue _syncQueue = ApiProviderSyncQueue();

  late final ApiProviderSyncService _syncService =
      ApiProviderSyncService(
        registry: _registry,
        syncQueue: _syncQueue,
      );

  bool _syncing = false;

  List<ApiProvider> _providers = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadProviders();
  }

  Future<void> _loadProviders() async {
    final providers = await _registry.getAll();
    if (!mounted) return;

    setState(() {
      _providers = providers;
      _loading = false;
    });
  }

  Future<void> _openForm([ApiProvider? existing]) async {
    final result = await showDialog<_ApiProviderFormResult>(
      context: context,
      builder: (dialogContext) => _ApiProviderDialog(existing: existing),
    );

    if (result == null) return;

    try {
      // Grava a credencial antes do cadastro para evitar salvar uma conta
      // nova sem sua chave quando o armazenamento seguro falhar.
      if (result.apiKey.trim().isNotEmpty) {
        await _credentials.saveCredential(
          accountId: result.provider.id,
          apiKey: result.apiKey.trim(),
        );
      }

      final success = existing == null
          ? await _registry.add(result.provider)
          : await _registry.update(result.provider);

      if (!success) {
        if (!mounted) return;
        _showMessage('NÃƒÂ£o foi possÃƒÂ­vel salvar. Verifique o cadastro.');
        return;
      }

      if (!mounted) return;
      await _loadProviders();

      if (!mounted) return;
      _showMessage(
        existing == null
            ? 'API cadastrada com sucesso.'
            : 'API atualizada com sucesso.',
      );
    } catch (_) {
      if (!mounted) return;
      _showMessage('NÃƒÂ£o foi possÃƒÂ­vel salvar a API ou sua credencial.');
    }
  }

  Future<void> _toggleActive(ApiProvider provider) async {
    final updated = provider.copyWith(active: !provider.active);
    final success = await _registry.update(updated);

    if (!mounted) return;

    if (success) {
      await _loadProviders();
      if (!mounted) return;
      _showMessage(updated.active ? 'API ativada.' : 'API desativada.');
    }
  }

  Future<void> _deleteProvider(ApiProvider provider) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Excluir API?'),
        content: Text(
          'Deseja excluir "${provider.name}" do cadastro '
          'e remover sua credencial armazenada? '
          'Essa aÃƒÂ§ÃƒÂ£o nÃƒÂ£o pode ser desfeita.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      final success = await _registry.remove(provider.id);

      if (!success) {
        if (!mounted) return;
        _showMessage('NÃƒÂ£o foi possÃƒÂ­vel excluir a API.');
        return;
      }

      await _credentials.deleteCredential(provider.id);

      if (!mounted) return;
      await _loadProviders();

      if (!mounted) return;
      _showMessage('API e credencial excluÃƒÂ­das.');
    } catch (_) {
      if (!mounted) return;
      _showMessage(
        'A API foi removida, mas nÃƒÂ£o foi possÃƒÂ­vel confirmar '
        'a remoÃƒÂ§ÃƒÂ£o da credencial.',
      );
    }
  }

  Future<void> _syncNow() async {
    if (_syncing) return;

    setState(() {
      _syncing = true;
    });

    try {
      final pendingBefore = await _syncQueue.getAll();

      if (pendingBefore.isEmpty) {
        if (mounted) {
          _showMessage('NÃ£o hÃ¡ operaÃ§Ãµes pendentes para sincronizar.');
        }
        return;
      }

      final synchronized = await _syncService.synchronize();
      final pendingAfter = await _syncQueue.getAll();

      if (!mounted) return;

      if (pendingAfter.isEmpty) {
        _showMessage(
          ' operaÃ§Ã£o(Ãµes) sincronizada(s) com sucesso.',
        );
      } else if (synchronized > 0) {
        _showMessage(
          ' operaÃ§Ã£o(Ãµes) sincronizada(s). '
          ' continuam pendentes.',
        );
      } else {
        _showMessage(
          'Nenhuma operaÃ§Ã£o foi concluÃ­da. '
          ' continuam pendentes. '
          'Verifique o servidor selecionado e a conexÃ£o.',
        );
      }
    } catch (_) {
      if (mounted) {
        _showMessage(
          'NÃ£o foi possÃ­vel sincronizar. '
          'Verifique o servidor selecionado e a conexÃ£o.',
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _syncing = false;
        });
      }
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  IconData _iconFor(String capability) {
    switch (capability) {
      case 'image':
        return Icons.image_outlined;
      case 'video':
        return Icons.video_library_outlined;
      case 'audio':
        return Icons.graphic_eq;
      default:
        return Icons.text_fields;
    }
  }

  String _capabilityName(String capability) {
    switch (capability) {
      case 'image':
        return 'Imagem';
      case 'video':
        return 'VÃƒÂ­deo';
      case 'audio':
        return 'ÃƒÂudio';
      default:
        return 'Texto';
    }
  }

  String _formatDate(DateTime date) {
    final day = date.day.toString().padLeft(2, '0');
    final month = date.month.toString().padLeft(2, '0');
    return '$day/$month/${date.year}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Central de APIs'),
        actions: [
          IconButton(
            tooltip: 'Sincronizar agora',
            onPressed: _syncing ? null : _syncNow,
            icon: _syncing
                ? const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.sync),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openForm(),
        icon: const Icon(Icons.add),
        label: const Text('Adicionar API'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _providers.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.api, size: 64),
                    const SizedBox(height: 16),
                    Text(
                      'Nenhuma API cadastrada',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Cadastre serviÃƒÂ§os de texto, imagem, vÃƒÂ­deo '
                      'ou ÃƒÂ¡udio para organizar suas opÃƒÂ§ÃƒÂµes.',
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    FilledButton.icon(
                      onPressed: () => _openForm(),
                      icon: const Icon(Icons.add),
                      label: const Text('Cadastrar primeira API'),
                    ),
                  ],
                ),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
              itemCount: _providers.length,
              itemBuilder: (context, index) {
                final provider = _providers[index];
                final selectedModel = provider.modelId == null
                    ? null
                    : ApiModelCatalog.findById(provider.modelId!);

                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ListTile(
                    leading: CircleAvatar(
                      child: Icon(_iconFor(provider.capability)),
                    ),
                    title: Text(provider.name),
                    subtitle: Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(provider.provider),
                          if (selectedModel != null)
                            Text('Modelo: ${selectedModel.name}'),
                          if (provider.modelId != null && selectedModel == null)
                            Text('Modelo: ${provider.modelId}'),
                          const SizedBox(height: 4),
                          Text(
                            '${_capabilityName(provider.capability)}'
                            ' Ã¢â‚¬Â¢ ${provider.isFree ? "Gratuita" : "Paga"}'
                            '${provider.hasFreeTrial ? " Ã¢â‚¬Â¢ Teste grÃƒÂ¡tis" : ""}',
                          ),
                          Text(
                            'Prioridade: ${provider.priority}'
                            ' Ã¢â‚¬Â¢ ${provider.active ? "Ativa" : "Desativada"}',
                          ),
                          if (provider.trialEndsAt != null)
                            Text(
                              'Fim do teste: '
                              '${_formatDate(provider.trialEndsAt!)}',
                            ),
                          if (provider.websiteUrl != null)
                            Text(
                              provider.websiteUrl!,
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                          if (provider.notes != null)
                            Text(
                              provider.notes!,
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                        ],
                      ),
                    ),
                    trailing: PopupMenuButton<String>(
                      tooltip: 'OpÃƒÂ§ÃƒÂµes da API',
                      onSelected: (value) {
                        switch (value) {
                          case 'toggle':
                            _toggleActive(provider);
                            break;
                          case 'edit':
                            _openForm(provider);
                            break;
                          case 'delete':
                            _deleteProvider(provider);
                            break;
                        }
                      },
                      itemBuilder: (_) => [
                        PopupMenuItem(
                          value: 'toggle',
                          child: Text(provider.active ? 'Desativar' : 'Ativar'),
                        ),
                        const PopupMenuItem(
                          value: 'edit',
                          child: Text('Editar'),
                        ),
                        const PopupMenuItem(
                          value: 'delete',
                          child: Text('Excluir'),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class _ApiProviderFormResult {
  final ApiProvider provider;
  final String apiKey;

  const _ApiProviderFormResult({required this.provider, required this.apiKey});
}

class _ApiProviderDialog extends StatefulWidget {
  final ApiProvider? existing;

  const _ApiProviderDialog({this.existing});

  @override
  State<_ApiProviderDialog> createState() => _ApiProviderDialogState();
}

class _ApiProviderDialogState extends State<_ApiProviderDialog> {
  final _formKey = GlobalKey<FormState>();

  final ApiProviderCredentialsStorage _credentials =
      ApiProviderCredentialsStorage();
  final ApiCustomModelStorage _customModelStorage = ApiCustomModelStorage();
  final ApiProviderAdapterRegistry _adapterRegistry =
      ApiProviderAdapterRegistry();

  late final TextEditingController _nameController;
  late final TextEditingController _providerController;
  late final TextEditingController _websiteController;
  late final TextEditingController _notesController;
  late final TextEditingController _apiKeyController;

  late final String _accountId;

  late String _capability;
  late bool _isFree;
  late bool _hasFreeTrial;
  late bool _active;
  late int _priority;
  late DateTime? _trialEndsAt;

  String? _selectedModelId;
  List<ApiModel> _availableModels = [];

  bool _obscureKey = true;
  bool _loadingCredential = false;
  bool _loadingModels = false;
  bool _testing = false;
  bool _connectionTestPassed = false;

  String? _testMessage;
  int _modelLoadRequest = 0;

  @override
  void initState() {
    super.initState();

    final existing = widget.existing;
    _accountId = existing?.id ?? 'api_${DateTime.now().microsecondsSinceEpoch}';

    _nameController = TextEditingController(text: existing?.name ?? '');
    _providerController = TextEditingController(text: existing?.provider ?? '');
    _websiteController = TextEditingController(
      text: existing?.websiteUrl ?? '',
    );
    _notesController = TextEditingController(text: existing?.notes ?? '');
    _apiKeyController = TextEditingController();

    _capability = existing?.capability ?? 'text';
    _isFree = existing?.isFree ?? true;
    _hasFreeTrial = existing?.hasFreeTrial ?? false;
    _active = existing?.active ?? true;
    _priority = existing?.priority ?? 1;
    _trialEndsAt = existing?.trialEndsAt;
    _selectedModelId = existing?.modelId;

    if (existing != null) {
      _loadCredential();
    }

    _loadModels();
  }

  bool get _isGoogleProvider {
    final provider = _providerController.text.trim().toLowerCase();
    return provider.contains('google') || provider.contains('gemini');
  }

  String _catalogProviderName(String provider) {
    final normalized = provider.trim().toLowerCase();
    if (normalized.contains('google') || normalized.contains('gemini')) {
      return 'Google';
    }
    return provider.trim();
  }

  Future<void> _loadCredential() async {
    if (mounted) {
      setState(() {
        _loadingCredential = true;
      });
    }

    try {
      final key = await _credentials.readCredential(_accountId);
      if (!mounted) return;
      _apiKeyController.text = key ?? '';
    } catch (_) {
      if (!mounted) return;
      _testMessage = 'NÃƒÂ£o foi possÃƒÂ­vel carregar a credencial segura.';
    }

    if (!mounted) return;
    setState(() {
      _loadingCredential = false;
    });
  }

  Future<void> _loadModels() async {
    final request = ++_modelLoadRequest;
    if (!mounted) return;

    setState(() {
      _loadingModels = true;
    });

    try {
      final provider = _providerController.text.trim();
      final catalogProvider = _catalogProviderName(provider);

      final officialModels = ApiModelCatalog.getActiveModels(catalogProvider);
      final customModels = await _customModelStorage.getByProvider(provider);

      if (!mounted || request != _modelLoadRequest) return;

      final combined = <ApiModel>[...officialModels, ...customModels];

      setState(() {
        _availableModels = combined;

        if (_selectedModelId == null ||
            !combined.any((model) => model.id == _selectedModelId)) {
          final recommended = combined
              .where((model) => model.recommended)
              .toList();

          _selectedModelId = recommended.isNotEmpty
              ? recommended.first.id
              : null;
        }

        _loadingModels = false;
      });
    } catch (_) {
      if (!mounted || request != _modelLoadRequest) return;
      setState(() {
        _availableModels = [];
        _selectedModelId = null;
        _loadingModels = false;
        _testMessage = 'NÃƒÂ£o foi possÃƒÂ­vel carregar os modelos.';
      });
    }
  }

  @override
  void dispose() {
    _modelLoadRequest++;
    _nameController.dispose();
    _providerController.dispose();
    _websiteController.dispose();
    _notesController.dispose();
    _apiKeyController.dispose();
    _adapterRegistry.dispose();
    super.dispose();
  }

  Future<void> _chooseTrialDate() async {
    final now = DateTime.now();
    final selected = await showDatePicker(
      context: context,
      initialDate: _trialEndsAt ?? now.add(const Duration(days: 30)),
      firstDate: DateTime(now.year - 1),
      lastDate: DateTime(now.year + 10),
    );

    if (selected != null && mounted) {
      setState(() {
        _trialEndsAt = selected;
      });
    }
  }

  Future<void> _addCustomModel() async {
    final provider = _providerController.text.trim();

    if (provider.isEmpty) {
      setState(() {
        _testMessage = 'Informe o fornecedor antes de adicionar um modelo.';
      });
      return;
    }

    final result = await showDialog<ApiModel>(
      context: context,
      builder: (_) =>
          _CustomModelDialog(provider: provider, capability: _capability),
    );

    if (result == null) return;

    try {
      final saved = await _customModelStorage.add(result);
      if (!mounted) return;

      if (!saved) {
        setState(() {
          _testMessage =
              'JÃƒÂ¡ existe um modelo com esse ID para esse fornecedor.';
        });
        return;
      }

      await _loadModels();
      if (!mounted) return;

      setState(() {
        _selectedModelId = result.id;
        _testMessage = 'Modelo personalizado adicionado.';
        _connectionTestPassed = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _testMessage = 'NÃƒÂ£o foi possÃƒÂ­vel salvar o modelo personalizado.';
      });
    }
  }

  Future<void> _testConnection() async {
    if (_apiKeyController.text.trim().isEmpty) {
      setState(() {
        _testMessage = 'Informe a chave antes de testar.';
        _connectionTestPassed = false;
      });
      return;
    }

    if (!_isGoogleProvider) {
      setState(() {
        _testMessage =
            'O teste automÃƒÂ¡tico disponÃƒÂ­vel neste momento '
            'ÃƒÂ© para Google Gemini.';
        _connectionTestPassed = false;
      });
      return;
    }

    if (_selectedModelId == null || _selectedModelId!.trim().isEmpty) {
      setState(() {
        _testMessage = 'Selecione um modelo antes de testar.';
        _connectionTestPassed = false;
      });
      return;
    }

    setState(() {
      _testing = true;
      _testMessage = null;
      _connectionTestPassed = false;
    });

    try {
      final adapter = _adapterRegistry.find('google');
      if (adapter == null) {
        throw Exception('Adaptador Google nÃƒÂ£o encontrado.');
      }

      final result = await adapter.testConnection(
        apiKey: _apiKeyController.text.trim(),
        modelId: _selectedModelId!,
      );

      if (!mounted) return;
      setState(() {
        _testing = false;
        _connectionTestPassed = result.success;
        _testMessage = result.message;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _testing = false;
        _connectionTestPassed = false;
        _testMessage = 'NÃƒÂ£o foi possÃƒÂ­vel testar a conexÃƒÂ£o.';
      });
    }
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;

    final existing = widget.existing;
    final provider = ApiProvider(
      id: _accountId,
      name: _nameController.text.trim(),
      provider: _providerController.text.trim(),
      capability: _capability,
      connectionType: existing?.connectionType ?? 'manual',
      modelId: _selectedModelId,
      active: _active,
      isFree: _isFree,
      hasFreeTrial: _hasFreeTrial,
      priority: _priority,
      trialEndsAt: _hasFreeTrial ? _trialEndsAt : null,
      trialDays: existing?.trialDays,
      quotaRenewsAt: existing?.quotaRenewsAt,
      websiteUrl: _websiteController.text.trim().isEmpty
          ? null
          : _websiteController.text.trim(),
      notes: _notesController.text.trim().isEmpty
          ? null
          : _notesController.text.trim(),
      createdAt: existing?.createdAt ?? DateTime.now(),
    );

    Navigator.pop(
      context,
      _ApiProviderFormResult(
        provider: provider,
        apiKey: _apiKeyController.text.trim(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.existing == null ? 'Adicionar API' : 'Editar API'),
      content: SizedBox(
        width: 440,
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Nome da API ou serviÃƒÂ§o',
                    hintText: 'Ex.: Gemini pessoal',
                  ),
                  validator: (value) => value == null || value.trim().isEmpty
                      ? 'Informe o nome do serviÃƒÂ§o.'
                      : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _providerController,
                  decoration: const InputDecoration(
                    labelText: 'Empresa ou fornecedor',
                    hintText: 'Ex.: Google',
                  ),
                  onChanged: (_) {
                    setState(() {
                      _selectedModelId = null;
                      _availableModels = [];
                      _testMessage = null;
                      _connectionTestPassed = false;
                    });
                    _loadModels();
                  },
                  validator: (value) => value == null || value.trim().isEmpty
                      ? 'Informe o fornecedor.'
                      : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _apiKeyController,
                  obscureText: _obscureKey,
                  enableSuggestions: false,
                  autocorrect: false,
                  decoration: InputDecoration(
                    labelText: 'Chave de API',
                    hintText: 'Cole sua chave aqui',
                    helperText: widget.existing == null
                        ? 'A chave serÃƒÂ¡ armazenada no dispositivo.'
                        : 'Chave protegida; substitua se necessÃƒÂ¡rio.',
                    suffixIcon: IconButton(
                      tooltip: _obscureKey ? 'Mostrar chave' : 'Ocultar chave',
                      icon: Icon(
                        _obscureKey ? Icons.visibility : Icons.visibility_off,
                      ),
                      onPressed: () {
                        setState(() {
                          _obscureKey = !_obscureKey;
                        });
                      },
                    ),
                  ),
                ),
                if (_loadingCredential)
                  const Padding(
                    padding: EdgeInsets.all(8),
                    child: LinearProgressIndicator(),
                  ),
                const SizedBox(height: 12),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Modelo de IA',
                    style: Theme.of(context).textTheme.titleSmall,
                  ),
                ),
                const SizedBox(height: 8),
                if (_loadingModels)
                  const LinearProgressIndicator()
                else if (_availableModels.isEmpty)
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Nenhum modelo cadastrado para este fornecedor.',
                    ),
                  )
                else
                  DropdownButtonFormField<String>(
                    initialValue:
                        _availableModels.any(
                          (model) => model.id == _selectedModelId,
                        )
                        ? _selectedModelId
                        : null,
                    decoration: const InputDecoration(
                      labelText: 'Selecione o modelo',
                    ),
                    items: _availableModels.map((model) {
                      return DropdownMenuItem<String>(
                        value: model.id,
                        child: Text(
                          '${model.name}'
                          '${model.recommended ? " Ã¢â‚¬Â¢ Recomendado" : ""}',
                          overflow: TextOverflow.ellipsis,
                        ),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedModelId = value;
                        _testMessage = null;
                        _connectionTestPassed = false;
                      });
                    },
                  ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: _loadingModels ? null : _addCustomModel,
                    icon: const Icon(Icons.add),
                    label: const Text('Adicionar modelo personalizado'),
                  ),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: _testing || _loadingCredential || _loadingModels
                        ? null
                        : _testConnection,
                    icon: _testing
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.wifi_tethering),
                    label: Text(
                      _testing ? 'Testando conexÃƒÂ£o...' : 'Testar conexÃƒÂ£o',
                    ),
                  ),
                ),
                if (_testMessage != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(
                          _connectionTestPassed
                              ? Icons.check_circle
                              : Icons.info_outline,
                          color: _connectionTestPassed ? Colors.green : null,
                        ),
                        const SizedBox(width: 8),
                        Expanded(child: Text(_testMessage!)),
                      ],
                    ),
                  ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  initialValue: _capability,
                  decoration: const InputDecoration(
                    labelText: 'Tipo de serviÃƒÂ§o',
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: 'text',
                      child: Text('GeraÃƒÂ§ÃƒÂ£o de texto'),
                    ),
                    DropdownMenuItem(
                      value: 'image',
                      child: Text('GeraÃƒÂ§ÃƒÂ£o de imagens'),
                    ),
                    DropdownMenuItem(
                      value: 'video',
                      child: Text('GeraÃƒÂ§ÃƒÂ£o de vÃƒÂ­deos'),
                    ),
                    DropdownMenuItem(
                      value: 'audio',
                      child: Text('ÃƒÂudio e voz'),
                    ),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _capability = value;
                      });
                    }
                  },
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<int>(
                  initialValue: _priority,
                  decoration: const InputDecoration(
                    labelText: 'Prioridade de uso',
                  ),
                  items: List.generate(
                    10,
                    (index) => DropdownMenuItem(
                      value: index + 1,
                      child: Text('Prioridade ${index + 1}'),
                    ),
                  ),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _priority = value;
                      });
                    }
                  },
                ),
                const SizedBox(height: 8),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('ServiÃƒÂ§o gratuito'),
                  value: _isFree,
                  onChanged: (value) {
                    setState(() {
                      _isFree = value;
                    });
                  },
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Possui teste grÃƒÂ¡tis por prazo'),
                  value: _hasFreeTrial,
                  onChanged: (value) {
                    setState(() {
                      _hasFreeTrial = value;
                      if (!value) _trialEndsAt = null;
                    });
                  },
                ),
                if (_hasFreeTrial)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Data de fim do teste'),
                    subtitle: Text(
                      _trialEndsAt == null
                          ? 'Data nÃƒÂ£o informada'
                          : '${_trialEndsAt!.day.toString().padLeft(2, '0')}/'
                                '${_trialEndsAt!.month.toString().padLeft(2, '0')}/'
                                '${_trialEndsAt!.year}',
                    ),
                    trailing: const Icon(Icons.calendar_month),
                    onTap: _chooseTrialDate,
                  ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('API ativa'),
                  value: _active,
                  onChanged: (value) {
                    setState(() {
                      _active = value;
                    });
                  },
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _websiteController,
                  decoration: const InputDecoration(
                    labelText: 'Site oficial (opcional)',
                  ),
                  keyboardType: TextInputType.url,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _notesController,
                  decoration: const InputDecoration(
                    labelText: 'ObservaÃƒÂ§ÃƒÂµes (opcional)',
                  ),
                  maxLines: 2,
                ),
              ],
            ),
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancelar'),
        ),
        FilledButton(
          onPressed: _loadingCredential ? null : _save,
          child: const Text('Salvar'),
        ),
      ],
    );
  }
}

class _CustomModelDialog extends StatefulWidget {
  final String provider;
  final String capability;

  const _CustomModelDialog({required this.provider, required this.capability});

  @override
  State<_CustomModelDialog> createState() => _CustomModelDialogState();
}

class _CustomModelDialogState extends State<_CustomModelDialog> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController _nameController;
  late final TextEditingController _idController;

  late String _capability;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController();
    _idController = TextEditingController();
    _capability = widget.capability;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _idController.dispose();
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;

    final model = ApiModel(
      id: _idController.text.trim(),
      name: _nameController.text.trim(),
      provider: widget.provider,
      capability: _capability,
    );

    Navigator.pop(context, model);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Adicionar modelo'),
      content: SizedBox(
        width: 400,
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Nome de exibiÃƒÂ§ÃƒÂ£o',
                    hintText: 'Ex.: Meu modelo rÃƒÂ¡pido',
                  ),
                  validator: (value) => value == null || value.trim().isEmpty
                      ? 'Informe o nome do modelo.'
                      : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _idController,
                  decoration: const InputDecoration(
                    labelText: 'ID tÃƒÂ©cnico do modelo',
                    hintText: 'Ex.: nome-do-modelo',
                    helperText: 'Use o ID exatamente como fornecido pela API.',
                  ),
                  validator: (value) => value == null || value.trim().isEmpty
                      ? 'Informe o ID tÃƒÂ©cnico.'
                      : null,
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  initialValue: _capability,
                  decoration: const InputDecoration(labelText: 'Capacidade'),
                  items: const [
                    DropdownMenuItem(value: 'text', child: Text('Texto')),
                    DropdownMenuItem(value: 'image', child: Text('Imagem')),
                    DropdownMenuItem(value: 'video', child: Text('VÃƒÂ­deo')),
                    DropdownMenuItem(value: 'audio', child: Text('ÃƒÂudio')),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _capability = value;
                      });
                    }
                  },
                ),
                const SizedBox(height: 12),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text('Fornecedor: ${widget.provider}'),
                ),
              ],
            ),
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancelar'),
        ),
        FilledButton(onPressed: _save, child: const Text('Adicionar')),
      ],
    );
  }
}


