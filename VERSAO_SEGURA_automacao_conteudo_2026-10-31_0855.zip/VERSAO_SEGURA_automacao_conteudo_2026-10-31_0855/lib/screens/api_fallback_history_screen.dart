
import 'package:flutter/material.dart';

import '../models/api_fallback_event.dart';
import '../services/api_fallback_history_service.dart';

class ApiFallbackHistoryScreen extends StatefulWidget {
  const ApiFallbackHistoryScreen({super.key});

  @override
  State<ApiFallbackHistoryScreen> createState() =>
      _ApiFallbackHistoryScreenState();
}

class _ApiFallbackHistoryScreenState
    extends State<ApiFallbackHistoryScreen> {
  final ApiFallbackHistoryService _historyService =
      ApiFallbackHistoryService();

  List<ApiFallbackEvent> _events = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    if (mounted) {
      setState(() {
        _loading = true;
      });
    }

    try {
      final events = await _historyService.getAll();

      if (!mounted) return;

      setState(() {
        _events = events;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;

      setState(() {
        _loading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Erro ao carregar o histórico: $error'),
        ),
      );
    }
  }

  Future<void> _clearHistory() async {
    if (_events.isEmpty) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Limpar histórico?'),
        content: const Text(
          'Todos os registros locais de simulações de falhas '
          'serão apagados. Essa ação não pode ser desfeita.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Limpar histórico'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      final success = await _historyService.clear();

      if (!mounted) return;

      if (success) {
        await _loadHistory();

        if (!mounted) return;

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Histórico apagado.'),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Não foi possível apagar o histórico.'),
          ),
        );
      }
    } catch (error) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Erro ao apagar o histórico: $error'),
        ),
      );
    }
  }

  String _capabilityName(String capability) {
    switch (capability) {
      case 'image':
        return 'Imagem';
      case 'video':
        return 'Vídeo';
      case 'audio':
        return 'Áudio';
      default:
        return 'Texto';
    }
  }

  String _actionName(String action) {
    switch (action) {
      case 'useFreeAlternative':
        return 'Alternativa gratuita selecionada';
      case 'requestPaidAuthorization':
        return 'Autorização para alternativa paga necessária';
      case 'noAlternativeAvailable':
        return 'Nenhuma alternativa disponível';
      default:
        return 'Resultado registrado';
    }
  }

  IconData _actionIcon(String action) {
    switch (action) {
      case 'useFreeAlternative':
        return Icons.check_circle_outline;
      case 'requestPaidAuthorization':
        return Icons.lock_outline;
      case 'noAlternativeAvailable':
        return Icons.error_outline;
      default:
        return Icons.history;
    }
  }

  String _formatDate(DateTime date) {
    final localDate = date.toLocal();

    final day = localDate.day.toString().padLeft(2, '0');
    final month = localDate.month.toString().padLeft(2, '0');
    final year = localDate.year.toString();
    final hour = localDate.hour.toString().padLeft(2, '0');
    final minute = localDate.minute.toString().padLeft(2, '0');

    return '$day/$month/$year às $hour:$minute';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Histórico de falhas de APIs'),
        actions: [
          IconButton(
            tooltip: 'Atualizar histórico',
            onPressed: _loading ? null : _loadHistory,
            icon: const Icon(Icons.refresh),
          ),
          IconButton(
            tooltip: 'Limpar histórico',
            onPressed: _loading || _events.isEmpty
                ? null
                : _clearHistory,
            icon: const Icon(Icons.delete_outline),
          ),
        ],
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : _events.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.history,
                          size: 56,
                          color: Theme.of(context)
                              .colorScheme
                              .secondary,
                        ),
                        const SizedBox(height: 16),
                        const Text(
                          'Nenhum registro encontrado.',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'Faça uma simulação na tela '
                          'Teste de alternativas para começar '
                          'a preencher este histórico.',
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 16),
                        FilledButton.icon(
                          onPressed: _loadHistory,
                          icon: const Icon(Icons.refresh),
                          label: const Text('Atualizar'),
                        ),
                      ],
                    ),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadHistory,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _events.length,
                    itemBuilder: (context, index) {
                      final event = _events[index];

                      return Card(
                        margin: const EdgeInsets.only(
                          bottom: 12,
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment.start,
                            children: [
                              Row(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  Icon(
                                    _actionIcon(event.action),
                                    size: 28,
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Text(
                                      _actionName(event.action),
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),
                              Text(
                                'Data: ${_formatDate(event.occurredAt)}',
                              ),
                              const SizedBox(height: 6),
                              Text(
                                'API que falhou: '
                                '${event.failedProviderName}',
                              ),
                              const SizedBox(height: 6),
                              Text(
                                'Tipo: '
                                '${_capabilityName(event.capability)}',
                              ),
                              const SizedBox(height: 6),
                              Text(
                                'Alternativa: '
                                '${event.alternativeProviderName ?? "Nenhuma"}',
                              ),
                              if (event.alternativeWasFree != null) ...[
                                const SizedBox(height: 6),
                                Text(
                                  'Custo cadastrado: '
                                  '${event.alternativeWasFree! ? "Gratuita" : "Paga"}',
                                ),
                              ],
                              if (event.message.isNotEmpty) ...[
                                const Divider(height: 24),
                                Text(event.message),
                              ],
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}
