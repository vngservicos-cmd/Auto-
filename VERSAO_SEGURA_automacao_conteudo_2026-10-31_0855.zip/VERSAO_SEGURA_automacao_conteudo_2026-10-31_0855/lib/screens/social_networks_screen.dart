
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/social_network.dart';
import '../services/social_network_registry.dart';

class SocialNetworksScreen extends StatefulWidget {
  const SocialNetworksScreen({super.key});

  @override
  State<SocialNetworksScreen> createState() =>
      _SocialNetworksScreenState();
}

class _SocialNetworksScreenState extends State<SocialNetworksScreen> {
  static const String _topicsKey = 'content_topics_v2';

  List<Map<String, dynamic>> _topics = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadTopics();
  }

  Future<void> _loadTopics() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getString(_topicsKey);

      if (saved != null) {
        final decoded = jsonDecode(saved) as List<dynamic>;
        _topics = decoded
            .map((item) => Map<String, dynamic>.from(item as Map))
            .toList();
      } else {
        final oldTopics = prefs.getStringList('content_topics') ?? [];
        _topics = oldTopics
            .map((name) => <String, dynamic>{
                  'name': name,
                  'description': '',
                  'active': true,
                })
            .toList();
      }
    } catch (_) {
      _topics = [];
    }

    if (!mounted) return;

    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final activeTopics =
        _topics.where((topic) => topic['active'] == true).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Redes sociais por tema'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : activeTopics.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.topic_outlined, size: 52),
                        const SizedBox(height: 12),
                        Text(
                          _topics.isEmpty
                              ? 'Nenhum tema cadastrado'
                              : 'Todos os temas estão inativos',
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'Cadastre um tema ou ative um tema existente '
                          'na tela Temas de conteúdo.',
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                )
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    const Text(
                      'Escolha um tema',
                      style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Cada tema terá suas próprias contas sociais.',
                    ),
                    const SizedBox(height: 20),
                    ...activeTopics.map((topic) {
                      final name = topic['name'] as String? ?? '';
                      final description =
                          topic['description'] as String? ?? '';

                      return Card(
                        child: ListTile(
                          leading: const CircleAvatar(
                            child: Icon(Icons.folder_outlined),
                          ),
                          title: Text(name),
                          subtitle: Text(
                            description.isEmpty
                                ? 'Gerencie as contas deste tema'
                                : description,
                          ),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => TopicSocialAccountsScreen(
                                  topicName: name,
                                ),
                              ),
                            );
                          },
                        ),
                      );
                    }),
                  ],
                ),
    );
  }
}

class TopicSocialAccountsScreen extends StatefulWidget {
  final String topicName;

  const TopicSocialAccountsScreen({
    super.key,
    required this.topicName,
  });

  @override
  State<TopicSocialAccountsScreen> createState() =>
      _TopicSocialAccountsScreenState();
}

class _TopicSocialAccountsScreenState
    extends State<TopicSocialAccountsScreen> {
  final List<Map<String, dynamic>> _accounts = [];
  final SocialNetworkRegistry _registry = SocialNetworkRegistry();

  List<SocialNetwork> _catalogNetworks = [];
  bool _isLoading = true;
  bool _isSaving = false;

  static const List<SocialNetwork> _builtInNetworks = [
    SocialNetwork(
      id: 'instagram',
      name: 'Instagram',
      iconName: 'instagram',
      connectorType: 'manual',
    ),
    SocialNetwork(
      id: 'facebook',
      name: 'Facebook',
      iconName: 'facebook',
      connectorType: 'manual',
    ),
    SocialNetwork(
      id: 'tiktok',
      name: 'TikTok',
      iconName: 'tiktok',
      connectorType: 'manual',
    ),
  ];

  String get _storageKey =>
      'social_accounts_topic_${base64Url.encode(utf8.encode(widget.topicName))}';

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getString(_storageKey);

      if (saved != null) {
        final decoded = jsonDecode(saved) as List<dynamic>;
        _accounts.addAll(
          decoded.map(
            (item) => Map<String, dynamic>.from(item as Map),
          ),
        );
      }
    } catch (_) {
      // Mantém a tela utilizável mesmo se houver dados antigos inválidos.
    }

    try {
      _catalogNetworks = await _registry.getAll();
    } catch (_) {
      _catalogNetworks = [];
    }

    if (!mounted) return;

    setState(() {
      _isLoading = false;
    });
  }

  List<SocialNetwork> get _availableNetworks {
    final result = <SocialNetwork>[..._builtInNetworks];
    final existingNames = result.map((n) => n.name.toLowerCase()).toSet();

    for (final network in _catalogNetworks) {
      if (!network.active) continue;

      if (existingNames.add(network.name.trim().toLowerCase())) {
        result.add(network);
      }
    }

    return result;
  }

  Future<void> _saveAccounts() async {
    if (mounted) {
      setState(() => _isSaving = true);
    }

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_storageKey, jsonEncode(_accounts));
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Não foi possível salvar as contas.'),
          ),
        );
      }
    }

    if (!mounted) return;

    setState(() => _isSaving = false);
  }

  Future<void> _addAccount() async {
    final networks = _availableNetworks;

    if (networks.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Não há redes ativas disponíveis no catálogo.'),
        ),
      );
      return;
    }

    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (_) => _AddAccountDialog(networks: networks),
    );

    if (result == null || !mounted) return;

    setState(() {
      _accounts.add(result);
    });

    await _saveAccounts();
  }

  Future<void> _toggleAccount(int index, bool active) async {
    setState(() {
      _accounts[index]['active'] = active;
    });

    await _saveAccounts();
  }

  Future<void> _removeAccount(int index) async {
    final name = _accounts[index]['name'] as String? ?? '';

    setState(() {
      _accounts.removeAt(index);
    });

    await _saveAccounts();

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Conta "$name" removida desta lista.')),
    );
  }

  IconData _platformIcon(String platform) {
    switch (platform.toLowerCase()) {
      case 'instagram':
        return Icons.camera_alt_outlined;
      case 'facebook':
        return Icons.facebook;
      case 'tiktok':
        return Icons.music_note_outlined;
      default:
        return Icons.share_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.topicName),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _isLoading || _isSaving ? null : _addAccount,
        icon: const Icon(Icons.add),
        label: const Text('Adicionar conta'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _accounts.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.share_outlined, size: 52),
                        SizedBox(height: 12),
                        Text(
                          'Nenhuma conta cadastrada',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 8),
                        Text(
                          'Adicione as contas que pertencem a este tema.',
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                )
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
                  children: [
                    Text(
                      'Contas de ${widget.topicName}',
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    ..._accounts.asMap().entries.map((entry) {
                      final index = entry.key;
                      final account = entry.value;
                      final platform =
                          account['platform'] as String? ?? '';
                      final name = account['name'] as String? ?? '';
                      final active = account['active'] == true;

                      return Card(
                        child: ListTile(
                          leading: Icon(
                            _platformIcon(platform),
                            size: 30,
                          ),
                          title: Text(name),
                          subtitle: Text(
                            '$platform • ${active ? 'Ativa' : 'Inativa'}',
                          ),
                          trailing: PopupMenuButton<String>(
                            onSelected: (value) {
                              if (value == 'toggle') {
                                _toggleAccount(index, !active);
                              } else if (value == 'delete') {
                                _removeAccount(index);
                              }
                            },
                            itemBuilder: (_) => [
                              PopupMenuItem(
                                value: 'toggle',
                                child: Text(
                                  active ? 'Desativar conta' : 'Ativar conta',
                                ),
                              ),
                              const PopupMenuItem(
                                value: 'delete',
                                child: Text('Remover da lista'),
                              ),
                            ],
                          ),
                        ),
                      );
                    }),
                    if (_isSaving)
                      const Padding(
                        padding: EdgeInsets.only(top: 8),
                        child: LinearProgressIndicator(),
                      ),
                  ],
                ),
    );
  }
}

class _AddAccountDialog extends StatefulWidget {
  final List<SocialNetwork> networks;

  const _AddAccountDialog({
    required this.networks,
  });

  @override
  State<_AddAccountDialog> createState() => _AddAccountDialogState();
}

class _AddAccountDialogState extends State<_AddAccountDialog> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();

  late SocialNetwork _selectedNetwork;

  @override
  void initState() {
    super.initState();
    _selectedNetwork = widget.networks.first;
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  void _add() {
    if (!_formKey.currentState!.validate()) return;

    Navigator.of(context).pop({
      'platform': _selectedNetwork.name,
      'networkId': _selectedNetwork.id,
      'name': _nameController.text.trim(),
      'active': true,
    });
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Adicionar conta'),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<String>(
                initialValue: _selectedNetwork.id,
                isExpanded: true,
                decoration: const InputDecoration(
                  labelText: 'Rede social',
                  border: OutlineInputBorder(),
                ),
                items: widget.networks.map((network) {
                  return DropdownMenuItem<String>(
                    value: network.id,
                    child: Text(network.name),
                  );
                }).toList(),
                onChanged: (value) {
                  if (value == null) return;

                  final selected = widget.networks.firstWhere(
                    (network) => network.id == value,
                  );

                  setState(() {
                    _selectedNetwork = selected;
                  });
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Nome ou identificação da conta',
                  hintText: '@minhaconta ou nome da página',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    value == null || value.trim().isEmpty
                        ? 'Informe o nome da conta.'
                        : null,
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancelar'),
        ),
        FilledButton(
          onPressed: _add,
          child: const Text('Adicionar'),
        ),
      ],
    );
  }
}
