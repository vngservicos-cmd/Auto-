
import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const AutomacaoConteudoApp());
}

class AutomacaoConteudoApp extends StatelessWidget {
  const AutomacaoConteudoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Automação de Conteúdo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF6750A4),
        ),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}
