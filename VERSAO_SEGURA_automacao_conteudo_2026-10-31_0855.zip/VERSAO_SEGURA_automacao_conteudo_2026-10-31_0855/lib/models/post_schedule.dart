
class PostSchedule {
  final String id;
  final String network;
  final String content;
  final DateTime? scheduledAt;
  final bool automatic;
  final String status;
  final DateTime createdAt;

  const PostSchedule({
    required this.id,
    required this.network,
    required this.content,
    required this.scheduledAt,
    required this.automatic,
    required this.status,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'network': network,
      'content': content,
      'scheduledAt': scheduledAt?.toIso8601String(),
      'automatic': automatic,
      'status': status,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory PostSchedule.fromJson(Map<String, dynamic> json) {
    return PostSchedule(
      id: json['id'] as String,
      network: json['network'] as String,
      content: json['content'] as String,
      scheduledAt: json['scheduledAt'] == null
          ? null
          : DateTime.parse(json['scheduledAt'] as String),
      automatic: json['automatic'] as bool? ?? false,
      status: json['status'] as String? ?? 'Rascunho',
      createdAt: DateTime.parse(json['createdAt'] as String),
    );
  }

  PostSchedule copyWith({
    String? network,
    String? content,
    DateTime? scheduledAt,
    bool? automatic,
    String? status,
  }) {
    return PostSchedule(
      id: id,
      network: network ?? this.network,
      content: content ?? this.content,
      scheduledAt: scheduledAt ?? this.scheduledAt,
      automatic: automatic ?? this.automatic,
      status: status ?? this.status,
      createdAt: createdAt,
    );
  }
}
