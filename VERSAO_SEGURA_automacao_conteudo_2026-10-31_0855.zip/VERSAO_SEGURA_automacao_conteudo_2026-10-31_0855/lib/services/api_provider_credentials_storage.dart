
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class ApiProviderCredentialsStorage {
  static const FlutterSecureStorage _storage = FlutterSecureStorage();

  String _keyFor(String accountId) =>
      'api_credential_account_$accountId';

  // Formato usado pela versão anterior do aplicativo.
  String _legacyKeyFor(String accountId) =>
      'api_credential_$accountId';

  Future<void> saveCredential({
    required String accountId,
    required String apiKey,
  }) async {
    await _storage.write(
      key: _keyFor(accountId),
      value: apiKey.trim(),
    );
  }

  Future<String?> readCredential(String accountId) async {
    final newKey = _keyFor(accountId);

    final currentCredential = await _storage.read(key: newKey);

    if (currentCredential != null &&
        currentCredential.isNotEmpty) {
      return currentCredential;
    }

    // Tenta recuperar a credencial salva pela versão antiga.
    final legacyKey = _legacyKeyFor(accountId);
    final legacyCredential =
        await _storage.read(key: legacyKey);

    if (legacyCredential == null ||
        legacyCredential.isEmpty) {
      return null;
    }

    // Migra a credencial para o novo formato.
    await _storage.write(
      key: newKey,
      value: legacyCredential,
    );

    await _storage.delete(key: legacyKey);

    return legacyCredential;
  }

  Future<void> deleteCredential(String accountId) async {
    await _storage.delete(key: _keyFor(accountId));
    await _storage.delete(key: _legacyKeyFor(accountId));
  }
}
