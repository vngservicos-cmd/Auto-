
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/post_schedule.dart';

class PostScheduleService {
  static const String _storageKey = 'post_schedules_v1';

  Future<List<PostSchedule>> getAll() async {
    final prefs = await SharedPreferences.getInstance();
    final storedData = prefs.getString(_storageKey);

    if (storedData == null || storedData.isEmpty) {
      return [];
    }

    try {
      final decoded = jsonDecode(storedData);

      if (decoded is! List) {
        return [];
      }

      return decoded
          .whereType<Map>()
          .map(
            (item) => PostSchedule.fromJson(
              Map<String, dynamic>.from(item),
            ),
          )
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<bool> saveAll(List<PostSchedule> schedules) async {
    final prefs = await SharedPreferences.getInstance();

    final encoded = jsonEncode(
      schedules.map((schedule) => schedule.toJson()).toList(),
    );

    return prefs.setString(_storageKey, encoded);
  }

  Future<bool> add(PostSchedule schedule) async {
    final schedules = await getAll();

    schedules.removeWhere((item) => item.id == schedule.id);
    schedules.add(schedule);

    return saveAll(schedules);
  }

  Future<bool> update(PostSchedule schedule) async {
    final schedules = await getAll();

    final index = schedules.indexWhere(
      (item) => item.id == schedule.id,
    );

    if (index == -1) {
      return false;
    }

    schedules[index] = schedule;

    return saveAll(schedules);
  }

  Future<bool> remove(String id) async {
    final schedules = await getAll();

    schedules.removeWhere((item) => item.id == id);

    return saveAll(schedules);
  }
}
