import 'api_provider_registry.dart';
import 'api_provider_credentials_storage.dart';
import 'api_provider_adapter.dart';

class ContentGenerationService {
  ContentGenerationService({
    ApiProviderRegistry? providerRegistry,
    ApiProviderCredentialsStorage? credentialsStorage,
    ApiProviderAdapterRegistry? adapterRegistry,
  })  : _providerRegistry = providerRegistry ?? ApiProviderRegistry(),
        _credentialsStorage =
            credentialsStorage ?? ApiProviderCredentialsStorage(),
        _adapterRegistry =
            adapterRegistry ?? ApiProviderAdapterRegistry(),
        _ownsAdapterRegistry = adapterRegistry == null;

  final ApiProviderRegistry _providerRegistry;
  final ApiProviderCredentialsStorage _credentialsStorage;
  final ApiProviderAdapterRegistry _adapterRegistry;
  final bool _ownsAdapterRegistry;

  bool _disposed = false;

  static const String _avisoPadrao = '''

Aviso importante:

Este conteúdo foi produzido com auxílio de inteligência artificial e tem finalidade informativa e reflexiva. Não deve ser considerado, por si só, uma fonte definitiva de informação, material didático validado ou referência para estudos acadêmicos. As informações apresentadas podem conter imprecisões e devem ser verificadas em fontes confiáveis quando utilizadas para estudos, pesquisas ou tomadas de decisão.

''';

  String _adicionarAviso(String texto) {
    final conteudo = texto.trim();

    if (conteudo.toLowerCase().contains(
      'este conteúdo foi produzido com auxílio de inteligência artificial',
    )) {
      return conteudo;
    }

    return '$conteudo\n\n${_avisoPadrao.trim()}';
  }

  void _checkNotDisposed() {
    if (_disposed) {
      throw Exception(
        'O serviço de geração já foi encerrado. Reabra a tela e tente novamente.',
      );
    }
  }

  Future<String> generate(String prompt) async {
    _checkNotDisposed();

    final normalizedPrompt = prompt.trim();

    if (normalizedPrompt.isEmpty) {
      throw Exception('Digite uma instrução para gerar o conteúdo.');
    }

    if (normalizedPrompt.length > 12000) {
      throw Exception(
        'O texto da solicitação ultrapassa 12.000 caracteres.',
      );
    }

    List<dynamic> accounts;

    try {
      accounts = await _providerRegistry.getAll();
    } catch (_) {
      throw Exception(
        'Não foi possível carregar as contas da Central de APIs. '
        'Verifique o armazenamento e tente novamente.',
      );
    }

    _checkNotDisposed();

    final compatibleAccounts = accounts
        .where(
          (account) =>
              account.active &&
              account.capability.trim().toLowerCase() == 'text',
        )
        .toList()
      ..sort((a, b) {
        final dateComparison = a.createdAt.compareTo(b.createdAt);

        if (dateComparison != 0) {
          return dateComparison;
        }

        return a.id.compareTo(b.id);
      });

    if (compatibleAccounts.isEmpty) {
      throw Exception(
        'Nenhuma conta ativa e compatível com geração de texto '
        'foi encontrada na Central de APIs.',
      );
    }

    final failures = <String>[];

    for (final account in compatibleAccounts) {
      _checkNotDisposed();

      final adapter = _adapterRegistry.find(
        account.provider.trim().toLowerCase(),
      );

      if (adapter == null) {
        failures.add(
          '${account.name}: fornecedor ainda não possui integração disponível.',
        );
        continue;
      }

      final modelId = account.modelId?.trim() ?? '';

      if (modelId.isEmpty) {
        failures.add(
          '${account.name}: nenhum modelo foi configurado.',
        );
        continue;
      }

      String? apiKey;

      try {
        apiKey = await _credentialsStorage.readCredential(account.id);
      } catch (_) {
        failures.add(
          '${account.name}: não foi possível acessar a credencial armazenada.',
        );
        continue;
      }

      _checkNotDisposed();

      if (apiKey == null || apiKey.trim().isEmpty) {
        failures.add(
          '${account.name}: credencial não encontrada.',
        );
        continue;
      }

      try {
        final result = await adapter.generateContent(
          apiKey: apiKey,
          modelId: modelId,
          prompt: normalizedPrompt,
        );

        _checkNotDisposed();

        if (result.trim().isEmpty) {
          failures.add(
            '${account.name}: o fornecedor retornou um conteúdo vazio.',
          );
          continue;
        }

        return _adicionarAviso(result);
      } on ApiProviderException catch (error) {
        failures.add('${account.name}: ${error.message}');

        if (!error.shouldTryNextAccount) {
          throw Exception(
            'A geração foi interrompida.\n${error.message}',
          );
        }
      } catch (_) {
        failures.add(
          '${account.name}: ocorreu uma falha inesperada durante a geração. '
          'Essa conta não será considerada disponível nesta tentativa.',
        );
      }
    }

    _checkNotDisposed();

    throw Exception(
      'Não foi possível gerar o conteúdo com as contas disponíveis.\n\n'
      '${failures.join('\n')}',
    );
  }

  void dispose() {
    if (_disposed) return;

    _disposed = true;

    if (_ownsAdapterRegistry) {
      _adapterRegistry.dispose();
    }
  }
}
