class ApiModel {
  final String id;
  final String name;
  final String provider;
  final String capability;
  final bool active;
  final bool recommended;

  const ApiModel({
    required this.id,
    required this.name,
    required this.provider,
    required this.capability,
    this.active = true,
    this.recommended = false,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'provider': provider,
      'capability': capability,
      'active': active,
      'recommended': recommended,
    };
  }

  factory ApiModel.fromJson(Map<String, dynamic> json) {
    return ApiModel(
      id: json['id'] as String,
      name: json['name'] as String,
      provider: json['provider'] as String,
      capability: json['capability'] as String,
      active: json['active'] as bool? ?? true,
      recommended: json['recommended'] as bool? ?? false,
    );
  }
}

class ApiModelCatalog {
  static const List<ApiModel> models = [
    // GOOGLE GEMINI
    ApiModel(
      id: 'gemini-3.1-flash-lite',
      name: 'Gemini 3.1 Flash Lite',
      provider: 'Google',
      capability: 'text',
      recommended: true,
    ),

    // Os próximos modelos serão adicionados conforme
    // a disponibilidade oficial de cada fornecedor.
  ];

  static List<ApiModel> getActiveModels(String provider) {
    return models
        .where(
          (model) =>
              model.provider.toLowerCase() ==
                  provider.toLowerCase() &&
              model.active,
        )
        .toList();
  }

  static ApiModel? findById(String id) {
    for (final model in models) {
      if (model.id == id) {
        return model;
      }
    }

    return null;
  }
}