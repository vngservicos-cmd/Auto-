
interface Env {
  GEMINI_API_KEY: string;
  APP_ACCESS_TOKEN: string;
  DB: D1Database;
}

const GEMINI_URL =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

function jsonResponse(
  data: unknown,
  status = 200,
): Response {
  return Response.json(data, {
    status,
    headers: corsHeaders,
  });
}

function getErrorMessage(error: unknown): string {
  return error instanceof Error
    ? error.message
    : "Erro desconhecido.";
}

function autorizado(
  request: Request,
  env: Env,
): boolean {
  const tokenRecebido =
    request.headers.get("Authorization");

  if (!env.APP_ACCESS_TOKEN || !tokenRecebido) {
    return false;
  }

  return tokenRecebido === `Bearer ${env.APP_ACCESS_TOKEN}`;
}

async function chamarGemini(
  apiKey: string,
  payload: Record<string, unknown>,
): Promise<Response> {
  return fetch(GEMINI_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": apiKey,
    },
    body: JSON.stringify(payload),
  });
}

export default {
  async fetch(
    request: Request,
    env: Env,
  ): Promise<Response> {
    const url = new URL(request.url);

    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: corsHeaders,
      });
    }

if (
  url.pathname.startsWith("/api/") &&
  !autorizado(request, env)
) {
  return jsonResponse(
    { erro: "Acesso não autorizado." },
    401,
  );
}

    if (url.pathname === "/" && request.method === "GET") {
      return new Response("Hello World!", {
        headers: {
          ...corsHeaders,
          "Content-Type": "text/plain; charset=utf-8",
        },
      });
    }

    // =====================================================
    // ROTA 1: VERIFICAÇÃO FACTUAL COM GOOGLE SEARCH
    // =====================================================

    if (
      url.pathname === "/api/verificar" &&
      request.method === "POST"
    ) {
      if (!env.GEMINI_API_KEY) {
        return jsonResponse(
          { erro: "A chave do Gemini não está configurada." },
          500,
        );
      }

      let body: {
        texto?: unknown;
        evidenciaAdicional?: unknown;
      };

      try {
        body = await request.json();
      } catch {
        return jsonResponse(
          { erro: "O corpo da requisição precisa ser JSON válido." },
          400,
        );
      }

      if (
        typeof body.texto !== "string" ||
        !body.texto.trim()
      ) {
        return jsonResponse(
          { erro: "Informe o conteúdo que será verificado." },
          400,
        );
      }

      if (body.texto.length > 5000) {
        return jsonResponse(
          { erro: "O conteúdo ultrapassa 5.000 caracteres." },
          400,
        );
      }

      if (
        body.evidenciaAdicional !== undefined &&
        (
          typeof body.evidenciaAdicional !== "string" ||
          body.evidenciaAdicional.length > 10000
        )
      ) {
        return jsonResponse(
          {
            erro:
              "A evidência adicional deve ser um texto de até 10.000 caracteres.",
          },
          400,
        );
      }

      const evidenciaAdicional =
        typeof body.evidenciaAdicional === "string"
          ? body.evidenciaAdicional.trim()
          : "";

      const prompt = `
Você é um assistente de verificação factual para conteúdo
em português brasileiro.

Pesquise fontes externas usando a ferramenta Google Search.

CONTEÚDO A VERIFICAR:
${body.texto}

${
  evidenciaAdicional
    ? `EVIDÊNCIA ADICIONAL FORNECIDA PELO USUÁRIO:
${evidenciaAdicional}`
    : ""
}

INSTRUÇÕES:
- Identifique as principais afirmações factuais verificáveis.
- Compare as afirmações com as fontes encontradas.
- Diferencie afirmações sustentadas, contraditas e não verificadas.
- Considere a atualidade, autoridade e relevância das fontes.
- Não invente fontes, links, datas ou evidências.
- Ausência de resultados não prova que uma afirmação é falsa.
- Se as fontes forem insuficientes, conflitantes ou inconclusivas,
  informe isso claramente.
- Diferencie fatos de opiniões, previsões e conteúdo criativo.
- Não declare que uma afirmação foi comprovada sem evidências adequadas.
- Escreva em português brasileiro.
- Apresente resumo, afirmações analisadas, limitações e fontes.

IMPORTANTE:
Sua análise não autoriza publicação automática.
O conteúdo deve continuar pendente de revisão humana.
`;

      try {
        const response = await chamarGemini(
          env.GEMINI_API_KEY,
          {
            contents: [
              {
                parts: [{ text: prompt }],
              },
            ],
            tools: [{ google_search: {} }],
          },
        );

        if (!response.ok) {
          const detalheGoogle = await response.text();

          // O detalhe fica no terminal local.
          // Nunca registre a chave da API.
          console.error(
            "[VERIFICAR] Erro do Google:",
            JSON.stringify({
              status: response.status,
              detalhe: detalheGoogle.slice(0, 2000),
            }),
          );

          return jsonResponse(
            {
              erro:
                "Não foi possível realizar a pesquisa e verificação.",
              codigoGoogle: response.status,
              detalheGoogle: detalheGoogle.slice(0, 2000),
            },
            502,
          );
        }

        const data = (await response.json()) as {
          candidates?: Array<{
            content?: {
              parts?: Array<{ text?: string }>;
            };
            groundingMetadata?: {
              groundingChunks?: Array<{
                web?: {
                  uri?: string;
                  title?: string;
                };
              }>;
            };
          }>;
        };

        const candidate = data.candidates?.[0];

        const relatorio = candidate?.content?.parts
          ?.map((part) => part.text ?? "")
          .join("")
          .trim();

        if (!relatorio) {
          console.error(
            "[VERIFICAR] Resposta sem relatório válido.",
          );

          return jsonResponse(
            {
              erro:
                "A verificação não retornou um relatório válido.",
            },
            502,
          );
        }

        const fontesMap = new Map<
          string,
          { titulo: string; url: string }
        >();

        for (
          const chunk of
          candidate?.groundingMetadata?.groundingChunks ?? []
        ) {
          const uri = chunk.web?.uri;

          if (uri && /^https?:\/\//i.test(uri)) {
            fontesMap.set(uri, {
              titulo: chunk.web?.title?.trim() || uri,
              url: uri,
            });
          }
        }

        const fontes = Array.from(fontesMap.values());

        // Ter links não significa que todas as afirmações
        // foram comprovadas. A revisão humana continua obrigatória.
        return jsonResponse({
          sucesso: true,
          status:
            fontes.length > 0
              ? "Pendente de revisão humana"
              : "Pendente por falta de evidências",
          liberadoParaPublicacao: false,
          relatorio,
          fontes,
          quantidadeFontes: fontes.length,
          revisaoHumanaObrigatoria: true,
        });
      } catch (error) {
        console.error(
          "[VERIFICAR] Falha de conexão:",
          getErrorMessage(error),
        );

        return jsonResponse(
          {
            erro:
              "Falha de conexão durante a verificação.",
          },
          502,
        );
      }
    }

    // =====================================================
    // ROTA 2: GERAÇÃO DE CONTEÚDO
    // Mantém o comportamento da rota original.
    // =====================================================

    if (
      url.pathname === "/api/gerar" &&
      request.method === "POST"
    ) {
      if (!env.GEMINI_API_KEY) {
        return jsonResponse(
          { erro: "A chave do Gemini não está configurada." },
          500,
        );
      }

      let body: { prompt?: unknown };

      try {
        body = await request.json();
      } catch {
        return jsonResponse(
          { erro: "O corpo da requisição precisa ser JSON válido." },
          400,
        );
      }

      if (
        typeof body.prompt !== "string" ||
        !body.prompt.trim()
      ) {
        return jsonResponse(
          { erro: "Informe um prompt de texto." },
          400,
        );
      }

      if (body.prompt.length > 12000) {
        return jsonResponse(
          {
            erro:
              "O prompt excede o limite de 12.000 caracteres.",
          },
          400,
        );
      }

      try {
        const response = await chamarGemini(
          env.GEMINI_API_KEY,
          {
            contents: [
              {
                parts: [{ text: body.prompt }],
              },
            ],
          },
        );

        if (!response.ok) {
          const detalheGoogle = await response.text();

          console.error(
            "[GERAR] Erro do Google:",
            JSON.stringify({
              status: response.status,
              detalhe: detalheGoogle.slice(0, 2000),
            }),
          );

          return jsonResponse(
            {
              erro:
                "O provedor Gemini não aceitou a solicitação.",
              codigoGoogle: response.status,
              detalhe: detalheGoogle.slice(0, 2000),
            },
            502,
          );
        }

        const data = (await response.json()) as {
          candidates?: Array<{
            content?: {
              parts?: Array<{ text?: string }>;
            };
          }>;
        };

        const texto = data.candidates?.[0]?.content?.parts
          ?.map((part) => part.text ?? "")
          .join("")
          .trim();

        if (!texto) {
          return jsonResponse(
            { erro: "O Gemini não retornou texto." },
            502,
          );
        }

        return jsonResponse({
          sucesso: true,
          texto,
        });
      } catch (error) {
        console.error(
          "[GERAR] Falha de conexão:",
          getErrorMessage(error),
        );

        return jsonResponse(
          { erro: "Não foi possível conectar ao Gemini." },
          502,
        );
      }
    }

    // =====================================================
    // ROTA 3: CONSULTA DE PROVEDORES NO D1
    // Somente leitura nesta primeira etapa.
    // =====================================================

    if (
      url.pathname === "/api/provedores" &&
      request.method === "GET"
    ) {
      try {
        const resultado = await env.DB
          .prepare(`
            SELECT
              id,
              name,
              service_type,
              provider_name,
              priority,
              is_active,
              created_at,
              updated_at
            FROM api_providers
            ORDER BY priority ASC, created_at ASC
          `)
          .all();

        return jsonResponse({
          sucesso: true,
          provedores: resultado.results,
          quantidade: resultado.results.length,
        });
      } catch (error) {
        console.error(
          "[PROVEDORES] Falha ao consultar D1:",
          getErrorMessage(error),
        );

        return jsonResponse(
          {
            erro: "Não foi possível consultar os provedores.",
          },
          500,
        );
      }
    }


    return jsonResponse(
      { erro: "Rota não encontrada." },
      404,
    );
  },
} satisfies ExportedHandler<Env>;
