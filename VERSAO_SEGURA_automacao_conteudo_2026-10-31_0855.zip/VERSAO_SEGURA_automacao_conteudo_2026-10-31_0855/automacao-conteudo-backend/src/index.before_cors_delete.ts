﻿
interface Env {
  GEMINI_API_KEY: string;
  APP_ACCESS_TOKEN: string;
  DB: D1Database;
}

const GEMINI_URL =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

function jsonResponse(
  data: unknown,
  status = 200,
): Response {
  return Response.json(data, {
    status,
    headers: corsHeaders,
  });
}

function getErrorMessage(error: unknown): string {
  return error instanceof Error
    ? error.message
    : "Erro desconhecido.";
}

function autorizado(
  request: Request,
  env: Env,
): boolean {
  const tokenRecebido =
    request.headers.get("Authorization");

  if (!env.APP_ACCESS_TOKEN || !tokenRecebido) {
    return false;
  }

  return tokenRecebido === `Bearer ${env.APP_ACCESS_TOKEN}`;
}

async function chamarGemini(
  apiKey: string,
  payload: Record<string, unknown>,
): Promise<Response> {
  return fetch(GEMINI_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": apiKey,
    },
    body: JSON.stringify(payload),
  });
}

export default {
  async fetch(
    request: Request,
    env: Env,
  ): Promise<Response> {
    const url = new URL(request.url);

    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: corsHeaders,
      });
    }

if (
  url.pathname.startsWith("/api/") &&
  !autorizado(request, env)
) {
  return jsonResponse(
    { erro: "Acesso nÃ£o autorizado." },
    401,
  );
}

    if (url.pathname === "/" && request.method === "GET") {
      return new Response("Hello World!", {
        headers: {
          ...corsHeaders,
          "Content-Type": "text/plain; charset=utf-8",
        },
      });
    }

    // =====================================================
    // ROTA 1: VERIFICAÃ‡ÃƒO FACTUAL COM GOOGLE SEARCH
    // =====================================================

    if (
      url.pathname === "/api/verificar" &&
      request.method === "POST"
    ) {
      if (!env.GEMINI_API_KEY) {
        return jsonResponse(
          { erro: "A chave do Gemini nÃ£o estÃ¡ configurada." },
          500,
        );
      }

      let body: {
        texto?: unknown;
        evidenciaAdicional?: unknown;
      };

      try {
        body = await request.json();
      } catch {
        return jsonResponse(
          { erro: "O corpo da requisiÃ§Ã£o precisa ser JSON vÃ¡lido." },
          400,
        );
      }

      if (
        typeof body.texto !== "string" ||
        !body.texto.trim()
      ) {
        return jsonResponse(
          { erro: "Informe o conteÃºdo que serÃ¡ verificado." },
          400,
        );
      }

      if (body.texto.length > 5000) {
        return jsonResponse(
          { erro: "O conteÃºdo ultrapassa 5.000 caracteres." },
          400,
        );
      }

      if (
        body.evidenciaAdicional !== undefined &&
        (
          typeof body.evidenciaAdicional !== "string" ||
          body.evidenciaAdicional.length > 10000
        )
      ) {
        return jsonResponse(
          {
            erro:
              "A evidÃªncia adicional deve ser um texto de atÃ© 10.000 caracteres.",
          },
          400,
        );
      }

      const evidenciaAdicional =
        typeof body.evidenciaAdicional === "string"
          ? body.evidenciaAdicional.trim()
          : "";

      const prompt = `
VocÃª Ã© um assistente de verificaÃ§Ã£o factual para conteÃºdo
em portuguÃªs brasileiro.

Pesquise fontes externas usando a ferramenta Google Search.

CONTEÃšDO A VERIFICAR:
${body.texto}

${
  evidenciaAdicional
    ? `EVIDÃŠNCIA ADICIONAL FORNECIDA PELO USUÃRIO:
${evidenciaAdicional}`
    : ""
}

INSTRUÃ‡Ã•ES:
- Identifique as principais afirmaÃ§Ãµes factuais verificÃ¡veis.
- Compare as afirmaÃ§Ãµes com as fontes encontradas.
- Diferencie afirmaÃ§Ãµes sustentadas, contraditas e nÃ£o verificadas.
- Considere a atualidade, autoridade e relevÃ¢ncia das fontes.
- NÃ£o invente fontes, links, datas ou evidÃªncias.
- AusÃªncia de resultados nÃ£o prova que uma afirmaÃ§Ã£o Ã© falsa.
- Se as fontes forem insuficientes, conflitantes ou inconclusivas,
  informe isso claramente.
- Diferencie fatos de opiniÃµes, previsÃµes e conteÃºdo criativo.
- NÃ£o declare que uma afirmaÃ§Ã£o foi comprovada sem evidÃªncias adequadas.
- Escreva em portuguÃªs brasileiro.
- Apresente resumo, afirmaÃ§Ãµes analisadas, limitaÃ§Ãµes e fontes.

IMPORTANTE:
Sua anÃ¡lise nÃ£o autoriza publicaÃ§Ã£o automÃ¡tica.
O conteÃºdo deve continuar pendente de revisÃ£o humana.
`;

      try {
        const response = await chamarGemini(
          env.GEMINI_API_KEY,
          {
            contents: [
              {
                parts: [{ text: prompt }],
              },
            ],
            tools: [{ google_search: {} }],
          },
        );

        if (!response.ok) {
          const detalheGoogle = await response.text();

          // O detalhe fica no terminal local.
          // Nunca registre a chave da API.
          console.error(
            "[VERIFICAR] Erro do Google:",
            JSON.stringify({
              status: response.status,
              detalhe: detalheGoogle.slice(0, 2000),
            }),
          );

          return jsonResponse(
            {
              erro:
                "NÃ£o foi possÃ­vel realizar a pesquisa e verificaÃ§Ã£o.",
              codigoGoogle: response.status,
              detalheGoogle: detalheGoogle.slice(0, 2000),
            },
            502,
          );
        }

        const data = (await response.json()) as {
          candidates?: Array<{
            content?: {
              parts?: Array<{ text?: string }>;
            };
            groundingMetadata?: {
              groundingChunks?: Array<{
                web?: {
                  uri?: string;
                  title?: string;
                };
              }>;
            };
          }>;
        };

        const candidate = data.candidates?.[0];

        const relatorio = candidate?.content?.parts
          ?.map((part) => part.text ?? "")
          .join("")
          .trim();

        if (!relatorio) {
          console.error(
            "[VERIFICAR] Resposta sem relatÃ³rio vÃ¡lido.",
          );

          return jsonResponse(
            {
              erro:
                "A verificaÃ§Ã£o nÃ£o retornou um relatÃ³rio vÃ¡lido.",
            },
            502,
          );
        }

        const fontesMap = new Map<
          string,
          { titulo: string; url: string }
        >();

        for (
          const chunk of
          candidate?.groundingMetadata?.groundingChunks ?? []
        ) {
          const uri = chunk.web?.uri;

          if (uri && /^https?:\/\//i.test(uri)) {
            fontesMap.set(uri, {
              titulo: chunk.web?.title?.trim() || uri,
              url: uri,
            });
          }
        }

        const fontes = Array.from(fontesMap.values());

        // Ter links nÃ£o significa que todas as afirmaÃ§Ãµes
        // foram comprovadas. A revisÃ£o humana continua obrigatÃ³ria.
        return jsonResponse({
          sucesso: true,
          status:
            fontes.length > 0
              ? "Pendente de revisÃ£o humana"
              : "Pendente por falta de evidÃªncias",
          liberadoParaPublicacao: false,
          relatorio,
          fontes,
          quantidadeFontes: fontes.length,
          revisaoHumanaObrigatoria: true,
        });
      } catch (error) {
        console.error(
          "[VERIFICAR] Falha de conexÃ£o:",
          getErrorMessage(error),
        );

        return jsonResponse(
          {
            erro:
              "Falha de conexÃ£o durante a verificaÃ§Ã£o.",
          },
          502,
        );
      }
    }

    // =====================================================
    // ROTA 2: GERAÃ‡ÃƒO DE CONTEÃšDO
    // MantÃ©m o comportamento da rota original.
    // =====================================================

    if (
      url.pathname === "/api/gerar" &&
      request.method === "POST"
    ) {
      if (!env.GEMINI_API_KEY) {
        return jsonResponse(
          { erro: "A chave do Gemini nÃ£o estÃ¡ configurada." },
          500,
        );
      }

      let body: { prompt?: unknown };

      try {
        body = await request.json();
      } catch {
        return jsonResponse(
          { erro: "O corpo da requisiÃ§Ã£o precisa ser JSON vÃ¡lido." },
          400,
        );
      }

      if (
        typeof body.prompt !== "string" ||
        !body.prompt.trim()
      ) {
        return jsonResponse(
          { erro: "Informe um prompt de texto." },
          400,
        );
      }

      if (body.prompt.length > 12000) {
        return jsonResponse(
          {
            erro:
              "O prompt excede o limite de 12.000 caracteres.",
          },
          400,
        );
      }

      try {
        const response = await chamarGemini(
          env.GEMINI_API_KEY,
          {
            contents: [
              {
                parts: [{ text: body.prompt }],
              },
            ],
          },
        );

        if (!response.ok) {
          const detalheGoogle = await response.text();

          console.error(
            "[GERAR] Erro do Google:",
            JSON.stringify({
              status: response.status,
              detalhe: detalheGoogle.slice(0, 2000),
            }),
          );

          return jsonResponse(
            {
              erro:
                "O provedor Gemini nÃ£o aceitou a solicitaÃ§Ã£o.",
              codigoGoogle: response.status,
              detalhe: detalheGoogle.slice(0, 2000),
            },
            502,
          );
        }

        const data = (await response.json()) as {
          candidates?: Array<{
            content?: {
              parts?: Array<{ text?: string }>;
            };
          }>;
        };

        const texto = data.candidates?.[0]?.content?.parts
          ?.map((part) => part.text ?? "")
          .join("")
          .trim();

        if (!texto) {
          return jsonResponse(
            { erro: "O Gemini nÃ£o retornou texto." },
            502,
          );
        }

        return jsonResponse({
          sucesso: true,
          texto,
        });
      } catch (error) {
        console.error(
          "[GERAR] Falha de conexÃ£o:",
          getErrorMessage(error),
        );

        return jsonResponse(
          { erro: "NÃ£o foi possÃ­vel conectar ao Gemini." },
          502,
        );
      }
    }

    // =====================================================
// ROTA 3: CONSULTA DE PROVEDORES NO D1
// Retorna os campos no formato esperado pelo Flutter.
// =====================================================

    // =====================================================
    // ROTA 3: CADASTRO DE PROVEDORES NO D1
    // =====================================================

    if (
      url.pathname === "/api/provedores" &&
      request.method === "POST"
    ) {
      let body: {
        id?: unknown;
        name?: unknown;
        provider?: unknown;
        capability?: unknown;
        connectionType?: unknown;
        active?: unknown;
        isFree?: unknown;
        hasFreeTrial?: unknown;
        priority?: unknown;
        trialDays?: unknown;
        trialEndsAt?: unknown;
        quotaRenewsAt?: unknown;
        websiteUrl?: unknown;
        notes?: unknown;
        createdAt?: unknown;
      };

      try {
        body = await request.json();
      } catch {
        return jsonResponse(
          { erro: "O corpo da requisição precisa ser JSON válido." },
          400,
        );
      }

      const camposTexto = [
        body.id,
        body.name,
        body.provider,
        body.capability,
        body.connectionType ?? "manual",
      ];

      if (
        camposTexto.some(
          (value) => typeof value !== "string" || !value.trim(),
        )
      ) {
        return jsonResponse(
          { erro: "Informe os campos obrigatórios do provedor." },
          400,
        );
      }

      if (
        (body.active !== undefined && typeof body.active !== "boolean") ||
        (body.isFree !== undefined && typeof body.isFree !== "boolean") ||
        (body.hasFreeTrial !== undefined && typeof body.hasFreeTrial !== "boolean") ||
        (body.priority !== undefined &&
          (!Number.isInteger(body.priority) || (body.priority as number) < 1)) ||
        (body.trialDays !== undefined &&
          body.trialDays !== null &&
          (!Number.isInteger(body.trialDays) || (body.trialDays as number) < 0))
      ) {
        return jsonResponse(
          { erro: "Um ou mais campos numéricos ou booleanos são inválidos." },
          400,
        );
      }

      const datas = [
        body.trialEndsAt,
        body.quotaRenewsAt,
        body.createdAt,
      ];

      if (
        datas.some(
          (value) =>
            value !== undefined &&
            value !== null &&
            (
              typeof value !== "string" ||
              Number.isNaN(Date.parse(value))
            ),
        )
      ) {
        return jsonResponse(
          { erro: "Uma ou mais datas informadas são inválidas." },
          400,
        );
      }

      if (
        (body.websiteUrl !== undefined &&
          body.websiteUrl !== null &&
          typeof body.websiteUrl !== "string") ||
        (body.notes !== undefined &&
          body.notes !== null &&
          typeof body.notes !== "string")
      ) {
        return jsonResponse(
          { erro: "Site e observações precisam ser textos." },
          400,
        );
      }

      try {
        const id = (body.id as string).trim();

        const existente = await env.DB
          .prepare("SELECT id FROM api_providers WHERE id = ?")
          .bind(id)
          .first();

        if (existente) {
          return jsonResponse(
            { erro: "Já existe um provedor com este ID." },
            409,
          );
        }

        const agora = new Date().toISOString();

        await env.DB
          .prepare(`
            INSERT INTO api_providers (
              id,
              name,
              provider_name,
              service_type,
              connection_type,
              is_active,
              is_free,
              has_free_trial,
              priority,
              trial_days,
              trial_ends_at,
              quota_renews_at,
              website_url,
              notes,
              created_at,
              updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `)
          .bind(
            id,
            (body.name as string).trim(),
            (body.provider as string).trim(),
            (body.capability as string).trim(),
            (body.connectionType as string | undefined) ?? "manual",
            body.active === false ? 0 : 1,
            body.isFree === false ? 0 : 1,
            body.hasFreeTrial === true ? 1 : 0,
            (body.priority as number | undefined) ?? 1,
            (body.trialDays as number | null | undefined) ?? null,
            (body.trialEndsAt as string | null | undefined) ?? null,
            (body.quotaRenewsAt as string | null | undefined) ?? null,
            (body.websiteUrl as string | null | undefined) ?? null,
            (body.notes as string | null | undefined) ?? null,
            (body.createdAt as string | undefined) ?? agora,
            agora,
          )
          .run();

        return jsonResponse(
          {
            sucesso: true,
            mensagem: "Provedor cadastrado com sucesso.",
            id,
          },
          201,
        );
      } catch (error) {
        console.error(
          "[PROVEDORES] Falha ao cadastrar:",
          getErrorMessage(error),
        );

        return jsonResponse(
          { erro: "Não foi possível cadastrar o provedor." },
          500,
        );
      }
    }
    // =====================================================
    // ROTA 4: EDIÇÃO DE PROVEDORES NO D1
    // =====================================================

    if (
      url.pathname === "/api/provedores" &&
      request.method === "PUT"
    ) {
      let body: {
        id?: unknown;
        name?: unknown;
        provider?: unknown;
        capability?: unknown;
        connectionType?: unknown;
        active?: unknown;
        isFree?: unknown;
        hasFreeTrial?: unknown;
        priority?: unknown;
        trialDays?: unknown;
        trialEndsAt?: unknown;
        quotaRenewsAt?: unknown;
        websiteUrl?: unknown;
        notes?: unknown;
      };

      try {
        body = await request.json();
      } catch {
        return jsonResponse(
          { erro: "O corpo da requisição precisa ser JSON válido." },
          400,
        );
      }

      const camposTexto = [
        body.id,
        body.name,
        body.provider,
        body.capability,
        body.connectionType ?? "manual",
      ];

      if (
        camposTexto.some(
          (value) => typeof value !== "string" || !value.trim(),
        )
      ) {
        return jsonResponse(
          { erro: "Informe os campos obrigatórios do provedor." },
          400,
        );
      }

      if (
        (body.active !== undefined && typeof body.active !== "boolean") ||
        (body.isFree !== undefined && typeof body.isFree !== "boolean") ||
        (body.hasFreeTrial !== undefined && typeof body.hasFreeTrial !== "boolean") ||
        (body.priority !== undefined &&
          (!Number.isInteger(body.priority) || (body.priority as number) < 1)) ||
        (body.trialDays !== undefined &&
          body.trialDays !== null &&
          (!Number.isInteger(body.trialDays) || (body.trialDays as number) < 0))
      ) {
        return jsonResponse(
          { erro: "Um ou mais campos numéricos ou booleanos são inválidos." },
          400,
        );
      }

      const datas = [
        body.trialEndsAt,
        body.quotaRenewsAt,
      ];

      if (
        datas.some(
          (value) =>
            value !== undefined &&
            value !== null &&
            (
              typeof value !== "string" ||
              Number.isNaN(Date.parse(value))
            ),
        )
      ) {
        return jsonResponse(
          { erro: "Uma ou mais datas informadas são inválidas." },
          400,
        );
      }

      if (
        (body.websiteUrl !== undefined &&
          body.websiteUrl !== null &&
          typeof body.websiteUrl !== "string") ||
        (body.notes !== undefined &&
          body.notes !== null &&
          typeof body.notes !== "string")
      ) {
        return jsonResponse(
          { erro: "Site e observações precisam ser textos." },
          400,
        );
      }

      try {
        const id = (body.id as string).trim();

        const resultado = await env.DB
          .prepare(`
            UPDATE api_providers
            SET
              name = ?,
              provider_name = ?,
              service_type = ?,
              connection_type = ?,
              is_active = ?,
              is_free = ?,
              has_free_trial = ?,
              priority = ?,
              trial_days = ?,
              trial_ends_at = ?,
              quota_renews_at = ?,
              website_url = ?,
              notes = ?,
              updated_at = ?
            WHERE id = ?
          `)
          .bind(
            (body.name as string).trim(),
            (body.provider as string).trim(),
            (body.capability as string).trim(),
            (body.connectionType as string | undefined) ?? "manual",
            body.active === false ? 0 : 1,
            body.isFree === false ? 0 : 1,
            body.hasFreeTrial === true ? 1 : 0,
            (body.priority as number | undefined) ?? 1,
            (body.trialDays as number | null | undefined) ?? null,
            (body.trialEndsAt as string | null | undefined) ?? null,
            (body.quotaRenewsAt as string | null | undefined) ?? null,
            (body.websiteUrl as string | null | undefined) ?? null,
            (body.notes as string | null | undefined) ?? null,
            new Date().toISOString(),
            id,
          )
          .run();

        if (resultado.meta.changes === 0) {
          return jsonResponse(
            { erro: "Provedor não encontrado." },
            404,
          );
        }

        return jsonResponse({
          sucesso: true,
          mensagem: "Provedor atualizado com sucesso.",
          id,
        });
      } catch (error) {
        console.error(
          "[PROVEDORES] Falha ao atualizar:",
          getErrorMessage(error),
        );

        return jsonResponse(
          { erro: "Não foi possível atualizar o provedor." },
          500,
        );
      }
    }
    if (
      url.pathname === "/api/provedores" &&
      request.method === "GET"
    ) {
      try {
        const resultado = await env.DB
          .prepare(`
            SELECT
              id,
              name,
              provider_name AS provider,
              service_type AS capability,
              connection_type AS connectionType,
              is_active AS active,
              is_free AS isFree,
              has_free_trial AS hasFreeTrial,
              priority,
              trial_days AS trialDays,
              trial_ends_at AS trialEndsAt,
              quota_renews_at AS quotaRenewsAt,
              website_url AS websiteUrl,
              notes,
              created_at AS createdAt
            FROM api_providers
            ORDER BY priority ASC, created_at ASC
          `)
          .all();

        const provedores = resultado.results.map((row) => ({
          ...row,
          active: Boolean(row.active),
          isFree: Boolean(row.isFree),
          hasFreeTrial: Boolean(row.hasFreeTrial),
        }));

        return jsonResponse({
          sucesso: true,
          provedores,
          quantidade: provedores.length,
        });
      } catch (error) {
        console.error(
          "[PROVEDORES] Falha ao consultar D1:",
          getErrorMessage(error),
        );

        return jsonResponse(
          { erro: "Não foi possível consultar os provedores." },
          500,
        );
      }
    }
    return jsonResponse(
      { erro: "Rota nÃ£o encontrada." },
      404,
    );
  },
} satisfies ExportedHandler<Env>;



