
import {
  env,
  createExecutionContext,
  waitOnExecutionContext,
  SELF,
} from "cloudflare:test";
import { describe, it, expect, vi } from "vitest";
import worker from "../src/index";

const IncomingRequest = Request<unknown, IncomingRequestCfProperties>;

describe("Hello World worker", () => {
  it("responds with Hello World! (unit style)", async () => {
    const request = new IncomingRequest("http://example.com");
    const ctx = createExecutionContext();
    const response = await worker.fetch(request, env, ctx);

    await waitOnExecutionContext(ctx);

    expect(await response.text()).toMatchInlineSnapshot(`"Hello World!"`);
  });

  it("responds with Hello World! (integration style)", async () => {
    const response = await SELF.fetch("https://example.com");

    expect(await response.text()).toMatchInlineSnapshot(`"Hello World!"`);
  });
});

describe("API de geração de conteúdo", () => {
  it("rejeita um prompt vazio", async () => {
    const response = await worker.fetch(
      new Request("http://example.com/api/gerar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: "   " }),
      }),
      { GEMINI_API_KEY: "chave-de-teste" },
      createExecutionContext(),
    );

    expect(response.status).toBe(400);
  });

  it("rejeita um prompt acima de 12.000 caracteres", async () => {
    const response = await worker.fetch(
      new Request("http://example.com/api/gerar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: "a".repeat(12001) }),
      }),
      { GEMINI_API_KEY: "chave-de-teste" },
      createExecutionContext(),
    );

    expect(response.status).toBe(400);
  });

  it("rejeita JSON inválido", async () => {
    const response = await worker.fetch(
      new Request("http://example.com/api/gerar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: "{json inválido",
      }),
      { GEMINI_API_KEY: "chave-de-teste" },
      createExecutionContext(),
    );

    expect(response.status).toBe(400);
  });

  it("retorna o texto quando o Gemini responde com sucesso", async () => {
    const fetchSimulado = vi
      .spyOn(globalThis, "fetch")
      .mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            candidates: [
              {
                content: {
                  parts: [
                    { text: "Conteúdo de teste gerado pela IA." },
                  ],
                },
              },
            ],
          }),
          {
            status: 200,
            headers: { "Content-Type": "application/json" },
          },
        ),
      );

    try {
      const response = await worker.fetch(
        new Request("http://example.com/api/gerar", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            prompt: "Crie uma legenda sobre tecnologia.",
          }),
        }),
        { GEMINI_API_KEY: "chave-de-teste" },
        createExecutionContext(),
      );

      expect(response.status).toBe(200);

      await expect(response.json()).resolves.toMatchObject({
        sucesso: true,
        texto: "Conteúdo de teste gerado pela IA.",
      });

      expect(fetchSimulado).toHaveBeenCalledOnce();
    } finally {
      fetchSimulado.mockRestore();
    }
  });
});
