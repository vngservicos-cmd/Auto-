﻿ALTER TABLE api_providers ADD COLUMN connection_type TEXT NOT NULL DEFAULT 'manual';
ALTER TABLE api_providers ADD COLUMN is_free INTEGER NOT NULL DEFAULT 1;
ALTER TABLE api_providers ADD COLUMN has_free_trial INTEGER NOT NULL DEFAULT 0;
ALTER TABLE api_providers ADD COLUMN trial_days INTEGER;
ALTER TABLE api_providers ADD COLUMN trial_ends_at TEXT;
ALTER TABLE api_providers ADD COLUMN quota_renews_at TEXT;
ALTER TABLE api_providers ADD COLUMN website_url TEXT;
ALTER TABLE api_providers ADD COLUMN notes TEXT;
