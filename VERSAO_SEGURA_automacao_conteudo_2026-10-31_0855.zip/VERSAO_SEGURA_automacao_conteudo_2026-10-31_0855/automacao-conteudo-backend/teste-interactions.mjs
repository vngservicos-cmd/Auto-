
const apiKey = process.env.GEMINI_API_KEY;

if (!apiKey) {
  console.error(
    "Chave não encontrada. Execute o teste pelo terminal do backend."
  );
  process.exit(1);
}

const url =
  "https://generativelanguage.googleapis.com/v1beta/interactions";

const body = {
  model: "gemini-3.1-flash-lite",
  input:
    "Pesquise na web e verifique a afirmação: a água ferve a 100 °C ao nível do mar sob pressão atmosférica padrão. Resuma a conclusão e cite as fontes consultadas.",
  tools: [{ type: "google_search" }]
};

try {
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": apiKey
    },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(90000)
  });

  const result = await response.json();

  console.log("Status HTTP:", response.status);
  console.log(JSON.stringify(result, null, 2));
} catch (error) {
  console.error("Falha na chamada:", error.message);
}
